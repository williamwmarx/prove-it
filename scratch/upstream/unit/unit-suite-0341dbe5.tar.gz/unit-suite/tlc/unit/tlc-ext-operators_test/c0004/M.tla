(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nCHECK_DEADLOCK FALSE"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt
VARIABLE x
C == TLCGetOrDefault(1, 0)
Init == x = 0
Next == x < 2 /\ TLCSet(1, x + 5) /\ PrintT(C) /\ x' = x + 1
====
