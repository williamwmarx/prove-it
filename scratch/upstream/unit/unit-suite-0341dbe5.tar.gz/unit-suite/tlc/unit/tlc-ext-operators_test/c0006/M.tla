(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nCHECK_DEADLOCK FALSE"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt
VARIABLE x
D == PrintT("d")
C == TLCEvalDefinition(IF PrintT("arg") THEN "D" ELSE "D")
Init == x = 0
Next == x < 2 /\ C /\ x' = x + 1
====
