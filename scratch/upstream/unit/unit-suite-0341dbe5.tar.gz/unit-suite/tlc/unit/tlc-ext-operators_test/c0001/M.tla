(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nACTION_CONSTRAINT Ask"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLCExt
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 3
Ask == PickSuccessor(x' # 1)
====
