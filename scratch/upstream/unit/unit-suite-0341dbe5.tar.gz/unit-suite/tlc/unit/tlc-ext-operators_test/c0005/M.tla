(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nCHECK_DEADLOCK FALSE"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt
VARIABLE x
C == TLCSet("s:k", 7)
Init == x = 0 /\ C
Next == x < 2 /\ PrintT(TLCGetOrDefault("s:k", 0)) /\ x' = x + 1
====
