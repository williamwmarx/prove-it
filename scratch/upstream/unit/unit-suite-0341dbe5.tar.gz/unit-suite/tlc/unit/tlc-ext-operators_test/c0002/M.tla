(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv"}
---*)
---- MODULE M ----
EXTENDS Integers, Sequences, TLC, TLCExt
VARIABLE x
Inv == AssertError("wrong", Head(<<>>))
Init == x = 0
Next == x < 2 /\ x' = x + 1
====
