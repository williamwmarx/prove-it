(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv"}
---*)
---- MODULE N ----
EXTENDS Naturals
VARIABLES x, y
---- MODULE Inner ----
EXTENDS Naturals
VARIABLES a, b
g[n \in 0..1] == a + n
P == g[1] + b < 3
====
---- MODULE Mid ----
VARIABLES p, q
J == INSTANCE Inner WITH a <- p, b <- q
====
I == INSTANCE Mid WITH p <- x + 1, q <- y
Init == x = 0 /\ y = 0
Next == x < 3 /\ x' = x + 1 /\ y' = y
Inv == I!J!P
====
