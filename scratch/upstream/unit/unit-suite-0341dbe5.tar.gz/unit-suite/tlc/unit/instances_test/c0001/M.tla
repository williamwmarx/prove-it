(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
---- MODULE Inner ----
VARIABLE v
Get == v
====
---- MODULE Mid ----
VARIABLE v
J == INSTANCE Inner WITH v <- v + 0
Val == J!Get
====
I == INSTANCE Mid WITH v <- x + 0
Init == x = 0
Next == x' = x
Inv == I!Val = 0
====
