(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS TLC
VARIABLE x
S(a) == INSTANCE Sequences
N(a) == INSTANCE Naturals
Ap(Op(_, _, _), v) == Op(1, v, 2)
ASSUME PrintT(<<S(1)!Append(<<5>>, 1), S(1)!Len(<<5>>), N(1)!+(2, 3), Ap(S!Append, <<4>>)>>)
Init == x = 0
Next == x' = x
====
