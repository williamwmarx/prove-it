(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE E ----
EXTENDS Integers
VARIABLES x, z
Init == x = 0 /\ z = [a |-> 0] /\ x /= 0
Next == x' = x /\ z' = [z EXCEPT !.a = 1]
====
