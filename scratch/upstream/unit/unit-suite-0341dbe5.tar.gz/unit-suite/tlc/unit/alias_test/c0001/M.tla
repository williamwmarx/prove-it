(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nALIAS Argument"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
Init == x = 0
Next == x < 1 /\ x' = x + 1
Argument(n) == [n |-> n]
====
