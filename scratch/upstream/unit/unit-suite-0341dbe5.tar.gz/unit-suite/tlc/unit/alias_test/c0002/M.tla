(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nALIAS Alias"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLES x, y
Init == x = 0 /\ y = 0
Next == IF x < 2 THEN x' = x + 1 /\ y' = y ELSE x' = x + 1
Alias == [x |-> x, lvl |-> TLCGet("level"), nx |-> x', ny |-> y']
====
