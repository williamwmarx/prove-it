(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec\nPROPERTY Property"}
---*)
---- MODULE Tree ----
EXTENDS Naturals
VARIABLE x
Next == x < 4000000 /\ x' \in {2 * x + 1, 2 * x + 2}
Spec == x = 0 /\ [][Next]_x
Property == TRUE ~> FALSE
====
