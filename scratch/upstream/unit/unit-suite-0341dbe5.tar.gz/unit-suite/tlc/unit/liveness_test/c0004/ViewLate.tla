(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec\nPROPERTY Prop\nVIEW View\nCHECK_DEADLOCK FALSE"}
---*)
---- MODULE ViewLate ----
EXTENDS Naturals
VARIABLES x, y
vars == <<x, y>>
Init == x = 0 /\ y = 0
Next ==
  \/ x = 0 /\ x' = 1 /\ y' = 0
  \/ x = 0 /\ x' = 2 /\ y' = 1
  \/ x = 0 /\ x' = 4 /\ y' = 0
  \/ x = 2 /\ x' = 1 /\ y' = y
  \/ x = 1 /\ y = 0 /\ x' = 5 /\ y' = y
  \/ x = 1 /\ y = 1 /\ x' = 3 /\ y' = y
  \/ x = 4 /\ x' = 3 /\ y' = y
Spec == Init /\ [][Next]_vars /\ WF_vars(Next)
Prop == (x = 2) ~> (x = 5)
View == x
====
