(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
Init == LET RECURSIVE Loop(_)
            Loop(i) == IF i < 1 THEN Loop(i + 1) ELSE i
        IN  x = Loop(0)
Spec == Init /\ [][x' = x]_x
====
