(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nPROPERTY Prop\nCHECK_DEADLOCK FALSE"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
S(v) == v < 0 /\ PrintT("s")
Init == x = 0
Next == x < 4 /\ x' = x + 1
Prop == <>[]~S(x)
====
