(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nPROPERTY Prop"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE s
RECURSIVE RecOp(_)
RecOp(n) == IF n = 0 THEN TRUE ELSE RecOp(n - 1)
Init == s = 0
Next == s' = (s + 1) % 3
Prop == []RecOp(s)
====
