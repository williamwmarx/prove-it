(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nPROPERTY Prop"}
---*)
---- MODULE M ----
EXTENDS Naturals, Sequences
VARIABLE x
G(v) == Head(<<>>) = 1
Init == x = 0
Next == x < 4 /\ x' = x + 1
Prop == <>(x = 3 /\ G(x))
====
