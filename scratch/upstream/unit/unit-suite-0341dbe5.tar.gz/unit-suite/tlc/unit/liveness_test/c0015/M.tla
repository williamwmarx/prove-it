(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec\nPROPERTY Live"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x /\ WF_x(Next)
Live == LET RECURSIVE G(_)
            G(n) == IF n = 0 THEN x ELSE G(n - 1)
        IN  []<>(G(2) = 2)
====
