(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nPROPERTY Prop"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
Bad == CHOOSE v \in {} : TRUE
Prop == []Bad
Init == x = 0
Next == x' = (x + 1) % 3
====
