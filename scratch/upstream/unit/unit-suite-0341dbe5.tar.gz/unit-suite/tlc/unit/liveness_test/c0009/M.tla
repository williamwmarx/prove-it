(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nPROPERTY Prop"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
Bad == x < 3 /\ 1 \div (x - x) = 0
Prop == []Bad
Init == x = 0
Next == x' = (x + 1) % 3
====
