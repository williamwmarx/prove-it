(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec\nPROPERTY Prop"}
---*)
---- MODULE M ----
EXTENDS Integers
VARIABLE x
Next == (x < 2 /\ x' = x + 1) \/ (x = 2 /\ x' = 0)
Spec == x = 0 /\ [][Next]_x /\ WF_x(Next)
Prop == ~((x = 1) ~> (x = 0))
====
