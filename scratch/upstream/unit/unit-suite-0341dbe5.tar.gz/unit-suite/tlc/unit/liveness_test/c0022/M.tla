(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec\nINVARIANT Inv\nCHECK_DEADLOCK FALSE", "args": ["-coverage", "1"]}
---*)
---- MODULE M ----
EXTENDS Integers
VARIABLES x, y
vars == <<x, y>>
Inc == x < 3 /\ x' = x + 1 /\ y' = y
Dec == x > 0 /\ x' = x - 1 /\ y' = y
Init == x = 0 /\ y \in {0, 1}
Spec == LET N == [][Inc \/ Dec]_vars IN Init /\ N
Inv == x < 3
====
