(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec\nPROPERTY Prop"}
---*)
---- MODULE M ----
EXTENDS TLC
VARIABLE x
A0 == PrintT(<<"A0", x>>) /\ x' = ~x
A1 == PrintT(<<"A1", x>>) /\ UNCHANGED x
Spec == x = FALSE /\ [][A0 \/ A1]_x /\ WF_<<x>>(A0) /\ WF_x(A1)
Prop == x ~> ~x
====
