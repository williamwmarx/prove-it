(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec\nPROPERTY Prop"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x /\ WF_x(Next)
Prop == LET RECURSIVE F F == IF x = 0 THEN <>(x = 1) ELSE F IN F
====
