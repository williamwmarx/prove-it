(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec\nPROPERTY Prop"}
---*)
---- MODULE M ----
EXTENDS Naturals, Sequences, TLC
VARIABLE x
Init == x = FALSE
Next == x' \in BOOLEAN
Spec == Init /\ [][Next]_x /\ \A i \in 1..6 : \A j \in 1..6 : SF_x(Next)
Prop == <>[](x \in BOOLEAN)
====
