(*---
{"description": "upstream unit case", "outcome": "any", "config": "", "args": ["-maxSetSize", "None"]}
---*)
---- MODULE M ----
EXTENDS Naturals, FiniteSets, TLC
ASSUME Nat = {{s \in SUBSET {1, 2} : PrintT(s) /\ s # 1}}
====
