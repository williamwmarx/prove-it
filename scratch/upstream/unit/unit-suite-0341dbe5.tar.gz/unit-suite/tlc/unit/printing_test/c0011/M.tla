(*---
{"description": "upstream unit case", "outcome": "any", "config": "", "args": ["-maxSetSize", "10"]}
---*)
---- MODULE M ----
EXTENDS Naturals, FiniteSets, TLC
ASSUME (SUBSET (1..5) \ {s \in SUBSET (1..5) : Cardinality(s) <= 1 /\ PrintT(s)}) = {}
====
