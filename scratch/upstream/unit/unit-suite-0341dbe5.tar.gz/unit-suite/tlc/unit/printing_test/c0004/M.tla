(*---
{"description": "upstream unit case", "outcome": "any", "config": "", "args": ["-maxSetSize", "None"]}
---*)
---- MODULE M ----
EXTENDS Naturals, FiniteSets, TLC
ASSUME {1, "a"} = {s \in SUBSET {1} : PrintT(s)}
====
