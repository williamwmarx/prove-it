(*---
{"description": "upstream unit case", "outcome": "any", "config": "", "args": ["-maxSetSize", "33"]}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC
ASSUME (SUBSET (1..5) \cup {s \in SUBSET (1..2) : PrintT(s)}) = {}
====
