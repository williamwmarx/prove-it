(*---
{"description": "upstream unit case", "outcome": "any", "config": "CONSTANT C = a_b"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC
CONSTANT C
ASSUME PrintT(Nat = C)
====
