(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nCONSTRAINT Constr"}
---*)
---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, TLCExt
VARIABLE x
Init == x = 0
A == x' = x + 1
B == x' = Len(x)
Next == A \/ B
Constr == Len(Trace) < 3
====
