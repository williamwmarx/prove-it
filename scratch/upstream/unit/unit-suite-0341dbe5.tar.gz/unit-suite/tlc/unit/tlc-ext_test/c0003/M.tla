(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv\nALIAS Alias"}
---*)
---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, TLCExt
VARIABLE x
Init == x = 0
Next == x' = x + 1
Alias == [x |-> x, n |-> Len(Trace)]
Inv == x < 1
====
