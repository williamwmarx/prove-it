(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nCHECK_DEADLOCK FALSE\nINVARIANT Inv", "args": ["-coverage", "1"]}
---*)
---- MODULE M ----
EXTENDS Naturals, Sequences, TLCExt
VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == Len(Trace) > 0
====
