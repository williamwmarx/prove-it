(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv\nALIAS Alias\n"}
---*)
---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, TLCExt
VARIABLE x
Init == x = 0 /\ PrintT("init")
Next == x' = x + 1 /\ PrintT(<<"next", x>>)
Inv == x < 4
Alias == [x |-> x, n |-> Len(Trace)]
====
