(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv\nVIEW View"}
---*)
---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, TLCExt
VARIABLE x
Init == x = 0 /\ PrintT("init")
Next == x < 4 /\ x' = x + 1 /\ PrintT(Len(Trace))
Inv == x < 3
View == x
====
