(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec\nPROPERTY Prop\nALIAS Alias\nCHECK_DEADLOCK FALSE"}
---*)
---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, TLCExt
VARIABLE x
Alias == [x |-> x, n |-> Len(Trace)]
Init == x = 0
Next == x < 3 /\ x' = x + 1
Spec == Init /\ [][Next]_x
Prop == <>(x = 4)
====
