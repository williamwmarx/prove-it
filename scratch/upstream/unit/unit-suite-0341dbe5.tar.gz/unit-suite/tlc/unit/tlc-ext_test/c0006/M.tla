(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv\nALIAS Alias\nCONSTRAINT Constr"}
---*)
---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, TLCExt
VARIABLE x
Init == x = 0 /\ PrintT("init")
Next == x' = x + 1 /\ PrintT(<<"next", x>>)
Inv == x < 3
Constr == x < 3
Alias == [x |-> x, n |-> Len(Trace)]
====
