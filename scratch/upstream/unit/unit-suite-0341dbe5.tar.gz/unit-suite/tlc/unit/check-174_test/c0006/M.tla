(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals, FiniteSets
VARIABLE x
Init == x = Cardinality([Nat -> {}])
Next == UNCHANGED x
====
