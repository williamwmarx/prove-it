(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
Init == x = 0
Next == \E n \in {1, 2} : x' = x + n
Inv == x # 3 \/ CHOOSE n \in {} : TRUE
====
