(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec"}
---*)
---- MODULE M ----
VARIABLE x
S(v) == v = 0 /\ [][v' = v]_v
Spec == S(x)
====
