(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec\nPROPERTY P"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
Init == x = 0
Spec == Init /\ [][x' = x]_x
P == <>(1 \notin SUBSET 1)
====
