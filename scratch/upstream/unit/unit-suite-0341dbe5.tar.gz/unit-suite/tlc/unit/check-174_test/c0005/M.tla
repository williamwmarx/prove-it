(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS TLC
VARIABLE x
Init == x = TLCGet("revision").tag
Next == UNCHANGED x
====
