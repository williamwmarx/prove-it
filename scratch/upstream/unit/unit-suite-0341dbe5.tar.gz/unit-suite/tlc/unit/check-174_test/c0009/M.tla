(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nCONSTRAINT C\nCHECK_DEADLOCK FALSE"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
Next == x' = x + 1
C == TLCGet("level") < 3
====
