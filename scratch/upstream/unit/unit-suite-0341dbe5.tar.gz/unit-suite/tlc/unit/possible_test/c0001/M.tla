(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nPOSTCONDITION Post"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC, _Possible
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 3 /\ _Track(x = 1, "ReachesTheFirstLongState") /\ _Track(x = 2, "ReachesTheSecondLongState") /\ _Track(x = 7, "ReachesTheThirdLongStateNever")
Post == _PrintCounts /\ _CheckName("ReachesTheThirdLongStateNever")
====
