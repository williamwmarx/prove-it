(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
EXTENDS Naturals
A == 1
B == 2
THEOREM TRUE BY DEF A + 1, {}, -A, A(1)
THEOREM TRUE BY DEF (A), A', <<A>>, A[1]
USE DEF A.b, B
====
