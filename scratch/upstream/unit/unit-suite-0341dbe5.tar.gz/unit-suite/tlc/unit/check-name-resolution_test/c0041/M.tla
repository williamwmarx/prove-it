(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
A == 1
B == 2
THEOREM TRUE BY DEF CASE A -> 1 [] OTHER -> 2, [a |-> 1], [a : {}], A
THEOREM TRUE BY DEF [v \in {} |-> 1], \A v, w \in {} : TRUE, A
THEOREM TRUE BY DEF LET Q == 1 IN Q, A \X B, A /\ B, {A \/ B}, A
THEOREM TRUE BY DEF [A EXCEPT ![1] = 2], [A -> B], {A : v \in {}}, WF_A(B), A
THEOREM TRUE BY DEF /\ A
                    /\ B
====
