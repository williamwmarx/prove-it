(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
x == 1
THEOREM T == []ASSUME CASE x = 1 -> TRUE [] x = 2 -> TRUE []PROVE TRUE
====
