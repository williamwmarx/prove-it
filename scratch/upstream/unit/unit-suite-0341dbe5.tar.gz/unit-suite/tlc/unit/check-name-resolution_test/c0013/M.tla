(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
THEOREM TRUE
<1>3. TRUE
<1>3. CASE TRUE
<1> QED
VARIABLE x
Init == x = 0
Next == x' = x
====
