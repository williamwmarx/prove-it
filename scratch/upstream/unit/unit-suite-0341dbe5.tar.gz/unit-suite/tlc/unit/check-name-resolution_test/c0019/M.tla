(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
CONSTANT c
F == 1
USE DEF Later
Later == 1
---- MODULE Inner ----
G == 1
====
I == INSTANCE Inner
THEOREM TRUE BY DEF x, c, F, Nope, I, I!G, I!H
THEOREM ASSUME NEW xx PROVE TRUE
  BY DEF xx
THEOREM TRUE
<1> PICK p : p = 1 OBVIOUS
<1> QED BY DEF p
HIDE DEF -., \cup, +, Nat
====
