(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
EXTENDS Naturals
CONSTANT k
THEOREM TRUE
<1>1. CHOOSE b : k + 1
  OBVIOUS
<1>2. <1>1!1
  OBVIOUS
<1> QED
====
