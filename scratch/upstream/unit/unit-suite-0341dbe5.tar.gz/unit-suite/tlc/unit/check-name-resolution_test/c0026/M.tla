(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
THEOREM T == []ASSUME TRUE []PROVE TRUE
X == T!1
====
