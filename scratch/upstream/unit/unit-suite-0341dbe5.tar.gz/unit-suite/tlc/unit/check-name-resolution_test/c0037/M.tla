(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
VARIABLE x
THEOREM TRUE
<1>1. SUFFICES ASSUME TRUE PROVE TRUE
  OBVIOUS
<1>2. []ASSUME TRUE []PROVE TRUE
  OBVIOUS
<1> QED
====
