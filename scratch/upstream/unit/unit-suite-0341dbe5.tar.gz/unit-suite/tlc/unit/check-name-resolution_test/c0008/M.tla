(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
J == INSTANCE Naturals
J == INSTANCE Naturals
VARIABLE x
Init == x = 0
Next == x' = x
====
