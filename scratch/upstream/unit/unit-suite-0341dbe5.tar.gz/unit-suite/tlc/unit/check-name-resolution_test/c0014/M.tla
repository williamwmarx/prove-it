(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
---- MODULE A ----
VARIABLE Baz
====
---- MODULE B ----
CONSTANT Baz
====
---- MODULE C ----
EXTENDS A, B
F == Baz
====
VARIABLE x
Init == x = 0
Next == x' = x
====
