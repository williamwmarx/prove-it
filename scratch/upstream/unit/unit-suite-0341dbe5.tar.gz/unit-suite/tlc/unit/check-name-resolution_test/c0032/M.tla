(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
THEOREM TRUE
<1>1. SUFFICES ASSUME TRUE PROVE TRUE
  <2>1. []ASSUME TRUE []PROVE TRUE
    OBVIOUS
  <2> QED
<1> QED
====
