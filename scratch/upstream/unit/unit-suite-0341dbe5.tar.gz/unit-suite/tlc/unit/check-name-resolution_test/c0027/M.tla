(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
THEOREM []ASSUME NEW VARIABLE v, v = 1 []PROVE v' = 1
====
