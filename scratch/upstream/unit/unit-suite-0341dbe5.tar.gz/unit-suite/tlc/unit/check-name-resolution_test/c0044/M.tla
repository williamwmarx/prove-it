(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
A == 1
B == 2
f == [x \in {1} |-> x]
F(x) == x
THEOREM TRUE BY DEF A + B + A, A /\ B /\ A, f[1] + B, A'', F(A)[1], A
====
