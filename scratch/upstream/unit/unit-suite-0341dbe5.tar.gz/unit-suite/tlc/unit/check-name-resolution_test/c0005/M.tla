(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals
ASSUME [EXTENDS |-> 3, a |-> 1].a = 1
VARIABLE v
Init == v = 0
Next == UNCHANGED v
====
