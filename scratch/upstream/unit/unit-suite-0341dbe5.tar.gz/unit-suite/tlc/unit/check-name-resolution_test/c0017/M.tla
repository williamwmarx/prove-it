(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
Init == x = 0
Next == x' = x
RECURSIVE F(_), F(_)
====
