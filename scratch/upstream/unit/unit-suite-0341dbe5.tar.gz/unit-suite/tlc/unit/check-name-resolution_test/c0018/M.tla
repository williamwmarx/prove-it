(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
USE
THEOREM TRUE
<1>1. HIDE
<1>2. USE ONLY
<1> QED
====
