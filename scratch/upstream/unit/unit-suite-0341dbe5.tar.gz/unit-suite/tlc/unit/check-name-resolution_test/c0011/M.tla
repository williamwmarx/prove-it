(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
---- MODULE P ----
VARIABLE sv
Shared == 0
====
---- MODULE In1 ----
EXTENDS P
====
---- MODULE Q ----
EXTENDS P
INSTANCE In1
====
VARIABLE x
Init == x = 0
Next == x' = x
====
