(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec\nPROPERTY Prop"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
---- MODULE Inner ----
B(p) == <<p>>
====
I(q) == INSTANCE Inner
Id(v) == v
Next == x' = (x + 1) % 3
Spec == x = 0 /\ [][Next]_x /\ WF_Id(x)(Next)
Prop == <>(x = 2)
====
