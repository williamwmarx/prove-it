(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
---- MODULE Base ----
Foo == 1
====
LOCAL INSTANCE Base
LOCAL INSTANCE Base
INSTANCE Base
VARIABLE x
Init == x = 0
Next == x' = x
====
