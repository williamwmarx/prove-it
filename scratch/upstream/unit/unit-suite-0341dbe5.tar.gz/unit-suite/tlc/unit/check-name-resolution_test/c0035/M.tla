(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
VARIABLE x
THEOREM T == ASSUME x = 1, []ASSUME x = 2 []PROVE x = 2 PROVE x = 1
====
