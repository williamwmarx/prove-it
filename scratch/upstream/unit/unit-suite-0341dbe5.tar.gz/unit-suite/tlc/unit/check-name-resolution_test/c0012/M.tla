(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
THEOREM ASSUME NEW a, NEW a PROVE TRUE
VARIABLE x
Init == x = 0
Next == x' = x
====
