(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
THEOREM T == []ASSUME []ASSUME TRUE []PROVE TRUE, ASSUME TRUE PROVE TRUE, []ASSUME TRUE []PROVE TRUE []PROVE TRUE
====
