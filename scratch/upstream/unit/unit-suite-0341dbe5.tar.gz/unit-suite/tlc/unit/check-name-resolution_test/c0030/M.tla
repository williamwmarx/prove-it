(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
THEOREM TRUE
<1>1. []ASSUME TRUE []PROVE TRUE
  OBVIOUS
<1>2. SUFFICES []ASSUME TRUE []PROVE TRUE
  OBVIOUS
<1> QED
====
