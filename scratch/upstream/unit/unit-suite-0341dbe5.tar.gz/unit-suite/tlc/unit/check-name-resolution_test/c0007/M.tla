(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
Nat == 1
INSTANCE Naturals
VARIABLE x
Init == x = 0
Next == x' = x
====
