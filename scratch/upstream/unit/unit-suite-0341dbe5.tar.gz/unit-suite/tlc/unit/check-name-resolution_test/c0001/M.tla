(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec\nPROPERTY Prop"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
---- MODULE Inner ----
VARIABLE x
vars == <<x>>
Next == x' = (x + 1) % 3
====
I == INSTANCE Inner
Spec == x = 0 /\ [][I!Next]_I!vars /\ WF_I!vars(I!Next)
Prop == <>(x = 2)
THEOREM Spec => WF_I!vars(I!Next)
====
