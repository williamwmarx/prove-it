(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
A == 1
THEOREM TRUE BY DEF /\ A
====
