(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
THEOREM T == []ASSUME a :: []ASSUME TRUE []PROVE TRUE []PROVE TRUE
X == T!a!1
====
