(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
ASSUME A == TRUE
ASSUME A == TRUE
VARIABLE x
Init == x = 0
Next == x' = x
====
