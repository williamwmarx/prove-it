(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
---- MODULE A ----
Foo == 1
====
---- MODULE B ----
Foo(a) == 2
====
---- MODULE C ----
EXTENDS A, B
F == Foo
====
I == INSTANCE C
VARIABLE x
Init == x = 0
Next == x' = x
====
