(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
VARIABLE x
THEOREM ASSUME NEW c PROVE TRUE
<1>1. []ASSUME c PROVE c
  OBVIOUS
<1> QED
====
