(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
CONSTANT K
A == 1
B == 2
THEOREM TRUE BY DEF CHOOSE v : TRUE, \E v, w : TRUE, {v \in {} : TRUE}, A
THEOREM TRUE BY DEF CHOOSE <<a, b>> \in {} : TRUE, {<<a, b>> \in {} : TRUE}, 12.50, A
THEOREM TRUE BY DEF CHOOSE A : TRUE, CHOOSE K : TRUE, \AA v : TRUE
====
