(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
A(i) == x < 3 /\ TLCGet("stats").distinct < 3 /\ x' = x + i
Next == \E i \in {1} : A(i)
Inv == x < 2
====
