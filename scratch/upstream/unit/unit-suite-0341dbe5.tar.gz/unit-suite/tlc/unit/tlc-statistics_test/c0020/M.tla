(*---
{"description": "upstream unit case", "outcome": "any", "config": "CONSTANT C = 0\nCONSTANT Def <- Alt\nINIT Init\nNEXT Next\nINVARIANT Inv"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC
CONSTANT C
VARIABLE x
Init == x = 0
Def == x
Alt == 1
Lit == IF FALSE THEN x ELSE 1
A(p) == x < 1 /\ x' = x + 1 /\ PrintT(<<"A", p>>)
Next == A(Def)
Inv == x < 1
====
