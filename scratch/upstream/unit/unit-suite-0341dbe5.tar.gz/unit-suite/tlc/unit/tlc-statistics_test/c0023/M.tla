(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv\nVIEW View"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x \in {0, 1}
Next == x' = x + 1
Inv == x < 3
View == <<x, TLCGet("level")>>
====
