(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
Next == x < 3 /\ TLCGet("stats").distinct < 3 /\ x' = x + 1
Inv == x < 2
====
