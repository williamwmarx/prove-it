(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
ASSUME TLCSet(1, 7)
Init == x = 0
A(p) == x < 1 /\ x' = x + 1 /\ PrintT(<<"A", p>>)
Next == \E p \in {TLCGet("all")} : A(p)
Inv == x < 1
====
