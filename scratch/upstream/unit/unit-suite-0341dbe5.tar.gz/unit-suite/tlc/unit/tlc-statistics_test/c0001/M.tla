(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
Next == x' \in {1, 2, 3} /\ PrintT(<<x', TLCGet("generated")>>)
Inv == x # 2
====
