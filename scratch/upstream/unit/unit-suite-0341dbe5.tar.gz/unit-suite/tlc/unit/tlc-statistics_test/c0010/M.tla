(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0 /\ TLCGet("s:q") = 5
Next == \E p \in {TLCSet("s:q", 5)} : x' = x
====
