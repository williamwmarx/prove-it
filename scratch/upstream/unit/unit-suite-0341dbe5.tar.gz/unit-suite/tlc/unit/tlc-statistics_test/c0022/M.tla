(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x \in {0, 1} /\ PrintT(<<"init", x, TLCGet("level")>>)
Next == x' = x + 1
Inv == x < 3
====
