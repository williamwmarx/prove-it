(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS TLC
VARIABLE x
A == "b"
B == "a"
ASSUME PrintT({ToString("a"), ToString("b")})
Init == x = 0
Next == UNCHANGED x
====
