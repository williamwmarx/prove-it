(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
EXTENDS Integers, Sequences, TLC
E == [k \in {} |-> k]
ASSUME \A i \in 1..5 : PrintT(<<[k \in 1..0 |-> k], E @@ E, Tail(<<1>>), E \o E, <<E>>>>[i])
====
