(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nCHECK_DEADLOCK FALSE"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLES x, y
g[n \in 0..2] == IF n < 0 THEN g[0] ELSE x + n + (IF PrintT(n) THEN 0 ELSE 1)
Init == x = 0 /\ y = <<>>
Next == x < 1 /\ x' = x + 1 /\ y' = <<[g EXCEPT ![1] = 7]>>
====
