(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nPROPERTY Prop"}
---*)
---- MODULE M ----
VARIABLE x
Init == x = 0
Next == x' = x
Prop == <>(\E k \in {1} : \E j \in {} : x = k) /\ <>(\E k \in {1} : \E j \in {} : x = k)
====
