(*---
{"description": "upstream unit case", "outcome": "any", "config": "CONSTANT P = {p1, p2}\nINIT Init\nNEXT Next\nINVARIANT Inv\nSYMMETRY Sym"}
---*)
---- MODULE M ----
EXTENDS Integers, TLC
CONSTANT P
VARIABLES q, x
Sym == Permutations(P)
Init == q = <<>> /\ x = 0
Next == x' = x + 1 /\ q' = IF x = 0 THEN [k \in 1..0 |-> k] ELSE q
Inv == x < 2
====
