(*---
{"description": "upstream unit case", "outcome": "any", "config": "CONSTANT A = {a1, a2}\nCONSTANT B = {b1, b2}\nCONSTANT Def <- [M] Perms\nSYMMETRY Def\nINIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS TLC
CONSTANTS A, B
VARIABLE x
Perms == Permutations(A)
Def == Permutations(B)
Init == x \in A
Next == x' = x
====
