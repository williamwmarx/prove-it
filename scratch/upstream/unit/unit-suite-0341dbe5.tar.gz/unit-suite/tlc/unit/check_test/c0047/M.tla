(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS TLCExt
VARIABLE v
Init == v = {TLCModelValue("A_a"), TLCModelValue("B_a")}
Next == UNCHANGED v
====
