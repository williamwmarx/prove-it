(*---
{"description": "upstream unit case", "outcome": "any", "config": "CONSTANTS p1 = p1 p2 = p2\nSPECIFICATION Spec\nPROPERTY Prop\nSYMMETRY Sym"}
---*)
---- MODULE M ----
EXTENDS Naturals, Sequences, TLC
CONSTANTS p1, p2
VARIABLES x, y
Init == x = 0 /\ y = 0
A1 == y' = 1 /\ x' = x
A2 == y' = Head(<<>>) /\ x' = x
Spec == Init /\ [][A1 \/ A2]_<<x, y>>
Prop == [][x' # x]_<<x, y>>
Sym == Permutations({p1, p2})
====
