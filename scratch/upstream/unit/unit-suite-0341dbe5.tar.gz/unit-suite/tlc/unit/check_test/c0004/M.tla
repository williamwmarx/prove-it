(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
EXTENDS Naturals
ASSUME \A y \in UNION {SUBSET {1}, {{}}} : TRUE
====
