(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nCONSTRAINT C\nINVARIANT Inv"}
---*)
---- MODULE M ----
EXTENDS Integers
VARIABLE x
Record == [a |-> 0, b |-> 0]
Init == x = [b |-> TRUE, a |-> 1]
Next == UNCHANGED x
C == x.a > 5
Inv == x.a = 0
====
