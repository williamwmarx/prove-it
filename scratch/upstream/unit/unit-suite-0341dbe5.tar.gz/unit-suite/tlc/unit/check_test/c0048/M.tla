(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT TypeOK"}
---*)
---- MODULE M ----
EXTENDS Integers
VARIABLE f
Init == f = [p \in 1..2 |-> [q \in 1..2 |-> 0]]
Next == \E p, q \in 1..2 : f' = [f EXCEPT ![p][q] = @ + 1]
TypeOK == f \in [1..2 -> [1..2 -> 0..2]]
====
