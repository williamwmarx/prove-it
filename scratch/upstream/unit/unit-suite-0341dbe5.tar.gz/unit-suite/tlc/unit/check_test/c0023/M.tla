(*---
{"description": "upstream unit case", "outcome": "any", "config": "CONSTANT m = m\nINIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Integers, TLC
CONSTANT m
VARIABLE x
ASSUME PrintT(<<1..3 \subseteq {1, 2}, 1..2 \subseteq {0, 1, 2, 5}, 2..1 \subseteq {}, 1..3 \subseteq {1, 2, 3}, 3..4 \subseteq {1, 2, 3}, 1..2 \subseteq 0..5, 1..2 \subseteq {m, 1, 2}, 1..3 \subseteq {m, 1, 2}, 0..1 \subseteq {m, 1, 2}>>)
Init == x = 0
Next == UNCHANGED x
====
