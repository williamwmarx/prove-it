(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nCHECK_DEADLOCK FALSE", "args": ["-coverage", "1"]}
---*)
---- MODULE E ----
EXTENDS Naturals
VARIABLES x, y
---- MODULE Inner ----
EXTENDS Naturals
VARIABLE z
Op(a) == /\ z < a
         /\ z' = z + 1
====
I == INSTANCE Inner WITH z <- x
Init == x = 0 /\ y = 0
Next == \/ I!Op(3)!1 /\ I!Op(3)!2 /\ y' = y
        \/ I!Op(2)!2 /\ x < 2 /\ y' = y
====
