(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals
a ^# == a = 1
a (+) b == <<a, b + 1>>
VARIABLE x
Init == x = 0
Next == x' = x
ASSUME ^#(2)!1 = 2
ASSUME (+)(1, 2)!>> = 3
ASSUME \oplus(4, 5)!<< = 4
====
