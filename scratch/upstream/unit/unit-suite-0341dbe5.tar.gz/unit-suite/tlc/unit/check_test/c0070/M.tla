(*---
{"description": "upstream unit case", "outcome": "any", "config": "CONSTANT G <- TLCGet\nINIT Init\nNEXT Next\nINVARIANT Inv\nCHECK_DEADLOCK FALSE"}
---*)
---- MODULE M ----
EXTENDS Integers, TLC
CONSTANT G(_)
VARIABLE x
Init == x = 0
Next == x < 2 /\ x' = x + 1
Inv == PrintT(G("level"))
====
