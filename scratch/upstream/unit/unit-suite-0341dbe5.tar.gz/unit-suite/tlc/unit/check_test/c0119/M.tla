(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec\nPROPERTY P1\nPROPERTY P2", "args": ["-coverage", "1"]}
---*)
---- MODULE M ----
EXTENDS Integers, TLC
VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1
Spec == Init /\ [][Next]_x
P1 == [][PrintT(<<"a", x, x'>>)]_x
P2 == [][x' <= 1]_x
====
