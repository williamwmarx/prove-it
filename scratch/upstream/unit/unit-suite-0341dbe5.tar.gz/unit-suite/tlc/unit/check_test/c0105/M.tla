(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv", "args": ["-coverage", "1"]}
---*)
---- MODULE M ----
EXTENDS Integers
VARIABLES x, z
Init == x \in BOOLEAN /\ z = 0
A1 == (~x => z = 1) /\ x' \in BOOLEAN /\ UNCHANGED z
A2 == z < 2 /\ z' = z + 1 /\ UNCHANGED x
Next == A1 \/ A2
Inv == ENABLED A1 \/ z < 5
====
