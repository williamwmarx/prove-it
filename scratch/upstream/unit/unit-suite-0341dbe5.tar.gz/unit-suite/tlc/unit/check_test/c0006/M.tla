(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec"}
---*)
---- MODULE M ----
Spec == [][TRUE]_<<>>
====
