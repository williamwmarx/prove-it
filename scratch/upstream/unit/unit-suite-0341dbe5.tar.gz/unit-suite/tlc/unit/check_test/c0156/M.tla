(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv"}
---*)
---- MODULE M ----
EXTENDS Integers
IsEven(v) == v % 2 = 0
VARIABLE v
Init == v = 0
Next == UNCHANGED v
Inv == IsEven(3)
====
