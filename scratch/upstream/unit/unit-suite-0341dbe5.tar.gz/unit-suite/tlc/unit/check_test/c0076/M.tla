(*---
{"description": "upstream unit case", "outcome": "any", "config": "CONSTANT C = FALSE\nSPECIFICATION Spec"}
---*)
---- MODULE M ----
CONSTANT C
VARIABLE x
Init == x = 0 /\ FALSE
Next == x' = x
Spec == Init /\ [][Next]_x
====
