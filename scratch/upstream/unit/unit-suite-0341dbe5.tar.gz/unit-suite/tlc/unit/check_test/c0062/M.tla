(*---
{"description": "upstream unit case", "outcome": "any", "config": "CONSTANTS a = a\nb = b\nINIT Init\nNEXT Next\nSYMMETRY Sym"}
---*)
---- MODULE M ----
EXTENDS TLC
CONSTANTS a, b
VARIABLE x
Init == x \in {a, b}
Next == UNCHANGED x
Swap == {(a :> b @@ b :> a)}
Sym == Swap
====
