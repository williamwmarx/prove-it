(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nCHECK_DEADLOCK FALSE"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences
VARIABLE x
Init == x = 0
A(p) == x < 2 /\ x' = x + 1 /\ PrintT(p)
Next == A(CounterExample)
====
