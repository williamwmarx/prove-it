(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv\nINVARIANT Inv2\nCHECK_DEADLOCK FALSE", "args": ["-seed", "4"]}
---*)
---- MODULE M ----
EXTENDS Integers, TLC, Randomization
VARIABLE x
Init == x = 0
Next == x < 2 /\ LET s == RandomSubset(1, 1..100) IN PrintT(<<"n", s, s>>) /\ x' = x + 1
Inv == LET s == RandomSubset(1, 1..100) IN PrintT(<<"i", s, s>>)
Inv2 == ENABLED (LET s == RandomSubset(1, 1..100) IN PrintT(<<"e", s, s>>) /\ x' = x)
====
