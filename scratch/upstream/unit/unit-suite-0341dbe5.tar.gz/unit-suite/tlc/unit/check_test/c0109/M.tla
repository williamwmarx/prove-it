(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nCHECK_DEADLOCK FALSE", "args": ["-coverage", "1"]}
---*)
---- MODULE M ----
EXTENDS Integers, TLC, FiniteSets, Sequences
VARIABLE x
Init == x = 0
Next == x' \in [{1} -> {t \in {3} \X {4, 5} : PrintT(t) /\ t[2] > 4}]
====
