(*---
{"description": "upstream unit case", "outcome": "any", "config": "CONSTANT Def = [M] 4\nINVARIANT Inv\nINIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Integers, TLC
VARIABLE x
Init == x = 0
Next == x' = x
Def == x
Inv == PrintT(Def)
====
