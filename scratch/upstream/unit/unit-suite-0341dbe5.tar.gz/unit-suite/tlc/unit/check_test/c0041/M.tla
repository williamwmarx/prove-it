(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nCONSTANT\n  F(0) = 1\n  F(1) = 2\n  F(2) = 2\nINVARIANT Inv"}
---*)
---- MODULE M ----
CONSTANT F(_)
VARIABLE x
Init == x = 0
Next == x' = F(x)
Inv == x /= 2
====
