(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
f == [v \in {1} |-> v]
A == [f EXCEPT ![[]x] = {<>x}]
B == [f EXCEPT !.a = 1, ![<>x][1] = {[]x}]
E == [f EXCEPT ![1] = [f EXCEPT ![[]x] = 2]]
Init == x = 0
Next == x' = x
====
