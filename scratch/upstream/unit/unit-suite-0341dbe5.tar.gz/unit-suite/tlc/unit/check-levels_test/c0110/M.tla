(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
---- MODULE P ----
CONSTANT c
VARIABLE v
====
N == INSTANCE P WITH c <- 1, v <- x
D1 == (x')'
ASSUME (x')' = 1
K == INSTANCE P WITH c <- (x')', v <- x
ASSUME (x')' = 2
D2 == (x')'
Init == x = 0
Next == x' = x
====
