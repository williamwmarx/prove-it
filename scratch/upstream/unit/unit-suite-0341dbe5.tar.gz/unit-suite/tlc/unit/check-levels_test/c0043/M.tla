(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
VARIABLE x
Ap(F(_), a) == F(a)
RECURSIVE R(_), S(_)
R(n) == IF n THEN TRUE ELSE S(n)
S(n) == Ap(LAMBDA v : R(v), n')
====
