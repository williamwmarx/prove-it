(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
CONSTANT d
THEOREM ASSUME NEW m \in []d, NEW n \in <>d PROVE TRUE
THEOREM TRUE
<1>1. SUFFICES ASSUME NEW k \in []d PROVE TRUE
  OBVIOUS
<1>2. QED
Init == x = 0
Next == x' = x
====
