(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE P ----
CONSTANT c
B == {c}
====
N == INSTANCE P WITH c <- 1
---- MODULE L ----
CONSTANT c
THEOREM T == ASSUME LET K == INSTANCE P IN K!B = {1} PROVE TRUE
====
I3 == INSTANCE L WITH c <- [](x = 1)
E == (I3!T!1)'
Init == x = 0
Next == x' = x
====
