(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE Q ----
CONSTANT c
VARIABLE w
A == c
====
---- MODULE L ----
CONSTANT k
D(a) == {a}
LOCAL INSTANCE Q WITH c <- D(k)!1, w <- 1
====
I == INSTANCE L WITH k <- x
Init == x = 0
Next == x' = x
====
