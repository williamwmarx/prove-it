(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
CONSTANT K
---- MODULE Inner ----
CONSTANT c
ASSUME c = {}
====
I == INSTANCE Inner WITH c <- [](x = 0)
Init == x = 0
Next == x' = x
====
