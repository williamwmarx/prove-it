(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE L ----
CONSTANT c
THEOREM T == ASSUME c = 1 PROVE TRUE
====
I(p) == INSTANCE L WITH c <- p
ASSUME I(x)!T
Init == x = 0
Next == x' = x
====
