(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE Inner ----
CONSTANT Op(_), k
K == Op(k)
====
I == INSTANCE Inner WITH Op <- LAMBDA p : 1, k <- x'
U == [](I!K)
W == LET L == INSTANCE Inner WITH Op <- LAMBDA p : 1, k <- x' IN [](L!K)
J == INSTANCE Inner WITH Op <- LAMBDA p : 1, k <- (x')'
Init == x = 0
Next == x' = x
====
