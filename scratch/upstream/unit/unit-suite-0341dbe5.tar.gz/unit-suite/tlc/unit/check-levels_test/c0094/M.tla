(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE L ----
VARIABLE v
D(r) == ((v' = r) /\ [](v = 1)) \/ FALSE
====
I3 == INSTANCE L WITH v <- x
E == (I3!D(1)!1)'
Init == x = 0
Next == x' = x
====
