(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
---- MODULE P ----
CONSTANT c, d
VARIABLE v
B == c
====
VARIABLE c, d
K == INSTANCE P WITH v <- x, d <- x'
Init == x = 0
Next == x' = x
====
