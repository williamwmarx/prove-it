(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE v, x
THEOREM T == ASSUME NEW CONSTANT q, (x' /\ []x) PROVE TRUE
<1>1. T!2 \/ TRUE
  OBVIOUS
<1> QED
Init == v = 0 /\ x = 0
Next == v' = v /\ x' = x
====
