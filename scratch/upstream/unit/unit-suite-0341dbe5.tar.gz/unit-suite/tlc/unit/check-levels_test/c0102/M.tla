(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
THEOREM T == ASSUME NEW CONSTANT q, \A y : l(y) :: (y = q) PROVE TRUE
<1>1. (T!l([](x = 1)))'
  OBVIOUS
<1> QED
Init == x = 0
Next == x' = x
====
