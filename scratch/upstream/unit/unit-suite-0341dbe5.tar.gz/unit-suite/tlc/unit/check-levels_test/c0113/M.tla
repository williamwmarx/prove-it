(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
---- MODULE P ----
CONSTANT zeta, a
VARIABLE v
B == a
====
VARIABLE zeta, a
K == INSTANCE P WITH v <- x
Init == x = 0
Next == x' = x
====
