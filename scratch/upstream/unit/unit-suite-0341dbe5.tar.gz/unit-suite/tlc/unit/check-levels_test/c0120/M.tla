(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
---- MODULE P ----
CONSTANT c
VARIABLE v
B == c
====
N == INSTANCE P WITH c <- 1, v <- x
D == LET K == INSTANCE P WITH v <- (x')', c <- (x'')'
          K2 == INSTANCE P WITH c <- (x')', v <- (x'')'
      IN K!B
Init == x = 0
Next == x' = x
====
