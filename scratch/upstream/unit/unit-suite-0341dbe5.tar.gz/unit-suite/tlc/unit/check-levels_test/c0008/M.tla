(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE Inner ----
CONSTANT k
VARIABLE z
K == k
====
I == INSTANCE Inner WITH k <- x, z <- x
D == LET L == INSTANCE Inner WITH k <- x, z <- x IN [](x')
E == [](x')
Init == x = 0
Next == x' = x
====
