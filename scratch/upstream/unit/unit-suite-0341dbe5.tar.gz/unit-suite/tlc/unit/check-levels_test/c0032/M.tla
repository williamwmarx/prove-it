(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE v
---- MODULE Inner ----
VARIABLE w
A == {[]w}
---- MODULE Deep ----
VARIABLE u
D == {[]u}
====
E == {<>w}
====
---- MODULE Other ----
VARIABLE w
O == {[]w}
====
I == INSTANCE Inner WITH w <- v
C == {I!A}
G == {[]v}
Init == v = 0
Next == v' = v
====
