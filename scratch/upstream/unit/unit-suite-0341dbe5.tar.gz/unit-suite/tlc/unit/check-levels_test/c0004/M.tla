(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
HiC(G(_)) == G(1) = 1
F == {HiC(LAMBDA p : [](x = p)) : v \in {1}}
Init == x = 0
Next == x' = x
====
