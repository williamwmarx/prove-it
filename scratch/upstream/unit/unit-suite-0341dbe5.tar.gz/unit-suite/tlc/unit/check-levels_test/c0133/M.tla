(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
B == \E b \in {x'} : b
THEOREM TRUE
<1>1. s :: (B /\ [](x = 1))
  <2>1. (<1>1!s)'
    OBVIOUS
  <2> QED
<1>2. (<1>1!s)'
  OBVIOUS
<1> D == ENABLED (<1>1!s)
<1>3. t :: ([](x = 1))
  OBVIOUS
<1> QED BY (<1>3!t)'
Init == x = 0
Next == x' = x
====
