(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
THEOREM T == ((lab :: ((x' = 1) /\ [](x = 1))) /\ TRUE) \/ FALSE
E0 == T!1!1
E == (T!1)'
Init == x = 0
Next == x' = x
====
