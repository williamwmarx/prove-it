(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
VARIABLE x
Ap(F(_), a) == F(a)
RECURSIVE R(_)
R(n) == IF n THEN TRUE ELSE Ap(LAMBDA v : R(v), n')
X == Ap(LAMBDA v : R(v), x')
====
