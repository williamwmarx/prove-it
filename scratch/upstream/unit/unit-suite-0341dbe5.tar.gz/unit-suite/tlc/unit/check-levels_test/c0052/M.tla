(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Sequences, TLC
VARIABLE x
F(s) == SelectSeq(s, LAMBDA a : a' = 1)
G == F(x')
Init == x = 0
Next == x' = x
====
