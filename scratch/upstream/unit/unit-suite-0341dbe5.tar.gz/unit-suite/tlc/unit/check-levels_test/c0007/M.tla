(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE Inner ----
CONSTANT Op(_), k
VARIABLE z
K == Op(k)
====
Eq(p) == p = 1
I == INSTANCE Inner WITH Op <- Eq, k <- [](x = 1), z <- x
U == I!K
J == INSTANCE Inner WITH Op <- Eq, k <- (x')', z <- x
Init == x = 0
Next == x' = x
====
