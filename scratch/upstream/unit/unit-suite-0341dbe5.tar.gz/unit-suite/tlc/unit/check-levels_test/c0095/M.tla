(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
D == ((lab :: ((x' = 1) /\ [](x = 1))) /\ TRUE) \/ FALSE
E == (D!1)'
Init == x = 0
Next == x' = x
====
