(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
THEOREM ASSUME NEW ACTION a PROVE TRUE
<1>1. a' = 1
  OBVIOUS
<1>2. ASSUME NEW ACTION b PROVE TRUE
  <2>1. b' = 1
    OBVIOUS
  <2> QED
<1>3. SUFFICES ASSUME NEW ACTION c PROVE TRUE
  OBVIOUS
<1>4. c' = 1
  OBVIOUS
<1> QED
THEOREM ASSUME NEW VARIABLE v PROVE [](x = 0)
<1> DEFINE D == x
<1>1. HAVE v = 1
<1>2. CASE D = 1
<1> QED
Init == x = 0
Next == x' = x
====
