(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
Pr(p) == p'
Prime(F(_), a) == F(a)'
D == Prime(Pr, []x)
Init == x = 0
Next == x' = x
====
