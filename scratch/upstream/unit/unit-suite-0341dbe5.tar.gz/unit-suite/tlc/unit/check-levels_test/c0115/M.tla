(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
---- MODULE P ----
CONSTANT Foo, Bar, Baz
VARIABLE v
B == Foo
====
VARIABLE Foo, Bar, Baz
K == INSTANCE P WITH v <- x
Init == x = 0
Next == x' = x
====
