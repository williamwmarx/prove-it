(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE Inner ----
CONSTANT Op(_), k
K == Op(k)
====
Pr(p) == p'
I == INSTANCE Inner WITH Op <- LAMBDA p : p, k <- 1
U == LET L(G(_)) == INSTANCE Inner WITH Op <- G, k <- x' IN L(Pr)!K
W(G(_)) == LET L == INSTANCE Inner WITH Op <- G, k <- x' IN L!K
V == W(Pr)
Init == x = 0
Next == x' = x
====
