(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE Inner ----
CONSTANT c
VARIABLE z
IZ == z
====
I0 == INSTANCE Inner WITH c <- 1, z <- x
THEOREM ASSUME NEW VARIABLE y PROVE LET N == INSTANCE Inner WITH c <- y, z <- x IN TRUE
THEOREM TRUE
<1>1. LET N == INSTANCE Inner WITH c <- x, z <- x IN TRUE
  OBVIOUS
<1> QED
THEOREM ASSUME NEW VARIABLE w PROVE TRUE
<1>1. LET N == INSTANCE Inner WITH c <- w, z <- x IN TRUE
  OBVIOUS
<1> QED
THEOREM U == LET N == INSTANCE Inner WITH c <- x, z <- x IN TRUE
Init == x = 0
Next == x' = x
====
