(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE Inner ----
CONSTANT c
VARIABLE z
IZ == z
====
I0 == INSTANCE Inner WITH c <- 1, z <- x
THEOREM ASSUME NEW VARIABLE y PROVE TRUE
<1> N == INSTANCE Inner WITH c <- y, z <- (x')'
<1>1. (x')' = 1
  OBVIOUS
<1> INSTANCE Inner WITH c <- x, z <- (x')'
<1>2. (x')' = 1
  OBVIOUS
<1> QED
Init == x = 0
Next == x' = x
====
