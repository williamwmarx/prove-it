(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
VARIABLE x
RECURSIVE R(_), S(_)
S(p) == {[]x}
R(p) == p' = 1 \/ R(p)
====
