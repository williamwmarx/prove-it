(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
Foo == [ab |-> 1, c |-> 2, ab |-> 3, c |-> 4]
Bar == [a : {1}, a : {2}]
Init == x = 0
Next == x' = x
====
