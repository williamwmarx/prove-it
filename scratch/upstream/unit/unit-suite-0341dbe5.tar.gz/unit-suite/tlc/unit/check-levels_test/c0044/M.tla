(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
VARIABLE x
A == []x
RECURSIVE R(_)
R(n) == IF n THEN {A!:} ELSE R(n)'
====
