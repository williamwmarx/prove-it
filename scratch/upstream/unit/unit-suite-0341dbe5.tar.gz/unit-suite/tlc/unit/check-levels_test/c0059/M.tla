(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
THEOREM ASSUME NEW y, []y PROVE <>y
<1>1. TAKE z \in {x}
<1>2. CASE []y
  <2>1. HAVE x = 4
  <2>2. QED
<1>3. PICK c \in {x} : <>(x = c)
<1>4. QED
Init == x = 0
Next == x' = x
====
