(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE In ----
VARIABLE v
B == \E b \in {v'} : b
THEOREM T == t :: (B /\ [](v = 1))
C == c :: ([](v = 1))
====
I == INSTANCE In WITH v <- x'
D == SF_I!T!t(x' = 1)
E == (I!C!c)'
Init == x = 0
Next == x' = x
====
