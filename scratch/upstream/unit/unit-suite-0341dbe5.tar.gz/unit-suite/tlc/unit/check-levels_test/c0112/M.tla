(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
---- MODULE P ----
CONSTANT ba, ab
VARIABLE v
B == ab
====
VARIABLE ab, ba
K == INSTANCE P WITH v <- x
Init == x = 0
Next == x' = x
====
