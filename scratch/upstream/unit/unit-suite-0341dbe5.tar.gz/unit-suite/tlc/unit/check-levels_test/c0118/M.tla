(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
---- MODULE P ----
CONSTANT c
VARIABLE v
====
N == INSTANCE P WITH c <- 1, v <- x
E == TRUE /\ TRUE
D == LET D1 == (x')'
          K == INSTANCE P WITH v <- (x')', c <- (x'')'
          D2 == E!1
      IN TRUE
Init == x = 0
Next == x' = x
====
