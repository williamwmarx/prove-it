(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
VARIABLE x
B == {[]x}
A == LET RECURSIVE F(_)
         F(n) == {<>x} \cup F(n)
     IN F(1)
====
