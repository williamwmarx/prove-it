(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE Inner ----
B == TRUE
====
I == INSTANCE Inner
RECURSIVE R(_)
R(n) == IF n THEN {[]x} ELSE I!B /\ R(n)'
====
