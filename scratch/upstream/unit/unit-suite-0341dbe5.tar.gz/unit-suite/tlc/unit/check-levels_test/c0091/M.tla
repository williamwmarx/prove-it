(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
---- MODULE L ----
CONSTANT c
Def == {<<y, c>> : y \in {1}}
====
VARIABLE y
I3 == INSTANCE L WITH c <- y
E == (I3!Def!(y'))'
Init == y = 0
Next == y' = y
====
