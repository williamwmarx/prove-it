(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
G == (x' = 2) /\ []x /\ TRUE
H == LET J == INSTANCE Naturals IN J!+(1, 2)
====
