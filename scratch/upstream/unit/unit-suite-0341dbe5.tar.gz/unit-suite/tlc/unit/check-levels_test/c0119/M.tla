(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
---- MODULE P ----
CONSTANT c
VARIABLE v
B == c
====
N == INSTANCE P WITH c <- 1, v <- x
D == LET D1 == (x')'
          K == INSTANCE P WITH v <- (x')', c <- (x'')'
          D2 == (x')'
      IN K!B
Init == x = 0
Next == x' = x
====
