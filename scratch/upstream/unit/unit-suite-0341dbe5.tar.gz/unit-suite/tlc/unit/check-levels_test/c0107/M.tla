(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
---- MODULE P ----
CONSTANT c
VARIABLE v
====
N == INSTANCE P WITH c <- 1, v <- x
THEOREM T == LET D1 == (x')'
          K == INSTANCE P WITH c <- (x')', v <- x
          D2 == (x')'
      IN TRUE
Init == x = 0
Next == x' = x
====
