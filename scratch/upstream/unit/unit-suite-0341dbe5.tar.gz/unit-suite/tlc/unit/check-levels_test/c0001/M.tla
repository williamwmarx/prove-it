(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
T == [](x = 1) /\ TRUE
F == \E v, w \in T!1 : TRUE
Init == x = 0
Next == x' = x
====
