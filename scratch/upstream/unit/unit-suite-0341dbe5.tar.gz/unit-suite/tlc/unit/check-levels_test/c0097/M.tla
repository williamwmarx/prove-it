(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
THEOREM T == ASSUME NEW CONSTANT q, ((lab :: ((x' = q) /\ [](x = 1))) /\ TRUE) PROVE TRUE
<1>1. (T!2)' \/ TRUE
  OBVIOUS
<1> QED
Init == x = 0
Next == x' = x
====
