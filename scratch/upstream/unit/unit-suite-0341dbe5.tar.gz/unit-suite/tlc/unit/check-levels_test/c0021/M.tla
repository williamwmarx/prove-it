(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE L ----
CONSTANT k
AXIOM X == k' = k
====
I1 == INSTANCE L WITH k <- x
I2 == INSTANCE L WITH k <- x'
I3 == INSTANCE L WITH k <- [](x = 1)
Init == x = 0
Next == x' = x
====
