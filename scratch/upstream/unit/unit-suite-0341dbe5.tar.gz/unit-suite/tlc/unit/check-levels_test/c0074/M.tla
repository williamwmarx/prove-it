(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE In ----
B == \E b \in {x'} : b
THEOREM T == t :: (B /\ [](x = 1))
C == c :: ([](x = 1))
====
I == INSTANCE In
J(p) == INSTANCE In
D == SF_I!T!t(x' = 1)
E == (J(1)!C!c)'
Init == x = 0
Next == x' = x
====
