(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x, v
---- MODULE In ----
VARIABLE v
THEOREM T == t :: ((v' = 1) /\ [](v = 1))
====
I == INSTANCE In
D == SF_I!T!t(x' = 1)
Init == x = 0
Next == x' = x
====
