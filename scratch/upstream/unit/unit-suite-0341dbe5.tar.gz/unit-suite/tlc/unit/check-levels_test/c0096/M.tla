(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE L ----
VARIABLE v
D == ((lab :: ((v' = 1) /\ [](v = 1))) /\ TRUE) \/ FALSE
====
I3 == INSTANCE L WITH v <- x
E0 == I3!D!1!1
E == (I3!D!1)'
Init == x = 0
Next == x' = x
====
