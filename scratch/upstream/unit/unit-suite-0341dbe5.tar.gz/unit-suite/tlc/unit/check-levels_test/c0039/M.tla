(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
VARIABLE x
RECURSIVE R(_)
R(p) == LET RECURSIVE F(_)
            F(n) == {[]x} \cup F(n) \cup R(n)
        IN F(p)
C == {<>x}
====
