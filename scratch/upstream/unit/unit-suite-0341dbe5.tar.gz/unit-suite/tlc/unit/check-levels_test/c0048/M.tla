(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
THEOREM TRUE
<1>1. {[]x} = 1
  <2>1. CASE {<>x} = 1
  <2> QED BY {[]x} = 1
<1> DEFINE D == {<>x}
<1>2. {D} = 1
<1> USE {[]x} = 1
<1> QED
USE {<>x} = 1
Init == x = 0
Next == x' = x
====
