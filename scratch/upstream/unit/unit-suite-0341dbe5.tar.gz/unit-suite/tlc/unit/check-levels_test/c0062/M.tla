(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
THEOREM ASSUME NEW TEMPORAL f PROVE TRUE
<1>1. CASE x = 1
  <2>1. TAKE y \in {x}
  <2> QED
<1>2. ASSUME NEW ACTION g PROVE TRUE
  <2>1. HAVE x = 1
  <2> QED
<1>3. ASSUME NEW TEMPORAL h PROVE TRUE
  <2>1. HAVE x = 1
  <2> QED
<1> QED
Init == x = 0
Next == x' = x
====
