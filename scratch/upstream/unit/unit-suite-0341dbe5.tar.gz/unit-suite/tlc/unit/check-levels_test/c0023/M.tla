(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE In ----
CONSTANT c
VARIABLE v
THEOREM T == v \in {c}
====
---- MODULE L ----
CONSTANT k
VARIABLE w
THEOREM ASSUME LET K == INSTANCE In WITH c <- w, v <- k IN TRUE PROVE TRUE
====
I == INSTANCE L WITH k <- x, w <- x
Init == x = 0
Next == x' = x
====
