(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
Pr(p) == p'
Ap(F(_), a) == F(a)
Ap2(F(_, _), a, b) == F(a, b)
OnPrime(F(_)) == F(x')
OnBox2(F(_, _)) == F([](x = 1), 1)
Twice(F(_), a) == F(F(a))
A == Ap(Pr, x')
B == OnPrime(Pr)
C == Twice(LAMBDA q : q' = q, x)
D == Ap(Pr, x)
E == OnBox2(\cup)
G == Ap2(\cup, [](x = 1), 1)
Init == x = 0
Next == x' = x
====
