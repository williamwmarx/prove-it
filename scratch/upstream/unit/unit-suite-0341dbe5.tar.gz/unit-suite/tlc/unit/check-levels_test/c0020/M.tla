(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE L0 ----
CONSTANT k
THEOREM k' = k
====
---- MODULE L ----
CONSTANT k
THEOREM TRUE
<1> DEFINE N == INSTANCE L0
<1> QED
====
I1 == INSTANCE L WITH k <- x
I2 == INSTANCE L WITH k <- x'
I3 == INSTANCE L WITH k <- [](x = 1)
Init == x = 0
Next == x' = x
====
