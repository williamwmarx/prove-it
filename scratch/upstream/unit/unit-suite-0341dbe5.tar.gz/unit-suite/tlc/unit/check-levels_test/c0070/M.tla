(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE Inner ----
CONSTANT c
VARIABLE z
IZ == z'
IC(a) == <<c, a>>
====
I0 == INSTANCE Inner WITH c <- 1, z <- x
THEOREM ASSUME NEW CONSTANT y PROVE TRUE
<1> N == INSTANCE Inner WITH c <- y, z <- x
<1>1. (N!IZ)' = 1
  OBVIOUS
<1>2. N!IC(x')' = 1
  OBVIOUS
<1> INSTANCE Inner WITH c <- 1, z <- x
<1>3. (IZ)' = 1
  OBVIOUS
<1>4. LET K == INSTANCE Inner WITH c <- y, z <- x IN (K!IZ)' = 1
  OBVIOUS
<1> QED
Init == x = 0
Next == x' = x
====
