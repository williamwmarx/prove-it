(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
A == (x' = x) /\ [](x = 1) /\ TRUE
B == ((x' = x)) \/ [](x = 1) \/ (x' = x)
C == ({[]x} = 1) /\ (x' = x) /\ []({<>x} = 1)
Init == x = 0
Next == x' = x
====
