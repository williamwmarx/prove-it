(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Sequences, TLC
VARIABLE x
F(s) == SortSeq(s, LAMBDA a, b : a' = b)
G == F(x')
Init == x = 0
Next == x' = x
====
