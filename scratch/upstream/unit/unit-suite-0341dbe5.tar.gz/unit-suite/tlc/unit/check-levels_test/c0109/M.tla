(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
---- MODULE P ----
CONSTANT c
VARIABLE v
THEOREM B == c = 1
====
N == INSTANCE P WITH c <- 1, v <- x
D1 == (x')'
THEOREM T0 == (x')' = 1
K == INSTANCE P WITH c <- (x')', v <- x
THEOREM T1 == (x')' = 1
D2 == (x')'
Init == x = 0
Next == x' = x
====
