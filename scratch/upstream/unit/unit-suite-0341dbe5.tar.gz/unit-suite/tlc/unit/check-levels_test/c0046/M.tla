(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
VARIABLE x
A == []x
ASSUME LET RECURSIVE F(_)
           F(n) == IF n THEN {A!:} ELSE F(n)'
       IN F(TRUE)
====
