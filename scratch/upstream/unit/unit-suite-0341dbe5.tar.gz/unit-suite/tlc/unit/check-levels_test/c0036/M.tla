(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
VARIABLE x
RECURSIVE R(_), S(_)
S(n) == R(n) \/ x' = 1
R(n) == S(n)
ASSUME R(1)
====
