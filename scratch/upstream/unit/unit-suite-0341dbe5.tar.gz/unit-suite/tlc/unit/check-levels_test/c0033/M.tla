(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
VARIABLE v
---- MODULE Inner ----
VARIABLE w
A == {[]w}
====
RECURSIVE R(_)
R(p) == {[]v} \cup R(p)
C == {<>v}
====
