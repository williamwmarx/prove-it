(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE v, x
THEOREM TRUE
<1>1. ASSUME NEW CONSTANT r, <>r PROVE TRUE
  <2>1. <1>1!2 \/ (v' = v)
    OBVIOUS
  <2> QED
<1> QED
Init == v = 0 /\ x = 0
Next == v' = v /\ x' = x
====
