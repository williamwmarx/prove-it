(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
ASSUME {<>x} = 1
THEOREM T == {<>x} = 1
  BY {[]x} = 1
ASSUME N == {[]x} = 1
THEOREM {[]x} = 1
A == {[]x}
Init == x = 0
Next == x' = x
====
