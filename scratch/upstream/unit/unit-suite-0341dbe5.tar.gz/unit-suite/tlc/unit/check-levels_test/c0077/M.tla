(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
CONSTANT k
---- MODULE In ----
CONSTANT k
THEOREM T == t :: ((k' = 1) /\ []TRUE)
====
I == INSTANCE In
D == SF_I!T!t(x' = 1)
Init == x = 0
Next == x' = x
====
