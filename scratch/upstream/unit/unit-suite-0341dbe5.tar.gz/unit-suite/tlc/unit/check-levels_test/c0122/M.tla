(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE L ----
CONSTANT c
THEOREM T == ASSUME NEW z, NEW w, c = 1 PROVE TRUE
====
INSTANCE L WITH c <- x
ASSUME T
Init == x = 0
Next == x' = x
====
