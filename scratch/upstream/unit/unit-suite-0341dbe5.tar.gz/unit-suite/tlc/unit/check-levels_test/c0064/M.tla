(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
Spec == x = 0 /\ [][x' = x]_x
L == []Spec!2!1
E == <>Spec!2!1
Init == x = 0
Next == x' = x
====
