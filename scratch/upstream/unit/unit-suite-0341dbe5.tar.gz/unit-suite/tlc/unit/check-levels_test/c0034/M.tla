(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
VARIABLE x
RECURSIVE R(_)
R(p) == IF p' = 1 THEN TRUE ELSE R(p)
====
