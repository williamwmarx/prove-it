(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
VARIABLE x
CONSTANT k
RECURSIVE R(_), S(_)
R(p) == k \cup (LET L == {x'} IN L)
S(p) == []x
====
