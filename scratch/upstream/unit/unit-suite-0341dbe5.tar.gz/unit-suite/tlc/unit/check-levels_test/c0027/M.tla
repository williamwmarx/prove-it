(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
A == x' /\ []x
B == x' \equiv []x
C ==
  /\ x'
  /\ []x
D == {x', []x}
E == \E v \in {[]x} : TRUE
G == [x EXCEPT ![1] = []x]
H == x[[]x, 1]
I == {v \in [](x = 1) : TRUE}
Init == x = 0
Next == x' = x
====
