(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
b == x' ~> []x
h == <>(x')
bar == [](x')
n == \A i \in {}, j \in x' : []x
Init == x = 0
Next == x' = x
====
