(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE L ----
CONSTANT c
THEOREM T == ASSUME NEW z, c = 1 PROVE z = z
====
I == INSTANCE L WITH c <- x
ASSUME I!T
Init == x = 0
Next == x' = x
====
