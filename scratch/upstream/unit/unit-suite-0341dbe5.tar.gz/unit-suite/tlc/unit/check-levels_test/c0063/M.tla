(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
THEOREM ASSUME NEW TEMPORAL F, NEW k \in F PROVE TRUE
THEOREM ASSUME NEW ACTION A, NEW j \in A PROVE TRUE
Init == x = 0
Next == x' = x
====
