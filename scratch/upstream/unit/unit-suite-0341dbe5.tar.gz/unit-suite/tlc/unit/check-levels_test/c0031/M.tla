(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
A == {[]x} \cup {<>x}
B == {A}
L == LET P == {[]x} IN {<>x} \cup P
E == \E v \in {[]x} : {<>x} = v
ASSUME {[]x} = {<>x}
THEOREM ASSUME NEW e \in {[]x}, NEW f \in {<>x} PROVE TRUE
Init == x = 0
Next == x' = x
====
