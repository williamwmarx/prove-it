(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
---- MODULE P ----
CONSTANT q, r, s, t
VARIABLE v
B == q
====
VARIABLE t, s, r, q
K == INSTANCE P WITH v <- x
Init == x = 0
Next == x' = x
====
