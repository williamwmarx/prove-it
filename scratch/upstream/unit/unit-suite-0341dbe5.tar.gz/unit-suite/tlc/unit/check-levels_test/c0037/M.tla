(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
VARIABLE x
RECURSIVE R(_)
X(p) == R(p)
R(p) == {[]x} \cup X(p)
ASSUME X(1)
====
