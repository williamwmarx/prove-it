(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE In ----
VARIABLE v
T == t :: (v' = 1)
THEOREM U == u :: (v' = 1)
====
I == INSTANCE In WITH v <- x'
E == I!T!t
F == I!U!u
Init == x = 0
Next == x' = x
====
