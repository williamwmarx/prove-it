(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE L ----
CONSTANT c
THEOREM T == ASSUME NEW z PROVE c = 1
====
INSTANCE L WITH c <- x
ASSUME T
Init == x = 0
Next == x' = x
====
