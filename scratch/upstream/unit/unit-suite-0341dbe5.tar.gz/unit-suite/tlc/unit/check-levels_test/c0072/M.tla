(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
B == \E b \in {x'} : b
THEOREM T == t :: (B /\ [](x = 1))
<1>1. SF_T!t(x' = 1)
  OBVIOUS
<1> QED
D == SF_T!t(x' = 1)
D2 == SF_T!t(x' = 1)
Init == x = 0
Next == x' = x
====
