(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE Inner ----
VARIABLE y
Foo == y' = 0
====
I(z) == INSTANCE Inner WITH y <- z
FooBar == I(x')!Foo
Init == x = 0
Next == x' = x
====
