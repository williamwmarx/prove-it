(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
THEOREM [](x = 0)
<1>1. HAVE x = 1
<1>2. QED
---- MODULE Inner ----
CONSTANT c
ASSUME c = {}
====
I == INSTANCE Inner WITH c <- [](x = 0)
Init == x = 0
Next == x' = x
====
