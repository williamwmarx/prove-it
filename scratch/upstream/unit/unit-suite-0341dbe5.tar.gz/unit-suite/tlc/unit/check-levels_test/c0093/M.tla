(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
D(r) == ((x' = r) /\ [](x = 1)) \/ FALSE
E == (D(1)!1)'
Init == x = 0
Next == x' = x
====
