(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS _Possible
VARIABLE x
F == _CheckName([](x = 1))
G == _Track(TRUE, []x)
H == [](_Track(x' = 1, "n"))
Init == x = 0
Next == x' = x
====
