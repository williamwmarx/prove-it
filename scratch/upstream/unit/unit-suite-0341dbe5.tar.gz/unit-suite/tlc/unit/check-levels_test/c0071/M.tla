(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
B == \E b \in {x'} : b
THEOREM T == t :: (B /\ [](x = 1))
D == T!t /\ (x' = 1 /\ [](x = 1))
Init == x = 0
Next == x' = x
====
