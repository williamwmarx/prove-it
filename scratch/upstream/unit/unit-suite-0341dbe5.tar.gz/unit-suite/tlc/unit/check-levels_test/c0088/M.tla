(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE P ----
CONSTANT c, e
B == {c}
====
N == INSTANCE P WITH c <- 1, e <- 1
---- MODULE L ----
CONSTANT c
S(p) == <<p, 2>>
THEOREM T == ASSUME TRUE PROVE LET K == INSTANCE P WITH e <- S(1)!1 IN K!B = {1}
====
I3 == INSTANCE L WITH c <- [](x = 1)
E == (I3!T!2)'
Init == x = 0
Next == x' = x
====
