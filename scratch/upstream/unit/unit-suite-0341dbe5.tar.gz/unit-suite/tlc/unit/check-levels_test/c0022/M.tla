(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
---- MODULE L ----
CONSTANT k
ASSUME k /\ TRUE
====
I == INSTANCE L WITH k <- [](x = 1)
Init == x = 0
Next == x' = x
====
