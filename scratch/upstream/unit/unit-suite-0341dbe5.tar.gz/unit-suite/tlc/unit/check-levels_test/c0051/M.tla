(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
ASSUME x' = x
ASSUME x = 1
Init == x = 0
Next == x' = x
====
