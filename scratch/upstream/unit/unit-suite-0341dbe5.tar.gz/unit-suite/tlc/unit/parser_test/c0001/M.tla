(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
a == TRUE
e == FALSE
S == {TRUE}
ASSUME {a, e \in S} = {TRUE, FALSE}
ASSUME {a, e, a \in S} = {TRUE, FALSE}
ASSUME {<<a, e>> \in {<<TRUE, FALSE>>}} = {TRUE}
ASSUME {<<1, 2>> \in {}} = {FALSE}
====
