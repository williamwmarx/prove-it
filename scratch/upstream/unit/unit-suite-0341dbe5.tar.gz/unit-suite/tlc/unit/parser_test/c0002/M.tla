(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
EXTENDS Naturals
f[v \in LET N == {1, 2} IN N] == v + 1
D == LET g[w \in {LET K == 3 IN K}] == w IN g[3]
ASSUME f[2] = 3 /\ D = 3
====
