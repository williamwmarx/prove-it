(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nPOSTCONDITION Post"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
Next == x < 1 /\ x' = x + 1
Post == PrintT("post") /\ [[a |-> 1] EXCEPT !.b = TLCGet("level")].a = 1
====
