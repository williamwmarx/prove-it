(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv\nINVARIANT Bound\nPOSTCONDITION Post"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt
VARIABLES x, s, r
Init == x = 0 /\ s = 0 /\ r = 0
Next == x < 2 /\ x' = x + 1 /\ UNCHANGED <<s, r>>
Inv == x < 2 \/ PrintT(ToString(Trace))
Bound == x < 2
Post == PrintT(ToString(CounterExample.state))
====
