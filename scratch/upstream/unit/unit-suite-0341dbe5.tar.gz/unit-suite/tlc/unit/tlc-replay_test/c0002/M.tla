(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv", "args": ["-continue"]}
---*)
---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, FiniteSets
VARIABLE x
Name == <<"zero", "one">>
Rec == [a |-> 1, b |-> 2]
Map == 1 :> "a" @@ 2 :> "b"
Op(i) == Name[i]
Init == x = 0
Next == x' = x + 1
Inv == x < 2 \/ Assert(FALSE, "bound")
====
