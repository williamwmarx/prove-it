(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, FiniteSets
VARIABLE x
Name == <<"zero", "one">>
Rec == [a |-> 1, b |-> 2]
Map == 1 :> "a" @@ 2 :> "b"
Op(i) == Name[i]
Init == \E i \in 1..3 : i < 3 => x = i
Next == x' = x
====
