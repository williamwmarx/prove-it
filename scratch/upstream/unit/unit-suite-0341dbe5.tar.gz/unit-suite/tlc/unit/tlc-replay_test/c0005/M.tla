(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv0\nINVARIANT Inv1", "args": ["-continue"]}
---*)
---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, FiniteSets
VARIABLE x
Name == <<"zero", "one">>
Rec == [a |-> 1, b |-> 2]
Map == 1 :> "a" @@ 2 :> "b"
Op(i) == Name[i]
Init == x \in 1..3
Next == x' = x
Inv0 == x > 5
Inv1 == x # 2 \/ CHOOSE e \in {} : TRUE
====
