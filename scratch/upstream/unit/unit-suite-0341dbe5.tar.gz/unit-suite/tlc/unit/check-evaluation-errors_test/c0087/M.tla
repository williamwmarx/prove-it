(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nPOSTCONDITION Post"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0 /\ TLCSet(1, 0) /\ PrintT(<<"i", TLCGet(1)>>)
Next == TLCSet(1, TLCGet(1) + 1) /\ PrintT(<<"n", TLCGet(1)>>) /\ x' = IF TLCGet(1) = 1 THEN (x /\ TRUE) ELSE x
Post == PrintT(<<"post", TLCGet(1)>>)
====
