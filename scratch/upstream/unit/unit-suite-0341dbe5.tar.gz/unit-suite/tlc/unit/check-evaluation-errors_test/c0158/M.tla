(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv\nVIEW View"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLES x, y
Init == x \in 0..1 /\ y \in {0, 1} /\ (x = 0 \/ <<x>>[3] = 0)
Next == UNCHANGED <<x, y>>
Inv == y = 0
View == x
====
