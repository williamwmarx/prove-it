(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
EXTENDS Integers, FiniteSets, TLC
ASSUME PrintT([b |-> 0])
ASSUME PrintT([s \in SUBSET {1} |-> 1 \div Cardinality(s)][{1}])
ASSUME PrintT([v \in {0} |-> [a |-> 1, b |-> 2]])
ASSUME PrintT([v \in SUBSET {0} |-> [a |-> 1, b |-> 2]])
ASSUME PrintT([v \in {0} \X {1} |-> [a |-> 1, b |-> 2]])
====
