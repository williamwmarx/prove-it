(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec\nPROPERTY Prop"}
---*)
---- MODULE M ----
VARIABLES x, z
Init == x = 0 /\ z = FALSE
A0 == x' = 0
A1 == x' = 0
Next == A0 \/ A1
Spec == Init /\ [][Next]_<<x, z>> /\ WF_<<x, z>>(A1)
Prop == []<>z
====
