(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv", "args": ["-coverage", "1"]}
---*)
---- MODULE M ----
EXTENDS Integers
VARIABLE v
fib[n \in 0..3] == IF n < 2 THEN n ELSE fib[n - 1] + fib[n - 2]
Init == v = 0
Next == UNCHANGED v
Inv == v = 0 /\ fib[7] = 1
====
