(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Integers, FiniteSets, TLC
VARIABLES x, y
Init == x = 0 /\ y = 0
Next == LET U(v) == UNCHANGED v IN x' = {1} /\ U(x) /\ y' = 0
====
