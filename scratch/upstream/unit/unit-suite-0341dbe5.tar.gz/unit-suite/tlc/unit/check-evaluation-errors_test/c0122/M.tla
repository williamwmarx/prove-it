(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nACTION_CONSTRAINT BadA", "args": ["-coverage", "1"]}
---*)
---- MODULE M ----
EXTENDS Integers, TLC
VARIABLE v
Init == v = 0
Next == v' = 1 - v
Bad == PrintT("a") /\ v \div 0 = 1
BadA == PrintT("a") /\ v' \div 0 = 1
Prop == [][BadA]_v
====
