(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
Op(a) == a + 1
Init == CASE 1 -> x = 0
Next == x' = x
====
