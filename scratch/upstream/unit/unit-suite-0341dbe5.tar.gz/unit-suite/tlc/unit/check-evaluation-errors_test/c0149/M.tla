(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Integers
VARIABLE x
Init == x = 0
Next == x' = IF x = 1 THEN {1} \X 2 ELSE x + 1
====
