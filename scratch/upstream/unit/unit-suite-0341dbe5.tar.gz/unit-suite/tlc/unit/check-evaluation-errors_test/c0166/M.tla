(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
EXTENDS Integers
fib[n \in 0..3] == IF n < 2 THEN n ELSE fib[n - 1] + fib[n - 2]
Foo == fib[7] = 1
ASSUME Foo
====
