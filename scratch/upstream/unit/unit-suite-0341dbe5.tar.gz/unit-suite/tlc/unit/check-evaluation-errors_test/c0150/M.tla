(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv\nCHECK_DEADLOCK FALSE", "args": ["-maxSetSize", "10"]}
---*)
---- MODULE M ----
EXTENDS Integers
VARIABLES x, y
Init == x = 0 /\ y = 0
Next == x < 3 /\ x' = x + 1 /\ y' \in [{1, 2} -> SUBSET (1..(x + 1))]
Inv == x < 3
====
