(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLES x, y, z
vars == <<x, y>>
Init == x = 0 /\ y = 0 /\ z = 0
Next ==
  \/ z' = (z + 1) % 3 /\ UNCHANGED <<vars, <<x>>>>
  \/ y' \in {y, 1} /\ UNCHANGED <<<<z>>, vars>>
  \/ x < 2 /\ x' = x + 1 /\ UNCHANGED <<z, <<y>>, x>>
  \/ x < 2 /\ x' = x + 1 /\ UNCHANGED <<z, y>>
====
