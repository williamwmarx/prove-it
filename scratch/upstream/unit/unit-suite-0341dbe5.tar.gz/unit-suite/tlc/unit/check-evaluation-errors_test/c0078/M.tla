(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Integers, FiniteSets, TLC
VARIABLE x
Init == x = 0
Next == x' = {1} /\ UNCHANGED <<x, x>>
====
