(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
EXTENDS TLC
ASSUME PrintT([fld2 |-> 0])
ASSUME PrintT(ToString([fld1 |-> 1, fld2 |-> 2]))
ASSUME PrintT(ToString(("fld1" :> 1) @@ ("fld3" :> 3) @@ ("fld2" :> 2)))
ASSUME PrintT([fld1 |-> 1, fld2 |-> 2])
====
