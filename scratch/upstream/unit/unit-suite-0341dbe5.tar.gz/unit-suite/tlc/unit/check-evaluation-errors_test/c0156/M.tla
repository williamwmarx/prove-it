(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals, Bags
VARIABLE x
Init == x = 0
Next == x' = x /\ SubBag(x) = {}
====
