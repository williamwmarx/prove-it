(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Integers, FiniteSets, TLC
VARIABLE x
Init == x = 0
Next == LET P(t) == PrintT(t) IN x' \in (((1..2) \cup {t \in (1..2) \X {0} : P(t) /\ IF t[1] = 2 THEN 1 = "a" ELSE TRUE}) \X SUBSET {1, "a"})
====
