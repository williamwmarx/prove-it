(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
EXTENDS Integers, Randomization
ASSUME RandomSubset(-1, {1}) = {}
====
