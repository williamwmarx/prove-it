(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
Init == x = 0
Next == x' = [j \in {1} |-> [k \in {1, 2} |-> k \div 0]]
====
