(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec\nPROPERTY P"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
Init == x = 0
A == IF x THEN x' = x ELSE x' = 1
Spec == Init /\ [][x' = x]_x /\ WF_x(A)
P == <>(x = 0)
====
