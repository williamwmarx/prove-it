(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
Op(a) == a + 1
Init == IF 1 THEN x = 0 ELSE x = 1
Next == x' = x
====
