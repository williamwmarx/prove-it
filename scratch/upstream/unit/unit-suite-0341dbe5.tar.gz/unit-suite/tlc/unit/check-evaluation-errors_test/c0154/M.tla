(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Integers, Sequences
VARIABLE x
Init == x = 0
Next == SelectSeq(<<1>>, LAMBDA k : {x} = <<x>>) = <<>> /\ x' = x
====
