(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
Init == x = 0
Filter == {n \in SUBSET {1} : 1 \div 0 = 1}
Next == x' = 1 /\ {1} # Filter
====
