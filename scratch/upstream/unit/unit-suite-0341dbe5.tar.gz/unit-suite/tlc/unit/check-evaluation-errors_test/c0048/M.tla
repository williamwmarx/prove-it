(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
Init == x = 0
Next == x' = [k \in Nat |-> k \div 0][1]
====
