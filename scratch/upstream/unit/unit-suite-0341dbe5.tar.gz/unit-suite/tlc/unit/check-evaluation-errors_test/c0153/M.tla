(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLCExt
VARIABLE x
Init == x = 0
Next == x' = x /\ AssertError("m", 1 \div 0) = 0
====
