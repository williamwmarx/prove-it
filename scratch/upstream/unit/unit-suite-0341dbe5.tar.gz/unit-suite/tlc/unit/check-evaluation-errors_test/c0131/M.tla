(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
EXTENDS Integers, TLC
ASSUME \A i \in 1..3 : TLCEval(Print("a", 7)) = 7
====
