(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nPROPERTY Prop"}
---*)
---- MODULE M ----
EXTENDS TLC
VARIABLE y
Init == y = 0
A == y' = 0 /\ PrintT("A")
Next == A
Prop == [](ENABLED A => <>FALSE)
====
