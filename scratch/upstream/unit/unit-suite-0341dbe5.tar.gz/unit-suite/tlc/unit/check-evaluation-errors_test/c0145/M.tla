(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Integers, TLC
VARIABLES x, y
Init == x = 0 /\ y = 0
A == PrintT(<<"a", x>>) /\ x' = x + 1 /\ (x > 0 \/ y' = 0)
Next == A
====
