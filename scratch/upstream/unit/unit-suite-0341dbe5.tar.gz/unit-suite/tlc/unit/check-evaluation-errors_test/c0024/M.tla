(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
U == ({"t0"} \X {0}) \cup {"null"}
Init == x = "none"
Next == \E t \in U : x' = t
====
