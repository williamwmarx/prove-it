(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next", "args": ["-maxSetSize", "10"]}
---*)
---- MODULE M ----
EXTENDS Integers, FiniteSets
VARIABLE x
F[r \in {s \in [a : 1..4, b : 1..4] : TRUE}] == IF r.a = 1 THEN 1 ELSE F[[a |-> 1, b |-> r.b]]
Init == x = 0
Next == x' = F
====
