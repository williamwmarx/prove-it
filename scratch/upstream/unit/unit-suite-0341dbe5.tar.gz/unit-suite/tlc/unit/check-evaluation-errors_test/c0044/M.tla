(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
Init == x = [k \in {1, 2} |-> k \div 0]
Next == x' = x
====
