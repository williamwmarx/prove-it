(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nCONSTRAINT C"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0 /\ TLCSet(1, 0)
Next == \E b \in {1, 2} : TLCSet(1, TLCGet(1) + 1) /\ PrintT(<<"n", b, TLCGet(1)>>) /\ x' = x + b
C == IF x = 2 /\ TLCGet(1) \in {2, 6} THEN 1 \in 2 ELSE TRUE
====
