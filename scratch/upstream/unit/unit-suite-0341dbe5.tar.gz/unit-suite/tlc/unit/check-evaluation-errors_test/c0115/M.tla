(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv", "args": ["-coverage", "None"]}
---*)
---- MODULE M ----
EXTENDS Integers
VARIABLES x, y
Init == x = 0 /\ y = 0
Next == x' = 1 - x /\ UNCHANGED y
Op(v) == v
Inv == ENABLED (x' = 1 /\ UNCHANGED Op(x))
====
