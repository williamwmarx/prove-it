(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv\nCHECK_DEADLOCK FALSE"}
---*)
---- MODULE M ----
EXTENDS Integers, TLC
VARIABLE x
D == TLCEval(Print("d", TRUE)) /\ x >= 0
D2 == D
Init == x = 0
Next == x < 2 /\ x' = x + 1
Inv == /\ \A i \in 1..2 : D
       /\ \A i \in 1..2 : D2
       /\ D
====
