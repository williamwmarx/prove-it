(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Integers, FiniteSets, TLC
VARIABLE x
Init == x = 0
Next == x' \in (((1..2) \cup {t \in (1..2) \X {0} : IF t[1] = 2 THEN 1 = "a" ELSE TRUE}) \X SUBSET {1, "a"})
====
