(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Naturals, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = CHOOSE n \in ({1} \cup 2) : TRUE
====
