(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec\nPROPERTY Prop", "args": ["-coverage", "None"]}
---*)
---- MODULE M ----
EXTENDS Integers
VARIABLES x, y, z
Init == x = 0 /\ y = 0 /\ z = 0
Next == x' = 1 - x /\ UNCHANGED <<y, z>>
A == y' = y /\ UNCHANGED (x + 1)
Spec == Init /\ [][Next]_<<x, y, z>> /\ WF_<<x, y, z>>(A)
Prop == <>(x = 5)
====
