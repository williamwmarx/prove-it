(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Integers
VARIABLES x, y
Init == x = 0 /\ y = 0
Next == x' = 1 /\ y' = (TRUE /\ 2 /\ TRUE /\ TRUE)
====
