(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv\nCHECK_DEADLOCK FALSE"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0 /\ TLCSet(1, 0)
Next == x < 3 /\ \E b \in {1, 2} : TLCSet(1, TLCGet(1) + 1) /\ PrintT(<<"n", x, TLCGet(1)>>) /\ x' = IF TLCGet(1) = 8 THEN (x /\ TRUE) ELSE x + b
Inv == IF x = 4 /\ TLCGet(1) = 6 THEN 1 \in 2 ELSE TRUE
====
