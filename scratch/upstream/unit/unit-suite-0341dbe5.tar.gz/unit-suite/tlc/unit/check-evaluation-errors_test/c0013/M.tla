(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
Init == x = 0
Next == CASE x = 5 -> x' = 0
  [] x = 6 -> x' = 1
====
