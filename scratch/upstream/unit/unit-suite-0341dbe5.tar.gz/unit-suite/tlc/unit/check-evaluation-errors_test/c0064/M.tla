(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Integers
VARIABLES x, y
Init == x = 0 /\ y = 0
Next == LET m == y IN (y' = 1 /\ UNCHANGED m /\ x' = x)
====
