(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nCHECK_DEADLOCK FALSE"}
---*)
---- MODULE M ----
EXTENDS Integers, FiniteSets, TLC
VARIABLE x
Init == x = 0
Next == x < 2 /\ x' = x + 1 /\ PrintT({{{}}} # {{0}})
====
