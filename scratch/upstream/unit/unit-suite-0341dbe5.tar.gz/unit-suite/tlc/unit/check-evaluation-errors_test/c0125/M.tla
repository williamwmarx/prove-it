(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec\nINVARIANT Inv\nPROPERTY Live"}
---*)
---- MODULE M ----
VARIABLE x
Init == x = 0
A == x' = 0
Next == A \/ x' = 1
Spec == Init /\ [][Next]_x
Inv == x # 1
Live == [](ENABLED A => <>FALSE)
====
