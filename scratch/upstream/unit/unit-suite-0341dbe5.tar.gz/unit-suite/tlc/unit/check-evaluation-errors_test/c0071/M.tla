(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Integers, FiniteSets, TLC
VARIABLES x, y
Init == x = 0 /\ y = 0
Next == x' = "a" /\ y' = 0 /\ UNCHANGED x
====
