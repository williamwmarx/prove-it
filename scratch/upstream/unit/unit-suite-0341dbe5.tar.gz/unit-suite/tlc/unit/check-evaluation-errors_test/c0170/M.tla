(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Integers
VARIABLE x
Init == x = 0
Next == x' = x /\ \E e \in [{1, 2} -> {9} \cup {t \in (1..2) \X {0} : t[1] > 0}] : FALSE
====
