(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Integers
VARIABLE x
Init == x = 0
Next == [i \in 0..2, j \in 1..2 |-> x' = x + i][1 \div x, 1]
====
