(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec\nPROPERTY Prop\nACTION_CONSTRAINT Constraint"}
---*)
---- MODULE M ----
EXTENDS Sequences
VARIABLES x, z
Init == x = <<0>> /\ z = 0
A0 == x' = x
A1 == x' = x /\ (Tail(x) /\ TRUE) /\ z' = z
Next == A0 \/ A1
Spec == Init /\ [][Next]_<<x, z>>
Prop == [](z = 0 => (z = 0 ~> x = <<>>))
Constraint == x' /= x
====
