(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nCHECK_DEADLOCK FALSE"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0 /\ TLCSet(1, 0)
Next == TLCSet(1, TLCGet(1) + 1) /\ x' = IF TLCGet(1) = 1 THEN x /\ TRUE ELSE x
====
