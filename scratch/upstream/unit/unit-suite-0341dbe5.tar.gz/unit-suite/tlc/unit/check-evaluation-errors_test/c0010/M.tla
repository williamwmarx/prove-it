(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv"}
---*)
---- MODULE M ----
EXTENDS TLC
VARIABLE x
Init == x = "a" :> 1
Next == UNCHANGED x
Inv == x = {}
====
