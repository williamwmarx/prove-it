(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec\nPROPERTY Live"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
Init == x = 0
A == (\E k \in {1} \cup SUBSET 3 : TRUE) /\ x' = x
Spec == Init /\ [][A]_x /\ SF_x(A)
Live == <>(x = 0)
====
