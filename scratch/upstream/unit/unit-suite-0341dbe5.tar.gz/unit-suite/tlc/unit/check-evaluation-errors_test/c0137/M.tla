(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv\nCHECK_DEADLOCK FALSE"}
---*)
---- MODULE M ----
EXTENDS Integers, TLC
VARIABLE x
L == LET a == TLCEval(Print("a", TRUE))
         b == TLCEval(Print("b", TRUE))
         RECURSIVE r(_)
         r(n) == IF n = 0 THEN 0 ELSE r(n - 1)
         c == TLCEval(Print("c", TRUE))
     IN a /\ b /\ c /\ r(1) = 0 /\ x >= 0
Init == x = 0
Next == x < 2 /\ x' = x + 1
Inv == L
====
