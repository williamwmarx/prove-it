(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Integers, TLC
VARIABLE x
Init == x = 0
A == PrintT(<<"a", x>>) /\ x \in 0..1 /\ x' = x + 5
B == PrintT(<<"b", x>>) /\ x' = IF x = 1 THEN [k \in SUBSET {1} |-> 1 \div 0] ELSE x + 1
Next == A \/ B
====
