(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec\nPROPERTY P"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
Init == x = 0
A == CASE x -> x' = x
Spec == Init /\ [][x' = x]_x /\ WF_x(A)
P == <>(x = 0)
====
