(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv"}
---*)
---- MODULE M ----
EXTENDS TLC
VARIABLE v
Init == v = 0
Next == UNCHANGED v
Inv == TLCEval(Print(v, TRUE))
====
