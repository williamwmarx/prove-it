(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Integers
VARIABLE x
Init == x = SUBSET (SUBSET (1..36))
Next == x' = x
====
