(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv\nCHECK_DEADLOCK FALSE"}
---*)
---- MODULE M ----
EXTENDS Integers, TLC
VARIABLE x
L == LET a == TLCEval(Print("a", TRUE))
         b == TLCEval(Print("b", TRUE))
     IN a /\ b /\ x >= 0
Init == x = 0
Next == x < 2 /\ x' = x + 1
Inv == L
====
