(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
ASSUME TRUE
====
