(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv"}
---*)
---- MODULE M ----
EXTENDS Integers, TLC
VARIABLE x
Op(G(_)) == TLCEval(Print(G("o"), TRUE))
Init == x = 0
Next == x < 2 /\ x' = x + 1
Inv == x >= 0 /\ LET F(a) == a IN TLCEval(Print(F("l"), TRUE)) /\ Op(F)
====
