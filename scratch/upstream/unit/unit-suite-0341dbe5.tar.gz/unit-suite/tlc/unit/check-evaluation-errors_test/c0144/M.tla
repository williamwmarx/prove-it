(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next", "args": ["-continue"]}
---*)
---- MODULE M ----
VARIABLES x, y
Init == x = 0 /\ y = 0
Next == x' = 1
====
