(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv"}
---*)
---- MODULE M ----
VARIABLE x
Init == x = 0
Next == x' = 1
Inv == ENABLED (Next \cdot Next)
====
