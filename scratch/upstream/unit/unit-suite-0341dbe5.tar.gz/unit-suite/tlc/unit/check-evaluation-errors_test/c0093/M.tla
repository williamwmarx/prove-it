(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nCONSTANT N <- Len"}
---*)
---- MODULE M ----
EXTENDS Integers, Sequences, FiniteSets, TLC, Bags, Json
CONSTANT N
VARIABLE x
Init == x = N
Next == x' = x
====
