(*---
{"description": "upstream unit case", "outcome": "any", "config": ""}
---*)
---- MODULE M ----
EXTENDS Sequences
ASSUME Append(1, 2) = 0
====
