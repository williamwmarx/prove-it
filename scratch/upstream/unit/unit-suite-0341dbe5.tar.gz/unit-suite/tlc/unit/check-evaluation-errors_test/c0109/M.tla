(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec\nPROPERTY P"}
---*)
---- MODULE M ----
EXTENDS Naturals
VARIABLE x
Init == x = 0
A == x' \in Nat
Spec == Init /\ [][x' = x]_x /\ WF_x(A)
P == <>(x = 0)
====
