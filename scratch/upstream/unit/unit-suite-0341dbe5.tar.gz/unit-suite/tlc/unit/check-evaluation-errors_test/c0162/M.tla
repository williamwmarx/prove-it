(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLES x, y
Init == y = x /\ x = 0
Next == UNCHANGED <<x, y>>
====
