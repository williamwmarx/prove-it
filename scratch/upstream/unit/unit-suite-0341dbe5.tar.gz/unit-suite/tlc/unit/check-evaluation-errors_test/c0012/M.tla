(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
VARIABLE x
ASSUME CASE 1 = 2 -> 3
Init == x = 0
Next == UNCHANGED x
====
