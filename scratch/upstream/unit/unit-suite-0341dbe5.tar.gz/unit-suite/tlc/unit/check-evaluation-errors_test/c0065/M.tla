(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Integers
VARIABLES x, y
Zy == y
Init == x = 0 /\ y = 0
Next == y' = 1 /\ UNCHANGED Zy /\ x' = x
====
