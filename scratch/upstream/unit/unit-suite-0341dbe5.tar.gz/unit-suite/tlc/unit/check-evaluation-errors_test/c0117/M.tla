(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv", "args": ["-coverage", "None"]}
---*)
---- MODULE M ----
EXTENDS Integers
VARIABLE x
Init == x = 0
Next == x' = x
Op(v) == v
Inv == ENABLED (UNCHANGED Op(x))
====
