(*---
{"description": "upstream unit case", "outcome": "any", "config": "SPECIFICATION Spec\nPROPERTY Prop"}
---*)
---- MODULE M ----
VARIABLES x, y
Init == x = 0 /\ y = 0
A == x' = CHOOSE t \in {0, 1} : t /= x /\ UNCHANGED y
Spec == Init /\ [][A]_<<x, y>>
Prop == <>(ENABLED A)
====
