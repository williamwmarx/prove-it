(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv"}
---*)
---- MODULE M ----
EXTENDS Integers, Randomization
VARIABLE x
Init == x = 0
Next == x' = x
Inv == <<TestRandomSetOfSubsets(x - 1, 2, {1})>> /= <<>>
====
