(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next", "args": ["-coverage", "1"]}
---*)
---- MODULE M ----
EXTENDS Integers
VARIABLES x, y
Init == (LET m == x IN m) = 0 /\ y = 0
Next == UNCHANGED <<x, y>>
====
