(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv", "args": ["-coverage", "1"]}
---*)
---- MODULE M ----
EXTENDS Integers
VARIABLES x, y, z
Init == x = 0 /\ y = 0 /\ z = 0
Next == x' = 1 - x /\ UNCHANGED <<y, z>>
Inv == ENABLED (y' = 1 - y /\ UNCHANGED (IF z = 2 THEN 0 ELSE x))
====
