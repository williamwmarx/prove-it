(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Integers
VARIABLE x
Init == x = LET RECURSIVE f(_)
                c == f(2)
                f(n) == IF n = 0 THEN 0 ELSE f(n - 1) + 1
            IN c
Next == UNCHANGED x
====
