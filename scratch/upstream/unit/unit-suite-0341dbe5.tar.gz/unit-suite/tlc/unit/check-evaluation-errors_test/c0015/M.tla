(*---
{"description": "upstream unit case", "outcome": "any", "config": "CONSTANT Nodes = {A, B}\nINIT Init\nNEXT Next\nCHECK_DEADLOCK FALSE\nINVARIANT TypeOK"}
---*)
---- MODULE M ----
EXTENDS Naturals
CONSTANTS Nodes
VARIABLES nodeState
LegalSets == {{}}
TypeOK == nodeState \in [Nodes -> [set: LegalSets]]
Init == nodeState = [n \in Nodes |-> [set |-> {}]]
Next == \E n \in Nodes : nodeState' = [nodeState EXCEPT ![n].set = 1]
====
