(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next"}
---*)
---- MODULE M ----
EXTENDS Integers
VARIABLE x
Init == x = 0
Next == x' = (LET g[n \in 0..3, m \in 1..2] == IF n = 0 THEN m ELSE g[n - 1, m \div x] IN g[2, 1])
====
