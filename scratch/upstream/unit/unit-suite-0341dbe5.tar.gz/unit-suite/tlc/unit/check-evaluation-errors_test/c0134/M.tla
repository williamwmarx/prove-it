(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nINVARIANT Inv\nCHECK_DEADLOCK FALSE"}
---*)
---- MODULE M ----
EXTENDS Integers, TLC
VARIABLE x
E == TLCEval(Print("e", TRUE)) /\ TRUE
Init == x = 0
Next == x < 2 /\ x' = x + 1
Inv == /\ \A i \in 1..2 : E!1 /\ x >= 0
       /\ \A i \in 1..2 : CASE x >= 0 -> TLCEval(Print("c", TRUE))
====
