(*---
{"description": "upstream unit case", "outcome": "any", "config": "INIT Init\nNEXT Next\nCONSTRAINT C\nCHECK_DEADLOCK FALSE"}
---*)
---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0 /\ TLCSet(1, 0)
Next == x < 3 /\ \E b \in {1, 2} : TLCSet(1, TLCGet(1) + 1) /\ x' = x + b
C == PrintT(<<"c", x, TLCGet(1)>>) /\ IF x = 3 /\ TLCGet(1) \in {5, 6} THEN 1 \in 2 ELSE TRUE
====
