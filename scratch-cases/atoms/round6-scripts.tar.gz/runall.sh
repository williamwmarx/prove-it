#!/bin/bash
cd /tmp/claude-0/adv8/round6
ls -d cases/*/ | while read d; do [ -f $d/result3.json ] || echo $d; done | xargs -P 2 -I{} python3 run.py {} 2>>runall.err
echo done > runall.done
