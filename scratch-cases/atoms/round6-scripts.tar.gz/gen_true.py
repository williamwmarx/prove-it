#!/usr/bin/env python3
# TRUE-bound constraints family.
from common import emit

def mod(name, body, ext="Naturals, TLC"):
    return f"---- MODULE {name} ----\nEXTENDS {ext}\n{body}\n====\n"

BASE = """VARIABLES x, y
vars == <<x, y>>
Init == x = 0 /\\ y = 0
Next == \\/ x < 3 /\\ x' = x + 1 /\\ UNCHANGED y
        \\/ y < 2 /\\ y' = y + 1 /\\ UNCHANGED x
W == x < 2
W2 == x' < 2
Wy == y < 1
Wy2 == y' < 1
WF(a) == x < a
WFn[i \\in 0..1] == x < 2
f9 == [i \\in 0..1 |-> i]
Wbad == f9[x] = 0
V == x < 1
"""
cases = []
def add(name, cfg, body=BASE, extra_files=None, root="M", opts=None, ext="Naturals, TLC"):
    files = {f"{root}.tla": mod(root, body, ext)}
    files.update(extra_files or {})
    cases.append((name, files, "INIT Init\nNEXT Next\n" + cfg, opts or [], root))

for kw in ["CONSTRAINT", "ACTION_CONSTRAINT"]:
    k = "c" if kw == "CONSTRAINT" else "a"
    w = "W" if k == "c" else "W2"
    # duplicates
    add(f"t{k}_dup_FT", f"CONSTANT {w} = FALSE\nCONSTANT {w} = TRUE\n{kw} {w}\n")
    add(f"t{k}_dup_TF", f"CONSTANT {w} = TRUE\nCONSTANT {w} = FALSE\n{kw} {w}\n")
    add(f"t{k}_dup_TT", f"CONSTANT {w} = TRUE\n{w} = TRUE\n{kw} {w}\n")
    add(f"t{k}_dup_T1", f"CONSTANT {w} = TRUE\n{w} = 1\n{kw} {w}\n")
    add(f"t{k}_dup_1T", f"CONSTANT {w} = 1\n{w} = TRUE\n{kw} {w}\n")
    # root-scoped value and substitute
    add(f"t{k}_scopedval", f"CONSTANT {w} = [M] TRUE\n{kw} {w}\n")
    add(f"t{k}_scopedval_and_T", f"CONSTANT {w} = [M] FALSE\n{w} = TRUE\n{kw} {w}\n")
    add(f"t{k}_T_scopedsub", f"CONSTANT {w} = TRUE\n{w} <- [M] V\n{kw} {w}\n")
    add(f"t{k}_T_unscopedsub", f"CONSTANT {w} = TRUE\n{w} <- V\n{kw} {w}\n")
    add(f"t{k}_T_sub_rhs", f"CONSTANT {w} = TRUE\nV <- {w}\n{kw} {w}\n")
    add(f"t{k}_T_sub_rhs_V", f"CONSTANT {w} = TRUE\nV <- {w}\n{kw} V\n")
    add(f"t{k}_T_both", f"CONSTANT V = TRUE\n{w} <- V\n{kw} {w}\n")
    add(f"t{k}_T_both_V", f"CONSTANT V = TRUE\n{w} <- V\n{kw} {w} V\n")
    add(f"t{k}_chain", f"CONSTANT {w} = TRUE\nV <- Wy\nWy <- {w}\n{kw} {w} V\n")
    # arity / function
    add(f"t{k}_arity", f"CONSTANT WF = TRUE\n{kw} WF\n")
    add(f"t{k}_fn", f"CONSTANT WFn = TRUE\n{kw} WFn\n")
    add(f"t{k}_bad_T", f"CONSTANT Wbad = TRUE\n{kw} Wbad\n")
    add(f"t{k}_bad_T_sub", f"CONSTANT Wbad = TRUE\nWbad <- V\n{kw} Wbad\n")
    # mixed lists
    add(f"t{k}_mix1", f"CONSTANT {w} = TRUE\n{kw} {w} Wy\n")
    add(f"t{k}_mix2", f"CONSTANT Wy = TRUE\n{kw} {w} Wy\n")
    add(f"t{k}_mix3", f"CONSTANT {w} = TRUE\nWy = TRUE\n{kw} {w} Wy\n")
    add(f"t{k}_mix_both", f"CONSTANT W = TRUE\nW2 = TRUE\nCONSTRAINT W Wy\nACTION_CONSTRAINT W2 Wy2\n")
    add(f"t{k}_mix_cross", f"CONSTANT W = TRUE\nCONSTRAINT Wy\nACTION_CONSTRAINT W\n")
    add(f"t{k}_mix_bad", f"CONSTANT Wbad = TRUE\n{kw} Wbad {w}\n")
    add(f"t{k}_mix_undef", f"CONSTANT {w} = TRUE\n{kw} {w} Nope\n")
    add(f"t{k}_undefT", f"CONSTANT Nope = TRUE\n{kw} Nope\n")
    # constant decls
    cbody = BASE + "CONSTANT Cst\n"
    add(f"t{k}_const", f"CONSTANT Cst = TRUE\n{kw} Cst\n", body=cbody)
    add(f"t{k}_const_sub", f"CONSTANT Cst <- V\n{kw} Cst\n", body=cbody)
    add(f"t{k}_const_sub_T", f"CONSTANT Cst <- TT\n{kw} Cst\n", body=cbody + "TT == TRUE\n")
    add(f"t{k}_const_F", f"CONSTANT Cst = FALSE\n{kw} Cst\n", body=cbody)
    add(f"t{k}_const_mv", f"CONSTANT Cst = Cst\n{kw} Cst\n", body=cbody)
    # extended module constant/definition
    lib = mod("Lib", "CONSTANT LC\nLW == TRUE\n", "Naturals")
    add(f"t{k}_extconst", f"CONSTANT LC = TRUE\n{kw} LC\n", body=BASE, extra_files={"Lib.tla": lib}, ext="Naturals, TLC, Lib")
    # instance names
    inner = mod("Inner", "CONSTANT K\nVARIABLE x\nIW == x < K\n", "Naturals")
    ib = BASE + "I == INSTANCE Inner WITH K <- 2\nJ(k) == INSTANCE Inner WITH K <- k\n"
    add(f"t{k}_inst", f"CONSTANT I = TRUE\n{kw} I\n", body=ib, extra_files={"Inner.tla": inner})
    add(f"t{k}_instparam", f"CONSTANT J = TRUE\n{kw} J\n", body=ib, extra_files={"Inner.tla": inner})
    add(f"t{k}_inst_IW", f"CONSTANT IW = TRUE\n{kw} I!IW\n", body=ib, extra_files={"Inner.tla": inner})
    ib2 = BASE + "INSTANCE Inner WITH K <- 2\n"
    add(f"t{k}_uinst", f"CONSTANT IW = TRUE\n{kw} IW\n", body=ib2, extra_files={"Inner.tla": inner})
    # LOCAL, recursive, theorem-ish
    add(f"t{k}_local", f"CONSTANT LW = TRUE\n{kw} LW\n", body=BASE + "LOCAL LW == x < 1\n")
    add(f"t{k}_recursive", f"CONSTANT RW = TRUE\n{kw} RW\n", body=BASE + "RECURSIVE RW\nRW == x < 1 /\\ RW\n")
    add(f"t{k}_temporal", f"CONSTANT TW = TRUE\n{kw} TW\n", body=BASE + "TW == []TRUE\n")
    add(f"t{k}_nonbool_T", f"CONSTANT NB = TRUE\n{kw} NB\n", body=BASE + "NB == 7\n")
    add(f"t{k}_string_T", f"CONSTANT SW = TRUE\n{kw} SW\n", body=BASE + "SW == \"s\"\n")
    # also used elsewhere
    add(f"t{k}_alsoinv", f"CONSTANT {w} = TRUE\n{kw} {w}\nINVARIANT {w}\n")
    add(f"t{k}_readnext", f"CONSTANT RN = TRUE\n{kw} RN\n", body=BASE.replace("Next ==", "Next == RN /\\ (") .replace("UNCHANGED x\n", "UNCHANGED x)\n", 1) + "RN == x < 2\n")
    add(f"t{k}_deadlock", f"CONSTANT {w} = TRUE\n{kw} {w}\n", opts=["-deadlock"])
    add(f"t{k}_spec", f"CONSTANT {w} = TRUE\n{kw} {w}\nINVARIANT V\n")
    # root names
    for rn in ["topic", "TOPIC", "Topics", "Tlc", "json", "AbstractGraphs", "Functions", "Relation", "Folds",
               "Toolbox", "RealTime", "Randomization", "TraceData", "MenuPane", "Main", "DocUtils", "Json2",
               "SequencesExt", "BagsExt", "Combinatorics", "HTMLPrinter", "Formatter"]:
        add(f"t{k}_root_{rn}", f"CONSTANT {w} = TRUE\n{kw} {w}\n", root=rn)
    # root name with no constraint bound TRUE (regression)
    for rn in ["TraceData", "Functions"]:
        add(f"t{k}_root_{rn}_plain", f"{kw} {w}\n", root=rn)

for c in cases:
    emit(*c[:4], root=c[4])
print(len(cases))
