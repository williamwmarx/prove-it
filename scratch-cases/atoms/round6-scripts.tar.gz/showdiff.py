import json,difflib,sys
c=sys.argv[1]; vk=sys.argv[2] if len(sys.argv)>2 else 'plain'; who=sys.argv[3] if len(sys.argv)>3 else 'branch1'
r=json.load(open('cases/'+c+'/result3.json'))[vk]
print('=====',c,'jar',r['jar']['rc'],who,r[who]['rc'],'main1',r['main1']['rc'],'decl' if r['main1'].get('decline') else '', r['main1']['err'][-160:].strip())
if r[who]['out'] is None: print(r[who]['err'][-400:]); sys.exit()
print('\n'.join(difflib.unified_diff((r['jar']['out'] or '').splitlines(), r[who]['out'].splitlines(),'jar',who,lineterm='',n=1)))
