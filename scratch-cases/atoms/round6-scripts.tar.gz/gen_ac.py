#!/usr/bin/env python3
# Action-constraint failure family.
import os
from common import emit

HDR = "---- MODULE M ----\nEXTENDS Naturals, Sequences, TLC, FiniteSets\n"

def spec(nextdef, ac, extra="", init="x = 0 /\\ y = 0", vars_="x, y"):
    return HDR + f"VARIABLES {vars_}\nvars == <<{vars_}>>\nf == [i \\in 0..2 |-> i]\nOp(k) == f[k]\nRECURSIVE R(_)\nR(n) == IF n = 0 THEN f[9] ELSE R(n-1)\n{extra}\nInit == {init}\n{nextdef}\nSpec == Init /\\ [][Next]_vars\nAC == {ac}\n====\n"

NEXTS = {
    "disj": "A == x < 3 /\\ x' = x + 1 /\\ UNCHANGED y\nB == y < 2 /\\ y' = y + 1 /\\ UNCHANGED x\nNext == A \\/ B",
    "exist": "Next == \\E i \\in 1..2 : x + i <= 4 /\\ x' = x + i /\\ y' = y",
    "param": "Inc(v) == v < 3\nA(i) == x < 3 /\\ x' = x + i /\\ UNCHANGED y\nNext == \\E i \\in {1} : A(i) \\/ (y < 2 /\\ y' = y + 1 /\\ UNCHANGED x)",
    "selfloop": "Next == \\/ x < 3 /\\ x' = x + 1 /\\ UNCHANGED y\n        \\/ UNCHANGED vars",
    "let": "Next == LET n == x + 1 IN n <= 3 /\\ x' = n /\\ UNCHANGED y",
    "ifte": "Next == IF x < 3 THEN x' = x + 1 /\\ UNCHANGED y ELSE x' = 0 /\\ y' = y + 1",
    "case": "Next == CASE x < 3 -> x' = x + 1 /\\ UNCHANGED y\n          [] OTHER -> x' = x /\\ y' = (y + 1) % 3",
    "conj_disj": "Next == /\\ y' = y\n        /\\ \\/ x < 3 /\\ x' = x + 1\n           \\/ x > 0 /\\ x' = x - 1",
}

ACS = {
    "fdom": "f[x']>= 0",
    "tupidx": "<<1,2,3>>[x' + 1] > 0",
    "op": "Op(x') >= 0",
    "letfail": "LET z == f[x'] IN z >= 0",
    "forall": "\\A i \\in 0..x' : f[i] >= 0",
    "exists": "\\E i \\in {x'} : f[i] >= 0",
    "nonbool": "IF x' = 3 THEN 5 ELSE TRUE",
    "assert": "Assert(x' < 3, \"too big\")",
    "choose": "x' = 3 => (CHOOSE i \\in {} : TRUE) = 1",
    "cmp": "x' = 3 => x' = \"a\"",
    "head": "x' = 3 => Head(<<>>) = 1",
    "rec": "x' = 3 => R(2) = 1",
    "rcd": "x' = 3 => [a |-> 1].b = 1",
    "level": "TLCGet(\"level\") < 3 \\/ f[x'] = 0",
    "unprimed": "f[x + 1] >= 0",
    "div": "10 \\div (3 - x') >= 0",
    "lazyfn": "x' = 3 => [i \\in Nat |-> i][-1] = 0",
    "except": "[f EXCEPT ![0] = 5][x'] >= 0",
    "cup": "x' = 3 => (1 \\cup {2}) = {}",
    "seqcat": "x' = 3 => (<<1>> \\o 2) = <<>>",
    "card": "x' = 3 => Cardinality(Nat) = 1",
    "subset": "x' = 3 => \\A s \\in SUBSET Nat : TRUE",
    "nested_op": "LET G(k) == Op(k) + Op(k) IN G(x') >= 0",
    "lambda": "LET Ap(F(_), k) == F(k) IN Ap(LAMBDA k : f[k], x') >= 0",
    "printT": "PrintT(x') /\\ f[x'] >= 0",
    "range_y": "y' = 2 => f[5] = 0",
    "orfalse": "x' # 3 \\/ f[x'] = 0",
    "andshort": "x' = 3 /\\ f[x'] = 0 \\/ x' # 3",
    "setof": "x' = 3 => f[x'] \\in {1}",
    "domain": "x' \\in DOMAIN f \\/ <<>>[1] = 0",
}

cases = []
for nk, nd in NEXTS.items():
    for ak in (["fdom", "op", "nonbool", "assert", "level", "unprimed"] if nk != "disj" else list(ACS)):
        a = ACS[ak]
        cfg = "INIT Init\nNEXT Next\nACTION_CONSTRAINT AC\n"
        cases.append((f"ac_{nk}_{ak}", {"M.tla": spec(nd, a)}, cfg, []))

D = NEXTS["disj"]
# interplay variants on disj/fdom
var = {
    "spec": ("SPECIFICATION Spec\nACTION_CONSTRAINT AC\n", []),
    "dl": ("INIT Init\nNEXT Next\nACTION_CONSTRAINT AC\n", ["-deadlock"]),
    "constr_hides": ("INIT Init\nNEXT Next\nCONSTRAINT Cn\nACTION_CONSTRAINT AC\n", []),
    "constr_pass": ("INIT Init\nNEXT Next\nCONSTRAINT Cp\nACTION_CONSTRAINT AC\n", []),
    "two_ac_falsefirst": ("INIT Init\nNEXT Next\nACTION_CONSTRAINT AF AC\n", []),
    "two_ac_failfirst": ("INIT Init\nNEXT Next\nACTION_CONSTRAINT AC AF\n", []),
    "inv_same": ("INIT Init\nNEXT Next\nINVARIANT Inv3\nACTION_CONSTRAINT AC\n", []),
    "inv_earlier": ("INIT Init\nNEXT Next\nINVARIANT Inv1\nACTION_CONSTRAINT AC\n", []),
    "sym": ("INIT Init\nNEXT Next\nACTION_CONSTRAINT AC\n", []),
    "view": ("INIT Init\nNEXT Next\nVIEW V\nACTION_CONSTRAINT AC\n", []),
    "continue": ("INIT Init\nNEXT Next\nACTION_CONSTRAINT AC\n", ["-continue"]),
    "prop": ("SPECIFICATION Spec\nPROPERTY P\nACTION_CONSTRAINT AC\n", []),
    "actprop": ("SPECIFICATION Spec\nPROPERTY AP\nACTION_CONSTRAINT AC\n", []),
    "post": ("INIT Init\nNEXT Next\nPOSTCONDITION Post\nACTION_CONSTRAINT AC\n", []),
    "dead_inv": ("INIT Init\nNEXT Next\nINVARIANT TRUEInv\nACTION_CONSTRAINT AC\n", []),
    "multiinit": ("INIT Init2\nNEXT Next\nACTION_CONSTRAINT AC\n", []),
    "constAC": ("INIT Init\nNEXT Next\nACTION_CONSTRAINT ACc\n", []),
    "constC": ("INIT Init\nNEXT Next\nCONSTRAINT ACc\n", []),
    "stateAC": ("INIT Init\nNEXT Next\nACTION_CONSTRAINT ACs\n", []),
    "dup": ("INIT Init\nNEXT Next\nACTION_CONSTRAINT AC AC\n", []),
    "sameasconstr": ("INIT Init\nNEXT Next\nCONSTRAINT ACs\nACTION_CONSTRAINT ACs\n", []),
}
extra = ("Cn == x < 3\nCp == x < 9\nAF == x' # 3\nInv3 == x # 3\nInv1 == x # 1\nV == <<x, y>>\nP == <>(x = 3)\nAP == [][x' >= x]_vars\n"
         "Post == TLCGet(\"distinct\") > 0\nTRUEInv == TRUE\nInit2 == x \\in {0, 1} /\\ y = 0\nACc == f[3] = 0\nACs == f[x] >= 0\n")
for vk, (cfg, opts) in var.items():
    for ak in ["fdom", "nonbool", "assert"]:
        cases.append((f"acv_{vk}_{ak}", {"M.tla": spec(D, ACS[ak], extra)}, cfg, opts))
# symmetry with model values
symspec = HDR + """CONSTANT P
VARIABLES x, y
vars == <<x, y>>
Init == x = {} /\\ y = 0
Next == \\E p \\in P : p \\notin x /\\ x' = x \\cup {p} /\\ y' = y + 1
Sym == Permutations(P)
AC == Cardinality(x') < 2 \\/ <<1>>[y' + 5] = 1
AC2 == y' = 2 => (CHOOSE q \\in x' : TRUE) = 1
====
"""
for ak in ["AC", "AC2"]:
    for sym in ["", "SYMMETRY Sym\n"]:
        cases.append((f"acsym_{ak}_{'sym' if sym else 'nosym'}", {"M.tla": symspec},
                      f"CONSTANT P = {{p1, p2, p3}}\nINIT Init\nNEXT Next\n{sym}ACTION_CONSTRAINT {ak}\n", []))

# Next through INSTANCE
inner = """---- MODULE Inner ----
EXTENDS Naturals
CONSTANT K
VARIABLES x, y
g == [i \\in 0..K |-> i]
A == x < 3 /\\ x' = x + 1 /\\ UNCHANGED y
Fail == g[x'] >= 0
====
"""
for withk, kexpr in [("k2", "2"), ("kfn", "1+1")]:
    rootm = HDR + f"VARIABLES x, y\nvars == <<x, y>>\nI == INSTANCE Inner WITH K <- {kexpr}\nInit == x = 0 /\\ y = 0\nNext == I!A \\/ (y < 1 /\\ y' = y + 1 /\\ UNCHANGED x)\nAC == I!Fail\nAC2 == I!g[x'] >= 0\n====\n"
    for ac in ["AC", "AC2"]:
        cases.append((f"acinst_{withk}_{ac}", {"M.tla": rootm, "Inner.tla": inner}, f"INIT Init\nNEXT Next\nACTION_CONSTRAINT {ac}\n", []))
# extended module Next
lib = """---- MODULE Lib ----
EXTENDS Naturals
VARIABLES x, y
g == [i \\in 0..2 |-> i]
A == x < 3 /\\ x' = x + 1 /\\ UNCHANGED y
LAC == g[x'] >= 0
====
"""
rootm = "---- MODULE M ----\nEXTENDS Lib, TLC\nInit == x = 0 /\\ y = 0\nNext == A\nAC == LAC\n====\n"
cases.append(("acext_LAC", {"M.tla": rootm, "Lib.tla": lib}, "INIT Init\nNEXT Next\nACTION_CONSTRAINT LAC\n", []))
cases.append(("acext_AC", {"M.tla": rootm, "Lib.tla": lib}, "INIT Init\nNEXT Next\nACTION_CONSTRAINT AC\n", []))

for c in cases:
    emit(*c)
print(len(cases))
