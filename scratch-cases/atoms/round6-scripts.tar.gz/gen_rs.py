from common import emit
import shutil,os
BASE = open('cases/tc_mix1/M.tla').read().replace("====\n","")
cases=[]
def add(n,cfg,extra="",files=None,cls=None):
    f={"M.tla":BASE+extra+"====\n"}; f.update(files or {})
    cases.append((n,f,"INIT Init\nNEXT Next\n"+cfg,[],cls))
FX="fr == 1\nfr2 == 2\n"
add("rs_assume_holds","CONSTANT fr <- [M] fr2\n",FX+"ASSUME fr \\in {1,2}\n")
add("rs_assume_fails","CONSTANT fr <- [M] fr2\n",FX+"ASSUME fr = 1\n")
add("rs_unused","CONSTANT fr <- [M] fr2\n",FX+"Un == fr + 1\n")
add("rs_unused2","CONSTANT fr <- [M] fr2\n",FX+"Un == fr + 1\nUn2 == Un\n")
add("rs_dropped_constraint","CONSTANT WR = TRUE\nfr <- [M] fr2\nCONSTRAINT WR\n",FX+"WR == x < fr\n")
add("rs_constraint","CONSTANT WR <- [M] V\nCONSTRAINT WR\n",FX+"WR == x < 3\n")
add("rs_lower_m","CONSTANT fr <- [m] fr2\nINVARIANT IR\n",FX+"IR == x < fr + 2\n")
add("rs_used_inv","CONSTANT fr <- [M] fr2\nINVARIANT IR\n",FX+"IR == x < fr + 2\n")
add("rs_used_inst","CONSTANT fr <- [M] fr2\nINVARIANT I!IW\n",FX+"I == INSTANCE Inner WITH K <- fr + 1\n",
    {"Inner.tla":"---- MODULE Inner ----\nEXTENDS Naturals\nCONSTANT K\nVARIABLE x\nIW == x < K\n====\n"})
add("rs_value_scoped","CONSTANT fr = [M] 5\nINVARIANT IR\n",FX+"IR == x < fr\n")
add("rs_value_scoped_lib","CONSTANT lf = [Lib] 1\nINVARIANT IR\n","IR == x < lf + 1\n",
    {"Lib.tla":"---- MODULE Lib ----\nlf == 7\n====\n"})
# class beside spec
for k in ["other","wmeth","wtrue"]:
    for kw,w in [("CONSTRAINT","W"),("ACTION_CONSTRAINT","W2")]:
        add(f"cls_{k}_{kw[0]}_T",f"CONSTANT {w} = TRUE\n{kw} {w}\n",cls=k)
        add(f"cls_{k}_{kw[0]}_plain",f"{kw} {w}\n",cls=k)
    add(f"cls_{k}_noconstraint","INVARIANT Wy\n",cls=k)
for n,f,cfg,o,cls in cases:
    emit(n,f,cfg,o)
    if cls: shutil.copy(f"java/{cls}/M.class",f"cases/{n}/M.class")
print(len(cases))
