from common import emit
BASE = open('cases/tc_mix1/M.tla').read().replace("====\n","")
X = "fr == 1\nfr2 == 2\nWR == x < 3\nWR2 == x' < 3\nIR == x < 3\nUR == x < fr + 2\n"
cases=[]
def add(n,cfg,extra=""):
    cases.append((n,{"M.tla":BASE+X+extra+"====\n"},"INIT Init\nNEXT Next\n"+cfg,[]))
add("rs2_c","CONSTANT WR <- [M] V\nCONSTRAINT WR\n")
add("rs2_ac","CONSTANT WR2 <- [M] Wy2\nACTION_CONSTRAINT WR2\n")
add("rs2_inv","CONSTANT IR <- [M] V\nINVARIANT IR\n")
add("rs2_c_inner","CONSTANT fr <- [M] fr2\nCONSTRAINT UR\n")
add("rs2_c_and_inv","CONSTANT WR <- [M] V\nCONSTRAINT WR\nINVARIANT WR\n")
add("rs2_c_viaop","CONSTANT WR <- [M] V\nCONSTRAINT CW\n","CW == WR\n")
add("rs2_ac_x","CONSTANT WR2 <- [M] V\nACTION_CONSTRAINT WR2\n")
add("rs2_assume_fails","CONSTANT fr <- [M] fr2\n","ASSUME fr = 1\n")
add("rs2_assume_holds2","CONSTANT fr <- [M] fr2\n","ASSUME fr > 0\n")
add("rs2_next","CONSTANT Nx <- [M] Nx2\n","Nx == x < 3\nNx2 == x < 1\n")
for c in cases: emit(*c)
