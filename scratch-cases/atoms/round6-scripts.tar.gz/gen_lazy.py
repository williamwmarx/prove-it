#!/usr/bin/env python3
# Lazy scoped substitutes through other operators.
from common import emit

BODIES = {
    # name: (definition of f2 in root, good key, bad key)
    "lam": ("f2 == [i \\in 0..1 |-> i]", "0", "5"),
    "nat": ("f2 == [i \\in Nat |-> i]", "0", "-1"),
    "subset": ("f2 == [s \\in SUBSET {1, 2} |-> Cardinality(s)]", "{}", "{3}"),
    "rec": ("f2[i \\in 0..1] == IF i = 0 THEN 0 ELSE f2[i - 1] + 1", "0", "5"),
    "let": ("f2 == LET h == [i \\in 0..1 |-> i] IN h", "0", "5"),
    "opapp": ("Mk(n) == [i \\in 0..n |-> i]\nf2 == Mk(1)", "0", "5"),
    "colon": ("f2 == (0 :> 0) @@ (1 :> 1)", "0", "5"),
    "tup": ("f2 == <<0, 1>>", "1", "5"),
    "rcd": ("f2 == [a |-> 0, b |-> 1]", "\"a\"", "\"c\""),
    "fnset": ("f2 == CHOOSE g \\in [0..1 -> {0}] : TRUE", "0", "5"),
    "multi": ("f2 == [i \\in 0..1, j \\in 0..1 |-> i + j]", "<<0, 0>>", "<<5, 0>>"),
    "except": ("f2 == [[i \\in 0..1 |-> i] EXCEPT ![0] = 5]", "0", "5"),
    "strdom": ("f2 == [s \\in {\"a\", \"b\"} |-> 1]", "\"a\"", "\"z\""),
    "interval_var": ("f2 == [i \\in 0..1 |-> i * 2]", "1", "2"),
}
USES = {
    "plain": "@F[k]",
    "atat": "(@F @@ (77 :> 7))[k]",
    "atat_l": "((77 :> 7) @@ @F)[k]",
    "rebuild": "[j \\in DOMAIN @F |-> @F[j]][k]",
    "except": "[@F EXCEPT ![@g] = 9][k]",
    "except2": "[[@F EXCEPT ![@g] = 9] EXCEPT ![@g] = 8][k]",
    "rcd": "[r |-> @F].r[k]",
    "seq": "<<@F>>[1][k]",
    "choose": "(CHOOSE h \\in {@F} : TRUE)[k]",
    "setmem": "IF @F \\in [DOMAIN @F -> Int \\cup {0}] THEN @F[k] ELSE 0",
    "lambda": "LET Ap(H) == H[k] IN Ap(@F)",
    "compose": "[j \\in {k} |-> @F[j]][k]",
    "letbind": "LET z == @F IN z[k]",
    "ifte": "(IF k = @g THEN @F ELSE @F)[k]",
    "case": "(CASE TRUE -> @F)[k]",
    "union": "(@F @@ @F)[k]",
    "domain": "IF k \\in DOMAIN @F THEN 0 ELSE @F[k]",
}

INNER = """---- MODULE Inner ----
EXTENDS Naturals, FiniteSets
CONSTANT K
VARIABLE x
G == K
Look(k) == G[k]
====
"""
LIB = """---- MODULE Lib ----
EXTENDS Naturals, FiniteSets
G == [i \\in 0..9 |-> i]
Look(k) == G[k]
====
"""

def root(mode, body, use, good, bad, site):
    ref = "I!G" if mode == "inst" else "G"
    u = use.replace("@F", f"({ref})").replace("@g", good)
    head = "---- MODULE M ----\nEXTENDS Integers, FiniteSets, TLC" + (", Lib" if mode == "ext" else "") + "\nVARIABLE x\n"
    s = head + body + "\nfill == [i \\in 0..9 |-> i]\n"
    if mode == "inst":
        s += "I == INSTANCE Inner WITH K <- fill\n"
    kx = "x'" if site == "ac" else "x"
    s += f"U == LET k == IF {kx} < 2 THEN {good} ELSE {bad} IN {u}\n"
    s += "Init == x = 0\n"
    if site == "next":
        s += "Next == x < 3 /\\ x' = x + 1 /\\ U # -99\n"
    else:
        s += "Next == x < 3 /\\ x' = x + 1\n"
    s += "Inv == U # -99\nAC == U # -99\n====\n"
    return s

cases = []
for mode in ["inst", "ext"]:
    mname = "Inner" if mode == "inst" else "Lib"
    for bk, (bdef, good, bad) in BODIES.items():
        uses = list(USES) if (mode == "inst" or bk in ("lam", "nat", "subset", "rec", "tup", "except")) else ["plain", "atat", "rebuild", "except"]
        for uk in uses:
            sites = ["next"] if uk not in ("plain", "except", "atat") else ["next", "inv", "ac"]
            for site in sites:
                files = {"M.tla": root(mode, bdef, USES[uk], good, bad, site)}
                files[f"{mname}.tla"] = INNER if mode == "inst" else LIB
                cfg = f"INIT Init\nNEXT Next\nCONSTANT G <- [{mname}] f2\n"
                if site == "inv":
                    cfg += "INVARIANT Inv\n"
                if site == "ac":
                    cfg += "ACTION_CONSTRAINT AC\n"
                cases.append((f"lz_{mode}_{bk}_{uk}_{site}", files, cfg, []))
for c in cases:
    emit(*c)
print(len(cases))
