#!/usr/bin/env python3
# Startup values, prints and randomness through substitutes and INSTANCEs, in failures.
from common import emit

INNER = """---- MODULE Inner ----
EXTENDS Integers, TLC
CONSTANT K
VARIABLE x
r == RandomElement(1..1000)
p == PrintT(<<"inner", K>>)
h == [i \\in 0..1 |-> i + K]
hb == [i \\in 0..1 |-> 10 \\div (i - K)]
Look(k) == h[k]
====
"""
INNERNP = """---- MODULE InnerNP ----
EXTENDS Integers, TLC
r == RandomElement(1..1000)
p == PrintT("innernp")
h == [i \\in 0..1 |-> i]
hb == [i \\in 0..1 |-> 10 \\div (i - 1)]
====
"""
HEAD = """---- MODULE M ----
EXTENDS Integers, TLC, Sequences
VARIABLE x
r == RandomElement(1..1000)
r2 == RandomElement(1..1000)
p == PrintT("root")
q == PrintT("q")
h == [i \\in 0..1 |-> i]
h2 == [i \\in 0..1 |-> i * 3]
hb == [i \\in 0..1 |-> 10 \\div (i - 1)]
hz == [i \\in 0..1 |-> 10 \\div (i - 0)]
lv == TLCGet("level")
I == INSTANCE Inner WITH K <- 1
J == INSTANCE InnerNP
Init == x = 0
"""
NEXTS = {
    "r": "Next == x < 3 /\\ x' = x + 1 /\\ r > 0",
    "Ir": "Next == x < 3 /\\ x' = x + 1 /\\ I!r > 0",
    "Jr": "Next == x < 3 /\\ x' = x + 1 /\\ J!r > 0",
    "p": "Next == x < 3 /\\ x' = x + 1 /\\ p",
    "Ip": "Next == x < 3 /\\ x' = x + 1 /\\ I!p",
    "Jp": "Next == x < 3 /\\ x' = x + 1 /\\ J!p",
    "q": "Next == x < 3 /\\ x' = x + 1 /\\ q",
    "lv": "Next == x < 3 /\\ x' = x + 1 + lv",
    "rx": "Next == x < 3 /\\ x' = x + 1 /\\ r # x",
}
FAILS = {
    "h": "h[x] >= 0",
    "Ih": "I!h[x] >= 0",
    "Jh": "J!h[x] >= 0",
    "Ilook": "I!Look(x) >= 0",
    "hb": "hb[x - 2] >= 0",
    "Ihb": "I!hb[x - 2] >= 0",
    "Jhb": "J!hb[x - 2] >= 0",
    "hz": "hz[x] >= 0",
    "rh": "r > 0 /\\ h[x] >= 0",
    "ph": "p /\\ h[x] >= 0",
    "Iph": "I!p /\\ I!h[x] >= 0",
    "Jph": "J!p /\\ J!h[x] >= 0",
    "lvh": "h[lv + x] >= 0",
}
SUBS = {
    "none": "",
    "h_h2": "CONSTANT h <- h2\n",
    "p_q": "CONSTANT p <- q\n",
    "r_r2": "CONSTANT r <- r2\n",
    "Ih_h2": "CONSTANT h <- [Inner] h2\n",
    "Jh_h2": "CONSTANT h <- [InnerNP] h2\n",
    "Ip_q": "CONSTANT p <- [Inner] q\n",
    "Jr_r2": "CONSTANT r <- [InnerNP] r2\n",
    "hval": "CONSTANT h = <<5>>\n",
}
cases = []
for nk, nd in NEXTS.items():
    for fk, fd in FAILS.items():
        for sk, sd in SUBS.items():
            # trim: full grid for a subset
            if sk != "none" and fk not in ("h", "Ih", "Jh", "ph", "Iph", "Jph", "rh") and nk not in ("p", "Ip"):
                continue
            if sk != "none" and nk not in ("r", "p", "Ip", "Jr", "q"):
                continue
            for site in ["inv", "next"]:
                if site == "next" and fk not in ("h", "Ih", "Jh", "Iph", "Jph", "hb"):
                    continue
                s = HEAD + nd + "\nInv == " + fd + "\nFailNext == Next /\\ " + fd + "\n====\n"
                cfg = "INIT Init\n" + ("NEXT Next\nINVARIANT Inv\n" if site == "inv" else "NEXT FailNext\n") + sd
                cases.append((f"ms_{nk}_{fk}_{sk}_{site}", {"M.tla": s, "Inner.tla": INNER, "InnerNP.tla": INNERNP}, cfg, []))
for c in cases:
    emit(*c)
print(len(cases))
