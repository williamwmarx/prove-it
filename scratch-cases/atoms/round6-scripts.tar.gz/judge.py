#!/usr/bin/env python3
import sys,json,os,glob
for c in sorted(glob.glob("/tmp/claude-0/adv8/round6/cases/*/result3.json")):
    r=json.load(open(c)); name=os.path.basename(os.path.dirname(c))
    for vk,v in r.items():
        j=v["jar"]
        def st(x):
            if x.get("decline"): return "DECL"
            if x["out"]==j["out"] and x["rc"]==j["rc"]: return "ok"
            return "DIFF"
        s={k:st(x) for k,x in v.items() if k!="jar"}
        m=set([s["main1"],s["main4"]]); b=set([s["branch1"],s["branch4"]])
        cat=""
        if "ok" in m and b!={"ok"}: cat="A"
        elif "DECL" in m and "DIFF" in b: cat="B"
        elif "DIFF" in b: cat="C"
        flag = cat or ""
        if len(sys.argv)>1 or flag:
            print(f"{flag:2} {name:40} {vk:14} jar={j['rc']} main={s['main1']},{s['main4']} branch={s['branch1']},{s['branch4']}")
