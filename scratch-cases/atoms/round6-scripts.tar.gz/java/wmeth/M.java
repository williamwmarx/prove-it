import tlc2.value.impl.*;
public class M { public static Value W() { return BoolValue.ValFalse; } }
