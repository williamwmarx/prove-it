import tlc2.value.impl.*;
public class M { public static Value Other() { return BoolValue.ValTrue; } }
