#!/usr/bin/env python3
# usage: run.py casedir  -> writes casedir/result2.json
import sys, os, subprocess, shutil, json, re, tempfile, glob
JAR="/home/user/tlc/tlaplus/tlatools/org.lamport.tlatools/tla2tools.jar"
B={"main":"/tmp/claude-0/adv8/main-bin","branch":"/tmp/claude-0/adv8/branch-bin"}
LIB="/home/user/prove-it/packages/prove-it/tests/conformance/.library"
case=os.path.abspath(sys.argv[1])
root=open(os.path.join(case,"root")).read().strip() if os.path.exists(os.path.join(case,"root")) else "M"
cfg=open(os.path.join(case,"cfgname")).read().strip() if os.path.exists(os.path.join(case,"cfgname")) else root+".cfg"
extra=open(os.path.join(case,"opts")).read().split() if os.path.exists(os.path.join(case,"opts")) else []
uselib=os.path.exists(os.path.join(case,"lib"))
if uselib:
    _l=open(os.path.join(case,"lib")).read().strip()
    if _l.startswith("/"): LIB=_l
srcdir=open(os.path.join(case,"src")).read().strip() if os.path.exists(os.path.join(case,"src")) else case
hasprop=bool(re.search(r'^\s*PROPERT',open(os.path.join(srcdir,cfg)).read(),re.M))
def norm(t):
    i=t.find("Starting... (")
    if i<0: return None
    t=t[i:]; j=t.find("Finished in")
    if j>=0: t=t[:j]
    out=[]
    for l in t.splitlines()[1:]:
        if l.startswith(("Progress(","Finished computing initial states","Checking ","Finished checking temporal properties")): continue
        l=re.sub(r'\d{4}-\d\d-\d\d \d\d:\d\d:\d\d','<T>',l)
        out.append(l)
    return "\n".join(out)
def runone(cmd,timeout=600,lim=True):
    d=tempfile.mkdtemp(dir="/tmp/claude-0/adv8/round6/tmp")
    for f in os.listdir(srcdir):
        if f.endswith((".tla",".cfg",".class")): shutil.copy(os.path.join(srcdir,f),d)
    os.makedirs(d+"/jtmp",exist_ok=True); cmd=[c.replace("{D}",d) for c in cmd]
    try:
        p=subprocess.run((["bash","-c","ulimit -v 4000000; exec \"$@\"","x"] if lim else [])+cmd,cwd=d,capture_output=True,timeout=timeout,text=True,errors="replace")
        out,err,rc=p.stdout,p.stderr,p.returncode
    except subprocess.TimeoutExpired:
        out,err,rc="","TIMEOUT",-999
    shutil.rmtree(d,ignore_errors=True)
    return out,err,rc
res={}
variants=[[]]+([["-lncheck","final"]] if hasprop else [])
for v in variants:
    vk=" ".join(v) or "plain"
    opts=["-nowarning","-seed","4","-fp","0"]+v+extra
    jcmd=["java","-Xmx1g","-XX:+UseSerialGC","-Djava.io.tmpdir={D}/jtmp"]+(["-DTLA-Library="+LIB] if uselib else [])+["-cp",JAR,"tlc2.TLC","-noTE","-workers","1"]+opts+["-config",cfg,root]
    o,e,rc=runone(jcmd,lim=False)
    res[vk]={"jar":{"rc":rc,"out":norm(o),"raw":o[-3000:]+e[-1000:]}}
    for name,b in B.items():
        for w in ["1","4"]:
            cmd=[b]+(["-DTLA-Library="+LIB,"tlc2.TLC"] if uselib else [])+["-noTE","-workers",w]+opts+["-config",cfg,root]
            o,e,rc=runone(cmd)
            dec="prove-it: not native yet" in e
            res[vk][name+w]={"rc":rc,"out":norm(o),"decline":dec,"err":e[-600:],"raw":o[-3000:]}
json.dump(res,open(os.path.join(case,"result3.json"),"w"),indent=1)
