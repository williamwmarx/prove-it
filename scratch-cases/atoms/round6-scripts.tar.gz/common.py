import os
BASE="/tmp/claude-0/adv8/round6/cases"
def emit(name, files, cfg, opts, root="M", lib=False):
    d=os.path.join(BASE,name); os.makedirs(d,exist_ok=True)
    for fn,c in files.items(): open(os.path.join(d,fn),"w").write(c)
    open(os.path.join(d,root+".cfg"),"w").write(cfg)
    if opts: open(os.path.join(d,"opts"),"w").write(" ".join(opts))
    if root!="M": open(os.path.join(d,"root"),"w").write(root)
    if lib: open(os.path.join(d,"lib"),"w").write("1")
