#!/usr/bin/env python3
import json, glob, collections, sys

res = {}
for f in glob.glob("/tmp/claude-0/rerun/res_*.jsonl"):
    for l in open(f):
        r = json.loads(l)
        res[r["id"]] = r
jobs = {json.loads(l)["id"]: json.loads(l) for l in open("/tmp/claude-0/rerun/jobs.jsonl")}

tot = collections.Counter()
chg = collections.Counter()
verbose = "-v" in sys.argv
for i, r in sorted(res.items()):
    tot[r["round"]] += 1
    if r["same"]:
        continue
    chg[r["round"]] += 1
    j = jobs[i]
    def st(b, ref_norm, ref_code):
        if b["v"] == "DECLINE":
            return "DECLINE"
        return "match" if (b["norm"] == ref_norm and b["code"] == ref_code) else "DIFF"
    dr = r["default_rerun"]
    repro = dr["norm"] == r["stored_norm"] and dr["code"] == r["stored_code"]
    line = []
    for k, b in r["bins"].items():
        old = st(b, r["stored_norm"], r["stored_code"])
        new = st(b, r["new_norm"], r["new_code"])
        line.append(f"{k}:{old}->{new}")
    print(f"R{r['round']} id={i} {r['case']} {' '.join(j['args'][5:])} codes {r['stored_code']}->{r['new_code']} default_repro={repro} :: {' '.join(line)}")
    if verbose:
        print("--- stored (default mode)\n" + str(r["stored_norm"]) + "\n--- new (-noTE)\n" + str(r["new_norm"]))
        for k, b in r["bins"].items():
            print(f"--- {k} code={b['code']}\n" + str(b.get("norm", b.get("err"))))
        print("=" * 60)
print("total", dict(tot), "changed", dict(chg))
