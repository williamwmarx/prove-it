#!/usr/bin/env python3
# Builds /tmp/claude-0/rerun/jobs.jsonl: one entry per stored jar run of the five rounds.
import os, re, json, glob, ast

OUT = "/tmp/claude-0/rerun/jobs.jsonl"
LIB = "/home/user/prove-it/packages/prove-it/tests/conformance/.library"
BASE = ["-nowarning", "-seed", "4", "-fp", "0"]
DROP = ("Progress(", "Finished computing initial states", "Checking ", "Finished checking temporal properties")


def norm(t):
    s = t.find("Starting... (")
    if s < 0:
        return None
    out = []
    for l in t[s:].split("\n")[1:]:
        if l.startswith("Finished in"):
            break
        if l.startswith(DROP):
            continue
        out.append(re.sub(r"\d{4}-\d\d-\d\d \d\d:\d\d:\d\d", "TS", l))
    return "\n".join(out)


jobs = []


def add(**k):
    k["id"] = len(jobs)
    jobs.append(k)


# Round 1
R = "/tmp/claude-0/adv/round1"
for f in sorted(glob.glob(R + "/cases*/*/result*.txt")):
    case = os.path.dirname(f)
    tag = os.path.basename(f)[len("result"):-4]
    extra = tag.split("_") if tag else []
    t = open(f).read()
    m = re.match(r"===== tlc exit=(-?\d+)\n", t)
    body = t[m.end():t.index("\n----- raw\n")]
    tla = [x for x in glob.glob(case + "/*.tla") if not os.path.basename(x).startswith("_")]
    mods = [os.path.basename(x)[:-4] for x in tla]
    main = [x for x in mods if os.path.exists(f"{case}/{x}.cfg")][0]
    add(round=1, case=case, mode="copy", jvm=["-Xmx2g", "-XX:+UseSerialGC"], lib=False,
        args=BASE + extra, mod=main, cfg=main, stored_norm=None if body == "(none)" else body,
        stored_code=int(m.group(1)), bins={"main": "/tmp/claude-0/adv/main-bin", "branch": "/tmp/claude-0/adv/branch-bin"},
        ws=["1", "4"], src=f)

# Round 2
R = "/tmp/claude-0/adv2/round2"
for f in sorted(glob.glob(R + "/**/result_*.txt", recursive=True)):
    case = os.path.dirname(f)
    t = open(f).read()
    opts = ast.literal_eval(re.search(r"^opts=(.*)$", t, re.M).group(1))
    m = re.search(r"^===== tlc exit=(-?\d+)\n", t, re.M)
    body = t[m.end():t.index("\n===== main1 exit=")]
    add(round=2, case=case, mode="copy", jvm=["-XX:+UseSerialGC", "-Xmx512m"], lib=False, metadir=True,
        args=BASE + opts, mod="M", cfg="M", stored_norm=body, stored_code=int(m.group(1)), norm_none="",
        bins={"main": "/tmp/claude-0/adv2/main-bin", "branch": "/tmp/claude-0/adv2/branch-bin"}, ws=["1", "4"], src=f)

# Round 3
R = "/tmp/claude-0/adv3/round3"
r3 = {}
for j in ["A", "D", "D3", "E", "E2", "F", "F2", "G", "G2", "M"]:
    d = R + "/" + ("cases" if j == "A" else "cases" + j)
    for l in open(f"{R}/{j}.jsonl"):
        r = json.loads(l)
        r3[(d + "/" + r["case"], r["opts"])] = (r, j)
for (case, opts), (r, j) in sorted(r3.items()):
    add(round=3, case=case, mode="copy", jvm=["-XX:+UseSerialGC", "-Xmx400m"], lib=False,
        args=opts.split(), mod="M", cfg="M", stored_norm=r["tlc"], stored_code=r["tlc_code"], norm_none="RAW",
        bins={"main": "/tmp/claude-0/adv3/main-bin", "branch": "/tmp/claude-0/adv3/branch-bin"}, ws=["1", "4"],
        src=f"{j}.jsonl", stored_bins={k: r[k] for k in ("main1", "main4", "branch1", "branch4")})

# Round 4
R = "/tmp/claude-0/adv5/round4"
codes = {}
def rec(case, r):
    codes[(case, tuple(r["opts"]))] = r
for f in glob.glob(R + "/**/res*.json", recursive=True):
    r = json.loads(open(f).read())
    rec(os.path.dirname(f), r)
def objs(t):
    dec = json.JSONDecoder(); i = 0; t = t.strip()
    while i < len(t):
        o, e = dec.raw_decode(t, i); yield o
        i = e
        while i < len(t) and t[i].isspace(): i += 1
for f in glob.glob(R + "/cases/*/res.txt"):
    for r in objs(open(f).read()):
        rec(os.path.dirname(f) + "/" + r["case"], r)
for f in glob.glob(R + "/java_*.res"):
    for r in objs(open(f).read()):
        rec(R + "/" + r["case"], r)
for f in sorted(glob.glob(R + "/**/jar*.out", recursive=True)):
    case = os.path.dirname(f)
    tag = os.path.basename(f)[3:-4]
    if tag == "-workers-1":
        continue
    toks = tag.split("-")[1:] if tag else []
    opts, dash = [], True
    for t in toks:
        if t == "":
            dash = True
            continue
        opts.append("-" + t if dash else t)
        dash = False
    raw = open(f).read()
    stdout = raw.rsplit("\n--stderr--\n", 1)[0]
    corpus = "/corpus/" in case
    lib = corpus or "conformance/.library" in raw
    if corpus:
        mod = os.path.basename(case).split("__")[-1]
    else:
        mod = "M"
    r = codes.get((case, tuple(opts)))
    add(round=4, case=case, mode="inplace", jvm=["-XX:+UseParallelGC", "-Xmx1g"], lib=lib,
        args=BASE + opts, mod=mod, cfg=mod, stored_norm=norm(stdout), stored_code=None if r is None else r["jar"],
        bins={"main": "/tmp/claude-0/adv5/main-bin", "branch": "/tmp/claude-0/adv5/branch-bin"},
        ws=["1", "4"], src=f, stored_bins=None if r is None else {k: r.get(k) for k in ("main1", "main4", "branch1", "branch4")},
        opts_tag=tag)

# Round 5 (fairness)
R = "/tmp/claude-0/adv6/round"
for f in sorted(glob.glob(R + "/**/res.json", recursive=True)):
    case = os.path.dirname(f)
    sets = [[], ["-lncheck", "final"]]
    if os.path.exists(case + "/opts"):
        extra = [l.split() for l in open(case + "/opts").read().splitlines() if l.strip()]
        sets = [s + e for e in extra for s in sets]
    for opts in sets:
        tag = "_".join(o.strip("-") for o in opts) or "plain"
        jf = f"{case}/jar.{tag}.out"
        if not os.path.exists(jf):
            continue
        raw = open(jf).read()
        m = re.search(r"\n--code (-?\d+)\n$", raw)
        stdout = raw.rsplit("\n--stderr--\n", 1)[0]
        add(round=5, case=case, mode="inplace", jvm=["-XX:+UseSerialGC", "-Xmx1g"], lib=False,
            args=BASE + opts, mod="M", cfg="M", stored_norm=norm(stdout), stored_code=int(m.group(1)),
            bins={"main": "/tmp/claude-0/adv6/main-bin", "branch": "/tmp/claude-0/adv6/branch-bin"},
            ws=["1", "4"], src=jf)

with open(OUT, "w") as o:
    for j in jobs:
        o.write(json.dumps(j) + "\n")
import collections
print(collections.Counter(j["round"] for j in jobs))
print("no code:", [(j["case"], j["args"]) for j in jobs if j["stored_code"] is None])
