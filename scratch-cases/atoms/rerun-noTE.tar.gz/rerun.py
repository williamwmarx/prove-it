#!/usr/bin/env python3
# usage: rerun.py SHARD NSHARDS   -- processes jobs.jsonl entries with id % NSHARDS == SHARD
import json, os, re, sys, shutil, subprocess, resource, glob

JAR = "/home/user/tlc/tlaplus/tlatools/org.lamport.tlatools/tla2tools.jar"
LIB = "/home/user/prove-it/packages/prove-it/tests/conformance/.library"
W = "/tmp/claude-0/rerun"
DROP = ("Progress(", "Finished computing initial states", "Checking ", "Finished checking temporal properties")
DECLINE = "prove-it: not native yet"


def norm(t):
    s = t.find("Starting... (")
    if s < 0:
        return None
    out = []
    for l in t[s:].split("\n")[1:]:
        if l.startswith("Finished in"):
            break
        if l.startswith(DROP):
            continue
        out.append(re.sub(r"\d{4}-\d\d-\d\d \d\d:\d\d:\d\d", "TS", l))
    return "\n".join(out)


def stored_key(j):
    s = j["stored_norm"]
    if s is None:
        return None
    if j["round"] == 2 and s == "":
        return None
    if j["round"] == 3 and (s.startswith("TLC2 Version") or "Running " in s.split("\n")[0]):
        return None
    return "\n".join(re.sub(r"\d{4}-\d\d-\d\d \d\d:\d\d:\d\d", "TS", l) for l in s.split("\n"))


def lim():
    resource.setrlimit(resource.RLIMIT_AS, (4000000 * 1024, 4000000 * 1024))


def prep(j, wd):
    if j["mode"] == "inplace":
        return j["case"]
    d = wd + "/case"
    os.makedirs(d)
    for f in os.listdir(j["case"]):
        if f.endswith((".tla", ".cfg")):
            shutil.copy(os.path.join(j["case"], f), d)
    return d


def jar(j, cwd, wd, te):
    jt = wd + "/jt"
    os.makedirs(jt, exist_ok=True)
    cmd = ["java"] + j["jvm"] + ["-XX:SharedArchiveFile=%s/tlc_r%d.jsa" % (W, j["round"]), "-XX:+AutoCreateSharedArchive", "-Xlog:cds=off", "-Xlog:cds+dynamic=off", "-Djava.io.tmpdir=" + jt] + (["-DTLA-Library=" + LIB] if j["lib"] else []) + \
        ["-cp", JAR, "tlc2.TLC"] + ([] if te else ["-noTE"]) + ["-workers", "1", "-metadir", wd + "/meta"] + \
        j["args"] + ["-config", j["cfg"] + ".cfg", j["mod"]]
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    shutil.rmtree(jt, ignore_errors=True)
    shutil.rmtree(wd + "/meta", ignore_errors=True)
    for f in glob.glob(os.path.join(cwd, "*_TTrace_*")):
        os.remove(f)
    return p.returncode, p.stdout, p.stderr


def binrun(j, cwd, b, w):
    cmd = [b] + (["-DTLA-Library=" + LIB, "tlc2.TLC"] if j["lib"] else []) + ["-noTE", "-workers", w] + \
        j["args"] + ["-config", j["cfg"] + ".cfg", j["mod"]]
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, preexec_fn=lim)
    shutil.rmtree(os.path.join(cwd, "states"), ignore_errors=True)
    if DECLINE in p.stderr:
        return {"v": "DECLINE", "code": p.returncode, "err": p.stderr.strip()[-300:]}
    return {"v": "out", "code": p.returncode, "norm": norm(p.stdout), "tail": (p.stdout + "\n--stderr--\n" + p.stderr)[-1500:]}


def main():
    shard, n = int(sys.argv[1]), int(sys.argv[2])
    out = os.environ.get("OUT", f"{W}/res_{shard}.jsonl")
    done = set()
    if os.path.exists(out):
        for l in open(out):
            done.add(json.loads(l)["id"])
    skip = {int(x) for x in open(W + "/skip.txt").read().split()}
    jobs = [json.loads(l) for l in open(os.environ.get("JOBS", W + "/jobs.jsonl"))]
    with open(out, "a") as o:
        for j in jobs:
            if j["id"] % n != shard or j["id"] in done or j["id"] in skip:
                continue
            wd = f"{W}/tmp/j{j['id']}"
            shutil.rmtree(wd, ignore_errors=True)
            os.makedirs(wd)
            cwd = prep(j, wd)
            c, so, se = jar(j, cwd, wd, False)
            nn = norm(so)
            r = {"id": j["id"], "round": j["round"], "case": j["case"], "args": j["args"], "new_code": c, "new_norm": nn}
            sk = stored_key(j)
            sc = j["stored_code"]
            if sc is None:
                dc, dso, _ = jar(j, cwd, wd, True)
                sc = dc
                sk = norm(dso)
                r["stored_from_rerun"] = True
            r["stored_code"] = sc
            r["same"] = (nn == sk and c == sc)
            if not r["same"]:
                r["stored_norm"] = sk
                r["new_raw"] = (so + "\n--stderr--\n" + se)[-4000:]
                dc, dso, dse = jar(j, cwd, wd, True)
                r["default_rerun"] = {"code": dc, "norm": norm(dso)}
                r["bins"] = {}
                for name, b in j["bins"].items():
                    for w in j["ws"]:
                        r["bins"][name + w] = binrun(j, cwd, b, w)
            shutil.rmtree(wd, ignore_errors=True)
            o.write(json.dumps(r) + "\n")
            o.flush()


main()
