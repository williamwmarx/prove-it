---- MODULE M ----
EXTENDS Integers, FiniteSets, TLC
VARIABLE x
f2 == CHOOSE g \in [0..1 -> {0}] : TRUE
fill == [i \in 0..9 |-> i]
I == INSTANCE Inner WITH K <- fill
U == LET k == IF x < 2 THEN 0 ELSE 5 IN [j \in DOMAIN (I!G) |-> (I!G)[j]][k]
Init == x = 0
Next == x < 3 /\ x' = x + 1 /\ U # -99
Inv == U # -99
AC == U # -99
====
