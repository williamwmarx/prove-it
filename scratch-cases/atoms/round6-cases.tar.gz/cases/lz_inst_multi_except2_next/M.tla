---- MODULE M ----
EXTENDS Integers, FiniteSets, TLC
VARIABLE x
f2 == [i \in 0..1, j \in 0..1 |-> i + j]
fill == [i \in 0..9 |-> i]
I == INSTANCE Inner WITH K <- fill
U == LET k == IF x < 2 THEN <<0, 0>> ELSE <<5, 0>> IN [[(I!G) EXCEPT ![<<0, 0>>] = 9] EXCEPT ![<<0, 0>>] = 8][k]
Init == x = 0
Next == x < 3 /\ x' = x + 1 /\ U # -99
Inv == U # -99
AC == U # -99
====
