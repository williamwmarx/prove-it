---- MODULE M ----
EXTENDS Integers, FiniteSets, TLC, Lib
VARIABLE x
f2 == [i \in Nat |-> i]
fill == [i \in 0..9 |-> i]
U == LET k == IF x < 2 THEN 0 ELSE -1 IN [r |-> (G)].r[k]
Init == x = 0
Next == x < 3 /\ x' = x + 1 /\ U # -99
Inv == U # -99
AC == U # -99
====
