---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, FiniteSets
VARIABLES x, y
vars == <<x, y>>
f == [i \in 0..2 |-> i]
Op(k) == f[k]
RECURSIVE R(_)
R(n) == IF n = 0 THEN f[9] ELSE R(n-1)

Init == x = 0 /\ y = 0
Inc(v) == v < 3
A(i) == x < 3 /\ x' = x + i /\ UNCHANGED y
Next == \E i \in {1} : A(i) \/ (y < 2 /\ y' = y + 1 /\ UNCHANGED x)
Spec == Init /\ [][Next]_vars
AC == TLCGet("level") < 3 \/ f[x'] = 0
====
