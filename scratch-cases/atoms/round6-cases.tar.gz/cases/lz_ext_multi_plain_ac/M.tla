---- MODULE M ----
EXTENDS Integers, FiniteSets, TLC, Lib
VARIABLE x
f2 == [i \in 0..1, j \in 0..1 |-> i + j]
fill == [i \in 0..9 |-> i]
U == LET k == IF x' < 2 THEN <<0, 0>> ELSE <<5, 0>> IN (G)[k]
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == U # -99
AC == U # -99
====
