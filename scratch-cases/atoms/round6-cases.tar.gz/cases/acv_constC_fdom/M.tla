---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, FiniteSets
VARIABLES x, y
vars == <<x, y>>
f == [i \in 0..2 |-> i]
Op(k) == f[k]
RECURSIVE R(_)
R(n) == IF n = 0 THEN f[9] ELSE R(n-1)
Cn == x < 3
Cp == x < 9
AF == x' # 3
Inv3 == x # 3
Inv1 == x # 1
V == <<x, y>>
P == <>(x = 3)
AP == [][x' >= x]_vars
Post == TLCGet("distinct") > 0
TRUEInv == TRUE
Init2 == x \in {0, 1} /\ y = 0
ACc == f[3] = 0
ACs == f[x] >= 0

Init == x = 0 /\ y = 0
A == x < 3 /\ x' = x + 1 /\ UNCHANGED y
B == y < 2 /\ y' = y + 1 /\ UNCHANGED x
Next == A \/ B
Spec == Init /\ [][Next]_vars
AC == f[x']>= 0
====
