---- MODULE M ----
EXTENDS Integers, FiniteSets, TLC, Lib
VARIABLE x
f2 == [i \in 0..1 |-> i]
fill == [i \in 0..9 |-> i]
U == LET k == IF x < 2 THEN 0 ELSE 5 IN LET Ap(H) == H[k] IN Ap((G))
Init == x = 0
Next == x < 3 /\ x' = x + 1 /\ U # -99
Inv == U # -99
AC == U # -99
====
