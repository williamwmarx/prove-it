---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, FiniteSets
VARIABLES x, y
vars == <<x, y>>
f == [i \in 0..2 |-> i]
Op(k) == f[k]
RECURSIVE R(_)
R(n) == IF n = 0 THEN f[9] ELSE R(n-1)

Init == x = 0 /\ y = 0
Next == \E i \in 1..2 : x + i <= 4 /\ x' = x + i /\ y' = y
Spec == Init /\ [][Next]_vars
AC == Assert(x' < 3, "too big")
====
