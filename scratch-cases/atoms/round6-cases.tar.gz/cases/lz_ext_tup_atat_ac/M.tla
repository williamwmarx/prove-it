---- MODULE M ----
EXTENDS Integers, FiniteSets, TLC, Lib
VARIABLE x
f2 == <<0, 1>>
fill == [i \in 0..9 |-> i]
U == LET k == IF x' < 2 THEN 1 ELSE 5 IN ((G) @@ (77 :> 7))[k]
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == U # -99
AC == U # -99
====
