---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
J == INSTANCE InnerNP
Init == x = 0
Next == x < 2 /\ x' = x + 1
====
