---- MODULE InnerNP ----
EXTENDS TLC
p == PrintT("innernp")
====
