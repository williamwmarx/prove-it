---- MODULE M ----
EXTENDS Integers, FiniteSets, TLC, Lib
VARIABLE x
f2 == [s \in SUBSET {1, 2} |-> Cardinality(s)]
fill == [i \in 0..9 |-> i]
U == LET k == IF x < 2 THEN {} ELSE {3} IN LET z == (G) IN z[k]
Init == x = 0
Next == x < 3 /\ x' = x + 1 /\ U # -99
Inv == U # -99
AC == U # -99
====
