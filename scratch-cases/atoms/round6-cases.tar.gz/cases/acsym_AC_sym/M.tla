---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, FiniteSets
CONSTANT P
VARIABLES x, y
vars == <<x, y>>
Init == x = {} /\ y = 0
Next == \E p \in P : p \notin x /\ x' = x \cup {p} /\ y' = y + 1
Sym == Permutations(P)
AC == Cardinality(x') < 2 \/ <<1>>[y' + 5] = 1
AC2 == y' = 2 => (CHOOSE q \in x' : TRUE) = 1
====
