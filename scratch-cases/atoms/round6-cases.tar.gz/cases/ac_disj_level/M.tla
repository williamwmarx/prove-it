---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, FiniteSets
VARIABLES x, y
vars == <<x, y>>
f == [i \in 0..2 |-> i]
Op(k) == f[k]
RECURSIVE R(_)
R(n) == IF n = 0 THEN f[9] ELSE R(n-1)

Init == x = 0 /\ y = 0
A == x < 3 /\ x' = x + 1 /\ UNCHANGED y
B == y < 2 /\ y' = y + 1 /\ UNCHANGED x
Next == A \/ B
Spec == Init /\ [][Next]_vars
AC == TLCGet("level") < 3 \/ f[x'] = 0
====
