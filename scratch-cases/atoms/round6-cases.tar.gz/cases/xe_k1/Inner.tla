---- MODULE Inner ----
EXTENDS Naturals, FiniteSets
CONSTANT K
VARIABLE x
G == [i \in 0..9 |-> i + K]
Look(k) == G[k]
====
