---- MODULE M ----
EXTENDS Integers, TLC, Sequences
VARIABLE x
r == RandomElement(1..1000)
r2 == RandomElement(1..1000)
p == PrintT("root")
q == PrintT("q")
h == [i \in 0..1 |-> i]
h2 == [i \in 0..1 |-> i * 3]
hb == [i \in 0..1 |-> 10 \div (i - 1)]
hz == [i \in 0..1 |-> 10 \div (i - 0)]
lv == TLCGet("level")
I == INSTANCE Inner WITH K <- 1
J == INSTANCE InnerNP
Init == x = 0
Next == x < 3 /\ x' = x + 1 /\ J!r > 0
Inv == p /\ h[x] >= 0
FailNext == Next /\ p /\ h[x] >= 0
====
