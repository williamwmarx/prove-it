---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
J == INSTANCE InnerNP
Init == x = 0
Next == x < 3 /\ x' = x + 1 + TLCGet("level") * 0
h == [i \in 0..1 |-> i]
Inv == h[x] >= 0
====
