---- MODULE M ----
EXTENDS Integers, FiniteSets, TLC
VARIABLE x
f2 == [s \in {"a", "b"} |-> 1]
fill == [i \in 0..9 |-> i]
I == INSTANCE Inner WITH K <- fill
U == LET k == IF x < 2 THEN "a" ELSE "z" IN [[(I!G) EXCEPT !["a"] = 9] EXCEPT !["a"] = 8][k]
Init == x = 0
Next == x < 3 /\ x' = x + 1 /\ U # -99
Inv == U # -99
AC == U # -99
====
