---- MODULE M ----
EXTENDS Integers, FiniteSets, TLC
VARIABLE x
f2 == [i \in Nat |-> i]
U == LET k == IF x < 2 THEN 0 ELSE -1 IN IF (f2) \in [DOMAIN (f2) -> Int \cup {0}] THEN (f2)[k] ELSE 0
Init == x = 0
Next == x < 3 /\ x' = x + 1 /\ U # -99
====
