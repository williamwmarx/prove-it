---- MODULE M ----
EXTENDS Integers, FiniteSets, TLC, Lib
VARIABLE x
f2 == [a |-> 0, b |-> 1]
fill == [i \in 0..9 |-> i]
U == LET k == IF x < 2 THEN "a" ELSE "c" IN [(G) EXCEPT !["a"] = 9][k]
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == U # -99
AC == U # -99
====
