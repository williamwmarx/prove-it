---- MODULE Inner ----
EXTENDS Naturals
CONSTANT K
VARIABLE x
IW == x < K

====
