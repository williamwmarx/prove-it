---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLES x, y
vars == <<x, y>>
Init == x = 0 /\ y = 0
Next == \/ x < 3 /\ x' = x + 1 /\ UNCHANGED y
        \/ y < 2 /\ y' = y + 1 /\ UNCHANGED x
W == x < 2
W2 == x' < 2
Wy == y < 1
Wy2 == y' < 1
WF(a) == x < a
WFn[i \in 0..1] == x < 2
f9 == [i \in 0..1 |-> i]
Wbad == f9[x] = 0
V == x < 1
LOCAL LW == x < 1

====
