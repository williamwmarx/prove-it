---- MODULE M ----
EXTENDS Integers, FiniteSets, TLC
VARIABLE x
f2 == [i \in 0..1, j \in 0..1 |-> i + j]
fill == [i \in 0..9 |-> i]
I == INSTANCE Inner WITH K <- fill
U == LET k == IF x < 2 THEN <<0, 0>> ELSE <<5, 0>> IN (IF k = <<0, 0>> THEN (I!G) ELSE (I!G))[k]
Init == x = 0
Next == x < 3 /\ x' = x + 1 /\ U # -99
Inv == U # -99
AC == U # -99
====
