---- MODULE InnerNP ----
EXTENDS Integers, TLC
r == RandomElement(1..1000)
p == PrintT("innernp")
h == [i \in 0..1 |-> i]
hb == [i \in 0..1 |-> 10 \div (i - 1)]
====
