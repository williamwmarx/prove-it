---- MODULE Inner ----
EXTENDS Integers, TLC
CONSTANT K
VARIABLE x
r == RandomElement(1..1000)
p == PrintT(<<"inner", K>>)
h == [i \in 0..1 |-> i + K]
hb == [i \in 0..1 |-> 10 \div (i - K)]
Look(k) == h[k]
====
