---- MODULE Inner ----
EXTENDS Naturals, FiniteSets
CONSTANT K
VARIABLE x
G == K
Look(k) == G[k]
====
