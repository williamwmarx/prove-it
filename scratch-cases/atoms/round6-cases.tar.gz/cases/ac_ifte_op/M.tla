---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, FiniteSets
VARIABLES x, y
vars == <<x, y>>
f == [i \in 0..2 |-> i]
Op(k) == f[k]
RECURSIVE R(_)
R(n) == IF n = 0 THEN f[9] ELSE R(n-1)

Init == x = 0 /\ y = 0
Next == IF x < 3 THEN x' = x + 1 /\ UNCHANGED y ELSE x' = 0 /\ y' = y + 1
Spec == Init /\ [][Next]_vars
AC == Op(x') >= 0
====
