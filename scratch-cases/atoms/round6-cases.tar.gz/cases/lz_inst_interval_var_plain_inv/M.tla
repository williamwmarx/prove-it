---- MODULE M ----
EXTENDS Integers, FiniteSets, TLC
VARIABLE x
f2 == [i \in 0..1 |-> i * 2]
fill == [i \in 0..9 |-> i]
I == INSTANCE Inner WITH K <- fill
U == LET k == IF x < 2 THEN 1 ELSE 2 IN (I!G)[k]
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == U # -99
AC == U # -99
====
