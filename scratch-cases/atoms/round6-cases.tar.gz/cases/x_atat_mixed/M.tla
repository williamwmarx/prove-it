---- MODULE M ----
EXTENDS Integers, TLC, FiniteSets
VARIABLE x
g == [s \in SUBSET {1, 2} |-> Cardinality(s)]
Init == x = 0
Next == x < 3 /\ x' = x + 1 /\ (g @@ (77 :> 7))[IF x < 2 THEN {} ELSE {3}] # -99
====
