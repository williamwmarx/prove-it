---- MODULE Lib ----
EXTENDS Naturals, FiniteSets
G == [i \in 0..9 |-> i]
Look(k) == G[k]
====
