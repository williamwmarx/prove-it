---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, FiniteSets
VARIABLES x, y
vars == <<x, y>>
f == [i \in 0..2 |-> i]
Op(k) == f[k]
RECURSIVE R(_)
R(n) == IF n = 0 THEN f[9] ELSE R(n-1)

Init == x = 0 /\ y = 0
Next == LET n == x + 1 IN n <= 3 /\ x' = n /\ UNCHANGED y
Spec == Init /\ [][Next]_vars
AC == f[x + 1] >= 0
====
