---- MODULE M ----
EXTENDS Naturals, TLC
---- MODULE Inner ----
C == 3
====
I == INSTANCE Inner
VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < 2
Alias == I!C

====
