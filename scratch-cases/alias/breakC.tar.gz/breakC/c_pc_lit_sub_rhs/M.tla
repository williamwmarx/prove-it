---- MODULE M ----
EXTENDS Naturals, TLC
CONSTANT K
VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1
PC == TRUE

====
