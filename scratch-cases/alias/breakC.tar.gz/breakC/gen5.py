import json
V="VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n"
W="VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 5\n"
inv="INIT Init\nNEXT Next\nINVARIANT Inv\n"
c=[]
def a(n,t,cfg): c.append([n,t,cfg])
R="Q == [y |-> x]\n"
a("assign_sub_noviol", W+R+"Alias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias = 3\nCONSTANT Alias <- Q")
a("sub_then_assign", V+R+"Alias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias <- Q\nCONSTANT Alias = 3")
a("assign_sub_lit", V+"Q == 4\nAlias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias = 3\nCONSTANT Alias <- Q")
a("assign_sub_deadlock", "VARIABLE x\nInit == x = 0\nNext == x < 2 /\\ x' = x + 1\n"+R+"Alias == [z |-> x]\n", "INIT Init\nNEXT Next\nALIAS Alias\nCONSTANT Alias = 3\nCONSTANT Alias <- Q")
a("assign_sub_mv", V+R+"Alias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias = Alias\nCONSTANT Alias <- Q")
a("pc_assign_sub", "VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nPC == x = 9\nPB == x = 3\n", "INIT Init\nNEXT Next\nPOSTCONDITION PC\nCONSTANT PC = TRUE\nCONSTANT PC <- PB")
a("modasg", V+"Alias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias = [M] 3")
a("modsub", V+R+"Alias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias <- [M] Q")
a("inner_const", "---- MODULE Inner ----\nCONSTANT Alias\nUse == Alias\n====\nI == INSTANCE Inner WITH Alias <- 3\n"+V.replace("x < 2","x < I!Use - 1")+"Alias == [z |-> x]\n", inv+"ALIAS Alias")
a("inner_lit_alias", "---- MODULE Inner ----\nC == 3\n====\nI == INSTANCE Inner\n"+V+"Alias == I!C\n", inv+"ALIAS Alias")
json.dump(c,open('c5.json','w'))
