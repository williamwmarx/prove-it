import json
V="VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n"
inv="INIT Init\nNEXT Next\nINVARIANT Inv\n"
c=[]
def a(n,t,cfg): c.append([n,t,cfg])
R="Q == [y |-> x]\n"
# substitutions/assignments
a("sub_state", V+R+"Alias == 7\n", inv+"ALIAS Alias\nCONSTANT Alias <- Q")
a("sub_const", V+"Q == [y |-> 1]\nAlias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias <- Q")
a("sub_lit", V+"Q == 5\nAlias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias <- Q")
a("sub_to_assigned", V+"Q == [y |-> x]\nAlias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias <- Q\nCONSTANT Q = 3")
a("assign_and_sub", V+R+"Alias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias = 3\nCONSTANT Alias <- Q")
a("assign_def", V+"Alias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias = 3")
a("assign_mv", V+"Alias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias = Alias")
a("assign_set", V+"Alias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias = {a, b}")
a("assign_str", V+"Alias == [z |-> x]\n", inv+'ALIAS Alias\nCONSTANT Alias = "s"')
a("decl_sub", "CONSTANT Alias\n"+V+R, inv+"ALIAS Alias\nCONSTANT Alias <- Q")
a("decl_sub_lit", "CONSTANT Alias\n"+V+"Q == 3\n", inv+"ALIAS Alias\nCONSTANT Alias <- Q")
a("sub_to_declconst", "CONSTANT K\n"+V+"Alias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT K = 2\nCONSTANT Alias <- K")
a("chain", V+R+"P == [w |-> x]\nAlias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias <- Q\nCONSTANT Q <- P")
a("sub_args", V+"Q(a) == [y |-> a]\nAlias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias <- Q")
a("sub_both_args", V+"Q(a) == [y |-> a]\nAlias(b) == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias <- Q")
a("sub_self", V+"Alias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias <- Alias")
a("sub_err", V+"Q == [y |-> 1 \\div 0]\nAlias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias <- Q")
a("sub_tlcget", V+"Q == [y |-> TLCGet(\"level\")]\nAlias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias <- Q")
a("sub_from_lit", V+R+"Alias == 3\n", inv+"ALIAS Alias\nCONSTANT Alias <- Q")
a("sub_lit2lit", V+'Q == "q"\nAlias == 3\n', inv+"ALIAS Alias\nCONSTANT Alias <- Q")
json.dump(c,open('c2.json','w'))
