---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Alias == 1
Init == x = Alias
Next == x < 3 /\ x' = x + 1
Inv == x < 2

====
