import sys, os, subprocess, json
S='/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad'
D=S+'/breakC'
BASE_HEAD="---- MODULE M ----\nEXTENDS Naturals, TLC\n"
def case(name, tla, cfg):
    d=f'{D}/c_{name}'; os.makedirs(d, exist_ok=True)
    open(f'{d}/M.tla','w').write(BASE_HEAD+tla+"\n====\n")
    open(f'{d}/M.cfg','w').write(cfg+"\n")
    r=subprocess.run(['bash',S+'/case3C.sh',f'{d}/M.tla',f'{d}/M.cfg'],capture_output=True,text=True)
    print(f'== {name}\n{r.stdout}{r.stderr}',flush=True)
cases=json.load(open(sys.argv[1]))
for c in cases:
    if len(sys.argv)>2 and c[0] not in sys.argv[2:]: continue
    case(*c)
