---- MODULE M ----
EXTENDS Naturals, TLC
C == 3
D == C + 1
VARIABLE x
Init == x = C
Next == x < D+1 /\ x' = x + 1
Inv == x < D
ASSUME C = 3
ASSUME PrintT(<<C, D>>)
Alias == [c |-> C, x |-> x]

====
