import json
V="VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n"
inv="INIT Init\nNEXT Next\nINVARIANT Inv\n"
c=[]
def a(n,t,cfg): c.append([n,t,cfg])
for n,body in [("num","3"),("str",'"a"'),("zero","0"),("max","2147483647"),("hex","\\h1F"),("bin","\\b101"),("oct","\\o17"),("empty",'""'),("esc",'"a\\"b\\\\c"'),("paren","(3)"),("neg","-3"),("true","TRUE"),("set","{1,2}"),("rec","[a |-> 1]"),("big","2147483648"),("pparen","((\"s\"))")]:
    a("alias_"+n, V+"Alias == "+body+"\n", inv+"ALIAS Alias")
json.dump(c,open('c1.json','w'))
