import json
V="VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n"
W="VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\n"
inv="INIT Init\nNEXT Next\nINVARIANT Inv\n"
ok="INIT Init\nNEXT Next\n"
c=[]
def a(n,t,cfg): c.append([n,t,cfg])
for n,b in [("num","3"),("str",'"a"'),("true","TRUE"),("zero","0"),("hex","\\h0"),("empty",'""')]:
    a("pc_"+n, W+"PC == "+b+"\n", ok+"POSTCONDITION PC")
a("pc_two", W+'PC == 3\nPD == "b"\n', ok+"POSTCONDITION PC\nPOSTCONDITION PD")
a("pc_lit_inv", V+'PC == 3\n', inv+"POSTCONDITION PC")
a("pc_sub", W+'PC == 3\nPB == x = 3\n', ok+"POSTCONDITION PC\nCONSTANT PC <- PB")
a("pc_assign", W+'PC == x = 3\n', ok+"POSTCONDITION PC\nCONSTANT PC = TRUE")
a("pc_sub_true", W+'PC == x = 3\nT == TRUE\n', ok+"POSTCONDITION PC\nCONSTANT PC <- T")
a("view_num", V+"Vw == 3\n", inv+"VIEW Vw")
a("view_str", V+'Vw == "v"\n', inv+"VIEW Vw")
a("cons_num", V+"Cn == 3\n", inv+"CONSTRAINT Cn")
a("cons_true", V+"Cn == TRUE\n", inv+"CONSTRAINT Cn")
a("inv_num", W+"I2 == 3\n", ok+"INVARIANT I2")
a("inv_str", W+'I2 == "s"\n', ok+"INVARIANT I2")
a("sym_num", V+"Sy == 3\n", inv+"SYMMETRY Sy")
a("prop_num", W+"Pr == 3\n", ok+"PROPERTY Pr")
a("prop_str", W+'Pr == "a"\n', ok+"PROPERTY Pr")
a("spec_num", W+"Sp == 3\n", "SPECIFICATION Sp")
a("ac_num", W+"AC == 3\n", ok+"ACTION_CONSTRAINT AC")
# literal defs referenced elsewhere
a("ref_c", "C == 3\nD == C + 1\nVARIABLE x\nInit == x = C\nNext == x < D+1 /\\ x' = x + 1\nInv == x < D\nASSUME C = 3\nASSUME PrintT(<<C, D>>)\nAlias == [c |-> C, x |-> x]\n", inv+"ALIAS Alias")
a("ref_alias_c", "C == 3\nVARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\nAlias == C\n", inv+"ALIAS Alias")
a("alias_ref_lit", "C == 3\nVARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\nAlias == C\n", inv+"ALIAS Alias")
a("alias_in_inv", V.replace("Inv == x < 2","Inv == x < Alias")+"Alias == 2\n", inv+"ALIAS Alias")
a("alias_in_init", "VARIABLE x\nAlias == 1\nInit == x = Alias\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n", inv+"ALIAS Alias")
a("alias_str_cfgget", V+'Alias == "q"\nASSUME PrintT(TLCGet("config").alias)\n', inv+"ALIAS Alias")
a("alias_num_deadlock", "VARIABLE x\nInit == x = 0\nNext == x < 2 /\\ x' = x + 1\nAlias == 5\n", ok+"ALIAS Alias")
a("alias_str_live", "VARIABLE x\nInit == x = 0\nNext == x' = (x + 1) % 3\nSpec == Init /\\ [][Next]_x\nP == <>(x = 5)\nAlias == \"s\"\n", "SPECIFICATION Spec\nPROPERTY P\nALIAS Alias")
a("alias_num_action", "VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nSpec == Init /\\ [][Next]_x\nP == [][x' = x + 2]_x\nAlias == 9\n", "SPECIFICATION Spec\nPROPERTY P\nALIAS Alias")
a("alias_str_tool", V+'Alias == "a b"\n', inv+"ALIAS Alias")
a("alias_unicode", V+'Alias == "\\t\\n"\n', inv+"ALIAS Alias")
json.dump(c,open('c3.json','w'))
