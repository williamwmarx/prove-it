import json
V="VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n"
inv="INIT Init\nNEXT Next\nINVARIANT Inv\n"
c=[]
def a(n,t,cfg): c.append([n,t,cfg])
a("lit_rhs_of_decl", "CONSTANT K\n"+V+"Alias == 3\n", inv+"ALIAS Alias\nCONSTANT K <- Alias")
a("lit_self_sub", V+"Alias == 3\n", inv+"ALIAS Alias\nCONSTANT Alias <- Alias")
a("pc_lit_sub_rhs", "CONSTANT K\nVARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nPC == TRUE\n", "INIT Init\nNEXT Next\nPOSTCONDITION PC\nCONSTANT K <- PC")
a("alias_str_letin", V+'Alias == LET s == "a" IN s\n', inv+"ALIAS Alias")
json.dump(c,open('c7.json','w'))
