import json
N="VARIABLE x\nInit == x = 0\nNext == x' = (x + 1) % 3\nInv == x < 5\n"
inv="INIT Init\nNEXT Next\nINVARIANT Inv\n"
c=[]
def a(n,t,cfg): c.append([n,t,cfg])
for n,v in [("mixed",'{1, "a"}'),("mixed3",'{<<1>>, 2}'),("num","3")]:
    a("nt_"+n, N+"Alias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias = "+v)
a("nt_mixed_used", N.replace("x < 5","x < 5 /\\ Alias # {}")+"Alias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias = {1, \"a\"}")
a("nt_assign_sub", N+"Q == [y |-> x]\nAlias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias = {1, \"a\"}\nCONSTANT Alias <- Q")
json.dump(c,open('c6.json','w'))
