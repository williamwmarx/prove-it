import json
V="VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n"
W="VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 5\n"
inv="INIT Init\nNEXT Next\nINVARIANT Inv\n"
c=[]
def a(n,t,cfg): c.append([n,t,cfg])
for n,v in [("mixed",'{1, "a"}'),("mvset","{a, b}"),("nested","{{1}, {2,3}}"),("neg","-3"),("big","2147483648"),("tup","<<1, 2>>"),("rec","[a |-> 1]"),("bool","TRUE"),("mixed2","{a, 1}")]:
    a("asg_ok_"+n, W+"Alias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias = "+v)
    a("asg_bad_"+n, V+"Alias == [z |-> x]\n", inv+"ALIAS Alias\nCONSTANT Alias = "+v)
a("asg_unused_ok", W+"Foo == 1\n", inv+"ALIAS Alias\nCONSTANT Alias = 3")
a("hex_max", V+"Alias == \\h7FFFFFFF\n", inv+"ALIAS Alias")
a("hex_big", V+"Alias == \\h80000000\n", inv+"ALIAS Alias")
a("pc_big", "VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nPC == 2147483648\n", "INIT Init\nNEXT Next\nPOSTCONDITION PC")
a("big_unused_alias_rec", V+"B == 2147483648\nAlias == [z |-> x]\n", inv+"ALIAS Alias")
a("alias_ok_lit_noviol", W+"Alias == 3\n", inv+"ALIAS Alias")
json.dump(c,open('c4.json','w'))
