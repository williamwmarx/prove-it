---- MODULE M ----
EXTENDS Naturals, TLC
---- MODULE Inner ----
CONSTANT Alias
Use == Alias
====
I == INSTANCE Inner WITH Alias <- 3
VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < I!Use - 1
Alias == [z |-> x]

====
