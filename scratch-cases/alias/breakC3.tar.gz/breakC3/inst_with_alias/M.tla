---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < 2
Alias == 3
I == INSTANCE N WITH c <- Alias
Inv2 == I!K = 3

====
