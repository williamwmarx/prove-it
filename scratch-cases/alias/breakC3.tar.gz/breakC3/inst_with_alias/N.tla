---- MODULE N ----
CONSTANT c
K == c
====
