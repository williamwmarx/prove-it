import os, sys
V="VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n"
INV="INIT Init\nNEXT Next\nINVARIANT Inv\n"
cases={}
def a(n, body, cfg, ext="Naturals, TLC", N=None):
    cases[n]=("---- MODULE M ----\nEXTENDS "+ext+"\n"+body+"\n====\n", cfg, N)
def mod(b): return "---- MODULE N ----\n"+b+"====\n"
a("ext_declc_sub", V+"Alias == 3\n", INV+"ALIAS Alias\nCONSTANT C <- Alias\n", ext="Naturals, TLC, N", N=mod("CONSTANT C\nK == C\n"))
a("ext_declc_sub_used", V+"Alias == 3\nInv2 == C = 3\n", INV+"INVARIANT Inv2\nALIAS Alias\nCONSTANT C <- Alias\n", ext="Naturals, TLC, N", N=mod("CONSTANT C\n"))
a("local_alias", V+"LOCAL Alias == 3\n", INV+"ALIAS Alias\n")
a("local_xsub", V+"X == 0\nLOCAL Alias == 3\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n")
a("rec_alias", V+"RECURSIVE Alias\nAlias == 3\n", INV+"ALIAS Alias\n")
a("rec_xsub", V+"X == 0\nRECURSIVE Alias\nAlias == \"s\"\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n")
a("modsub_lhs_lit", V+"Alias == 3\nQ == [y |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias <- [M] Q\n")
a("modsub_lhs_lit_both", V+"Alias == \"a\"\nQ == \"b\"\n", INV+"ALIAS Alias\nCONSTANT Alias <- [M] Q\n")
a("uinst_n_alias_xsub", V+"INSTANCE N\nX == 0\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n", N=mod("Alias == 3\n"))
a("uinst_param_n_alias_xsub", V+"INSTANCE N WITH c <- 1\nX == 0\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n", N=mod("CONSTANT c\nAlias == 3\n"))
a("mv_named_alias", "CONSTANT C\n"+V+"Alias == [y |-> x]\n", INV+"ALIAS Alias\nCONSTANT C = {Alias}\n")
a("mv_named_alias_lit", "CONSTANT C\n"+V+"Alias == 3\n", INV+"ALIAS Alias\nCONSTANT C = Alias\n")
a("inst_param_named_alias", V+"I == INSTANCE N WITH Alias <- 1\nAlias == [z |-> x]\nInv3 == I!K = 1\n", INV+"INVARIANT Inv3\nALIAS Alias\n", N=mod("CONSTANT Alias\nK == Alias\n"))
a("decl_and_def_sub", "CONSTANT C\n"+V+"Y == 0\nAlias == 3\n", INV+"ALIAS Alias\nCONSTANT C <- Alias\nCONSTANT Y <- Alias\n")
a("ext_inst_param_xsub", V+"I == INSTANCE N WITH c <- 1\nAlias == 3\n", INV+"ALIAS Alias\nCONSTANT c = 1\nCONSTANT Y <- Alias\n", ext="Naturals, TLC, N", N=mod("CONSTANT c\nY == 0\n"))
for n,(t,c,N) in cases.items():
    if len(sys.argv)>1 and n not in sys.argv[1:]: continue
    os.makedirs(n, exist_ok=True)
    open(n+"/M.tla","w").write(t); open(n+"/M.cfg","w").write(c)
    if N: open(n+"/N.tla","w").write(N)
print(" ".join(cases))
