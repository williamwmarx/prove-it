---- MODULE M ----
EXTENDS Naturals, TLC, N
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 3
X == 0

====
