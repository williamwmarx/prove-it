---- MODULE N ----
K == 1
====
