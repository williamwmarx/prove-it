---- MODULE N ----
CONSTANT C
K == C
====
