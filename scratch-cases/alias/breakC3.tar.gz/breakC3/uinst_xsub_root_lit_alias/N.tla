---- MODULE N ----
K == 4
====
