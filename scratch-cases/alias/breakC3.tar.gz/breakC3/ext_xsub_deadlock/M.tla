---- MODULE M ----
EXTENDS Naturals, TLC, N
VARIABLE x
Init == x = 0
Next == x < 2 /\ x' = x + 1
X == 0

====
