import os, sys
cases={}
def a(n, body, cfg, ext="Naturals, TLC, FiniteSets, Sequences", N=None):
    cases[n]=("---- MODULE M ----\nEXTENDS "+ext+"\n"+body+"\n====\n", cfg, N)
def mod(b): return "---- MODULE N ----\n"+b+"====\n"
DH="""Big == 5
Small == 3
Goal == 4
Name == "jug"
VARIABLES big, small
TypeOK == big \\in 0..Big /\\ small \\in 0..Small
Init == big = 0 /\\ small = 0
FillS == small' = Small /\\ big' = big
FillB == big' = Big /\\ small' = small
EmptyS == small' = 0 /\\ big' = big
EmptyB == big' = 0 /\\ small' = small
StoB == IF big + small =< Big THEN big' = big + small /\\ small' = 0 ELSE big' = Big /\\ small' = small - (Big - big)
BtoS == IF big + small =< Small THEN big' = 0 /\\ small' = big + small ELSE big' = big - (Small - small) /\\ small' = Small
Next == FillS \\/ FillB \\/ EmptyS \\/ EmptyB \\/ StoB \\/ BtoS
NotSolved == big # Goal
"""
a("dh_plain", DH, "INIT Init\nNEXT Next\nINVARIANT TypeOK\n")
a("dh_viol", DH, "INIT Init\nNEXT Next\nINVARIANT TypeOK\nINVARIANT NotSolved\n")
a("dh_sub", DH+"Five == 5\n", "INIT Init\nNEXT Next\nINVARIANT TypeOK\nINVARIANT NotSolved\nCONSTANT Big <- Five\n")
a("dh_asg", DH, "INIT Init\nNEXT Next\nINVARIANT TypeOK\nINVARIANT NotSolved\nCONSTANT Goal = 2\n")
MX="""N == 3
Procs == 1..N
Idle == "idle"
Wait == "wait"
Crit == "crit"
VARIABLES pc, turn
Init == pc = [p \\in Procs |-> Idle] /\\ turn = 1
Try(p) == pc[p] = Idle /\\ pc' = [pc EXCEPT ![p] = Wait] /\\ UNCHANGED turn
Enter(p) == pc[p] = Wait /\\ turn = p /\\ pc' = [pc EXCEPT ![p] = Crit] /\\ UNCHANGED turn
Exit(p) == pc[p] = Crit /\\ pc' = [pc EXCEPT ![p] = Idle] /\\ turn' = (turn % N) + 1
Pass(p) == pc[p] # Crit /\\ turn = p /\\ turn' = (turn % N) + 1 /\\ UNCHANGED pc
Next == \\E p \\in Procs : Try(p) \\/ Enter(p) \\/ Exit(p) \\/ Pass(p)
Spec == Init /\\ [][Next]_<<pc, turn>> /\\ WF_<<pc, turn>>(Next)
Mutex == \\A p, q \\in Procs : p # q => ~(pc[p] = Crit /\\ pc[q] = Crit)
Live == \\A p \\in Procs : pc[p] = Wait ~> pc[p] = Crit
Limit == 2
Cons == turn =< N
"""
a("mx_plain", MX, "SPECIFICATION Spec\nINVARIANT Mutex\nCONSTRAINT Cons\n")
a("mx_live", MX, "SPECIFICATION Spec\nINVARIANT Mutex\nPROPERTY Live\n")
a("mx_ext", MX.replace("N == 3\n","").replace("Idle == \"idle\"\n",""), "SPECIFICATION Spec\nINVARIANT Mutex\n", ext="Naturals, TLC, FiniteSets, Sequences, N", N=mod("N == 3\nIdle == \"idle\"\n"))
a("mx_inst", MX.replace("N == 3\n","I == INSTANCE N\nN == I!K\n"), "SPECIFICATION Spec\nINVARIANT Mutex\n", N=mod("K == 3\n"))
a("mx_uinst", MX.replace("N == 3\n","INSTANCE N\n"), "SPECIFICATION Spec\nINVARIANT Mutex\n", N=mod("N == 3\n"))
a("mx_view", MX, "SPECIFICATION Spec\nINVARIANT Mutex\nVIEW V\n".replace("V\n","V\n")) if False else None
a("mx_sym", MX+"P == Permutations({1,2,3})\n", "SPECIFICATION Spec\nINVARIANT Mutex\n")
a("mx_tlcget", MX+"Bound == TLCGet(\"level\") < 6\n", "SPECIFICATION Spec\nINVARIANT Mutex\nCONSTRAINT Bound\n")
for n,v in cases.items():
    if v is None: continue
    t,c,N=v
    if len(sys.argv)>1 and n not in sys.argv[1:]: continue
    os.makedirs(n, exist_ok=True)
    open(n+"/M.tla","w").write(t); open(n+"/M.cfg","w").write(c)
    if N: open(n+"/N.tla","w").write(N)
print(" ".join(k for k,v in cases.items() if v))
