import os, sys
V="VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n"
INV="INIT Init\nNEXT Next\nINVARIANT Inv\n"
cases={}
def a(n, body, cfg, ext="Naturals, TLC", N=None, N2=None):
    cases[n]=("---- MODULE M ----\nEXTENDS "+ext+"\n"+body+"\n====\n", cfg, N, N2)
def mod(b, name="N"): return "---- MODULE "+name+" ----\n"+b+"====\n"
a("asg_modsub_m", V+"Alias == [z |-> x]\nQ == [q |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias = 3\nCONSTANT Alias <- [M] Q\n")
a("uinst_asg_lit", V+"INSTANCE N\n", INV+"ALIAS Alias\nCONSTANT Alias = 5\n", N=mod("Alias == 3\n"))
a("uinst_asg_rec", V+"INSTANCE N\n", INV+"ALIAS Alias\nCONSTANT Alias = 5\n", N=mod("Alias == [a |-> 1]\n"))
a("uinst_asg_str", V+"INSTANCE N\n", INV+"ALIAS Alias\nCONSTANT Alias = \"q\"\n", N=mod("Alias == \"a\"\n"))
a("uinst_alias_sub_q", V+"INSTANCE N\nQ == [y |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias <- Q\n", N=mod("Alias == 3\n"))
a("uinst_q_lit_alias_sub", V+"INSTANCE N\nAlias == [z |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias <- Q\n", N=mod("Q == 3\n"))
a("ext_n_uinst_n2_xsub", V+"X == 0\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n", ext="Naturals, TLC, N", N=mod("INSTANCE N2\n"), N2=mod("Alias == 3\n","N2"))
a("ext_n_uinst_n2_alias", V, INV+"ALIAS Alias\n", ext="Naturals, TLC, N", N=mod("INSTANCE N2\n"), N2=mod("Alias == 3\n","N2"))
a("uinst_xsub_two_targets", V+"INSTANCE N\nX == 0\nY == 1\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\nCONSTANT Y <- Alias\n", N=mod("Alias == 3\n"))
a("uinst_xsub_other", V+"INSTANCE N\nX == 0\n", INV+"ALIAS Alias\nCONSTANT X <- K\n", N=mod("Alias == 3\nK == 4\n"))
a("uinst_xsub_root_lit_alias", V+"INSTANCE N\nX == 0\nAlias == 3\n", INV+"ALIAS Alias\nCONSTANT X <- K\n", N=mod("K == 4\n"))
for n,(t,c,N,N2) in cases.items():
    if len(sys.argv)>1 and n not in sys.argv[1:]: continue
    os.makedirs(n, exist_ok=True)
    open(n+"/M.tla","w").write(t); open(n+"/M.cfg","w").write(c)
    if N: open(n+"/N.tla","w").write(N)
    if N2: open(n+"/N2.tla","w").write(N2)
print(" ".join(cases))
