---- MODULE N ----
Alias == [a |-> 1]
====
