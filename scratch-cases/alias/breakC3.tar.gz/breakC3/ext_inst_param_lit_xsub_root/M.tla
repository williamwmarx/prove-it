---- MODULE M ----
EXTENDS Naturals, TLC, N
VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < 2
I == INSTANCE N WITH c <- 1
X == 0

====
