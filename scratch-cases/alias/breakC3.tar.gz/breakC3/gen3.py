import os, sys
cases={}
def a(n, body, cfg, ext="Naturals, TLC", N=None, N2=None):
    cases[n]=("---- MODULE M ----\nEXTENDS "+ext+"\n"+body+"\n====\n", cfg, N, N2)
def mod(b, name="N"): return "---- MODULE "+name+" ----\n"+b+"====\n"
C="VARIABLE x\nInit == x = 0\nNext == x' = (x + 1) % 3\n"
CC="INIT Init\nNEXT Next\n"
a("uinst_pc_ok_num", C+"INSTANCE N\nX == 0\n", CC+"POSTCONDITION PC\nCONSTANT X <- PC\n", N=mod("PC == 3\n"))
a("uinst_pc_ok_str", C+"INSTANCE N\nX == 0\n", CC+"POSTCONDITION PC\nCONSTANT X <- PC\n", N=mod("PC == \"s\"\n"))
a("uinst_pc_ok_nosub", C+"INSTANCE N\n", CC+"POSTCONDITION PC\n", N=mod("PC == 3\n"))
a("uinst_pc_ok_modsub", C+"INSTANCE N\nX == 0\n", CC+"POSTCONDITION PC\nCONSTANT X <- [M] PC\n", N=mod("PC == 3\n"))
a("uinst_pc_ok_nmodsub", C+"INSTANCE N\n", CC+"POSTCONDITION PC\nCONSTANT X <- [N] PC\n", N=mod("X == 0\nPC == 3\n"))
a("uinst_alias_nmodsub", "VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\nINSTANCE N\n", "INIT Init\nNEXT Next\nINVARIANT Inv\nALIAS Alias\nCONSTANT X <- [N] Alias\n", N=mod("X == 0\nAlias == 3\n"))
a("uinst_both_pc_alias", "VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\nINSTANCE N\nX == 0\nY == 0\n", "INIT Init\nNEXT Next\nINVARIANT Inv\nALIAS Alias\nPOSTCONDITION PC\nCONSTANT X <- Alias\nCONSTANT Y <- PC\n", N=mod("Alias == 3\nPC == \"t\"\n"))
for n,(t,c,N,N2) in cases.items():
    if len(sys.argv)>1 and n not in sys.argv[1:]: continue
    os.makedirs(n, exist_ok=True)
    open(n+"/M.tla","w").write(t); open(n+"/M.cfg","w").write(c)
    if N: open(n+"/N.tla","w").write(N)
    if N2: open(n+"/N2.tla","w").write(N2)
print(" ".join(cases))
