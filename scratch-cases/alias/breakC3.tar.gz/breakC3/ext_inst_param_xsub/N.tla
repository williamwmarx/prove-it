---- MODULE N ----
CONSTANT c
Y == 0
====
