import os, sys
V="VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n"
INV="INIT Init\nNEXT Next\nINVARIANT Inv\n"
C="VARIABLE x\nInit == x = 0\nNext == x' = (x + 1) % 3\n"
CC="INIT Init\nNEXT Next\n"
cases={}
def a(n, body, cfg, ext="Naturals, TLC", N=None, N2=None):
    cases[n]=("---- MODULE M ----\nEXTENDS "+ext+"\n"+body+"\n====\n", cfg, N, N2)
def mod(b, name="N"): return "---- MODULE "+name+" ----\n"+b+"====\n"
a("inst_with_alias", V+"Alias == 3\nI == INSTANCE N WITH c <- Alias\nInv2 == I!K = 3\n", INV+"INVARIANT Inv2\nALIAS Alias\n", N=mod("CONSTANT c\nK == c\n"))
a("uinst_implicit_xsub", V+"c == 1\nINSTANCE N\nX == 0\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n", N=mod("CONSTANT c\nAlias == 3\n"))
a("ext_declc_from_ext", "CONSTANT C\n"+V, INV+"ALIAS Alias\nCONSTANT C <- Alias\n", ext="Naturals, TLC, N", N=mod("Alias == 3\n"))
a("ext_pc_xsub_ok", C+"X == 0\n", CC+"POSTCONDITION PC\nCONSTANT X <- PC\n", ext="Naturals, TLC, N", N=mod("PC == 3\n"))
a("ext_pc_xsub_str_ok", C+"X == 0\n", CC+"POSTCONDITION PC\nCONSTANT X <- PC\n", ext="Naturals, TLC, N", N=mod("PC == \"z\"\n"))
a("ext_nmodsub_both_in_n", V, INV+"ALIAS Alias\nCONSTANT X <- [N] Alias\n", ext="Naturals, TLC, N", N=mod("X == 0\nAlias == 3\n"))
a("ext_chain_xsub", V+"X == 0\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n", ext="Naturals, TLC, N", N=mod("EXTENDS N2\n"), N2=mod("Alias == 3\n","N2"))
a("ext_xsub_str", V+"X == \"q\"\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n", ext="Naturals, TLC, N", N=mod("Alias == \"w\"\n"))
a("ext_xsub_deadlock", "VARIABLE x\nInit == x = 0\nNext == x < 2 /\\ x' = x + 1\nX == 0\n", CC+"ALIAS Alias\nCONSTANT X <- Alias\n", ext="Naturals, TLC, N", N=mod("Alias == 3\n"))
a("ext_inst_param_lit_alias", V+"I == INSTANCE N WITH c <- 1\n", INV+"ALIAS Alias\nCONSTANT c = 1\n", ext="Naturals, TLC, N", N=mod("CONSTANT c\nAlias == 3\n"))
a("ext_inst_param_lit_xsub_root", V+"I == INSTANCE N WITH c <- 1\nX == 0\n", INV+"ALIAS Alias\nCONSTANT c = 1\nCONSTANT X <- Alias\n", ext="Naturals, TLC, N", N=mod("CONSTANT c\nAlias == 3\n"))
a("root_lit_used_in_n_inst", V+"Alias == 3\nI == INSTANCE N\nX == 0\n", INV+"ALIAS Alias\nCONSTANT X <- I_K\n".replace("I_K","Alias"), N=mod("K == 1\n"))
a("lit_sub_target_local_in_n", V+"INSTANCE N\nAlias == 3\nX == 0\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n", N=mod("LOCAL Alias == 5\nK == Alias\n"))
for n,(t,c,N,N2) in cases.items():
    if len(sys.argv)>1 and n not in sys.argv[1:]: continue
    os.makedirs(n, exist_ok=True)
    open(n+"/M.tla","w").write(t); open(n+"/M.cfg","w").write(c)
    if N: open(n+"/N.tla","w").write(N)
    if N2: open(n+"/N2.tla","w").write(N2)
print(" ".join(cases))
