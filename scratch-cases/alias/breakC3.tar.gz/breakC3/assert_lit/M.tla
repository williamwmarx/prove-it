---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
Next == x' = x + 1 /\ Assert(x < 2, "boom")
Alias == "s"

====
