import os, sys
cases={}
def a(n, body, cfg, ext="Naturals, TLC", N=None):
    cases[n]=("---- MODULE M ----\nEXTENDS "+ext+"\n"+body+"\n====\n", cfg, N)
def mod(b): return "---- MODULE N ----\n"+b+"====\n"
L="VARIABLE x\nInit == x = 0\nNext == x' = (x + 1) % 3\nSpec == Init /\\ [][Next]_x\nProp == <>(x = 5)\n"
a("live_lit", L+"Alias == 3\n", "SPECIFICATION Spec\nPROPERTY Prop\nALIAS Alias\n")
a("live_uinst_xsub", L+"INSTANCE N\nX == 0\n", "SPECIFICATION Spec\nPROPERTY Prop\nALIAS Alias\nCONSTANT X <- Alias\n", N=mod("Alias == 3\n"))
a("assert_lit", "VARIABLE x\nInit == x = 0\nNext == x' = x + 1 /\\ Assert(x < 2, \"boom\")\nAlias == \"s\"\n", "INIT Init\nNEXT Next\nALIAS Alias\n")
a("assert_uinst_xsub", "VARIABLE x\nInit == x = 0\nNext == x' = x + 1 /\\ Assert(x < 2, \"boom\")\nINSTANCE N\nX == 0\n", "INIT Init\nNEXT Next\nALIAS Alias\nCONSTANT X <- Alias\n", N=mod("Alias == \"s\"\n"))
a("action_prop_lit", "VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nSpec == Init /\\ [][Next]_x\nAP == [][x' < 2]_x\nAlias == 7\n", "SPECIFICATION Spec\nPROPERTY AP\nALIAS Alias\n")
a("action_constraint_uinst", "VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\nINSTANCE N\nX == 0\n", "INIT Init\nNEXT Next\nINVARIANT Inv\nALIAS Alias\nCONSTANT X <- Alias\nCONSTRAINT Inv2\n", N=mod("Alias == 7\nInv2 == TRUE\n"))
for n,(t,c,N) in cases.items():
    if len(sys.argv)>1 and n not in sys.argv[1:]: continue
    os.makedirs(n, exist_ok=True)
    open(n+"/M.tla","w").write(t); open(n+"/M.cfg","w").write(c)
    if N: open(n+"/N.tla","w").write(N)
print(" ".join(cases))
