#!/bin/bash
# tlcok.sh case : TLC output summary
S=/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad
D=$(mktemp -d); cp $S/breakC3/$1/*.tla $D/; cp $S/breakC3/$1/M.cfg $D/; cd $D
/home/user/ext/tlcbuild/tlc -workers 1 -nowarning -noGenerateSpecTE -config M.cfg M.tla 2>&1 | grep -v '^Finished\|^Starting\|^Running\|^TLC2\|pid\|^Parsing\|^Semantic\|^Computing\|JAVA_TOOL\|Progress\|^The depth\|^The average\|^Model checking\|^Checking\|^Implied\|^Linting\|Semantic processing\|^SANY\|^Implied-temporal' | head -${2:-12}
cd /; rm -rf $D
