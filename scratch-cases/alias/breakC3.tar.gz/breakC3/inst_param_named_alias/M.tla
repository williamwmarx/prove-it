---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < 2
I == INSTANCE N WITH Alias <- 1
Alias == [z |-> x]
Inv3 == I!K = 1

====
