---- MODULE N ----
K == 3
====
