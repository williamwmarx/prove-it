---- MODULE M ----
EXTENDS Naturals, TLC, FiniteSets, Sequences
Big == 5
Small == 3
Goal == 4
Name == "jug"
VARIABLES big, small
TypeOK == big \in 0..Big /\ small \in 0..Small
Init == big = 0 /\ small = 0
FillS == small' = Small /\ big' = big
FillB == big' = Big /\ small' = small
EmptyS == small' = 0 /\ big' = big
EmptyB == big' = 0 /\ small' = small
StoB == IF big + small =< Big THEN big' = big + small /\ small' = 0 ELSE big' = Big /\ small' = small - (Big - big)
BtoS == IF big + small =< Small THEN big' = 0 /\ small' = big + small ELSE big' = big - (Small - small) /\ small' = Small
Next == FillS \/ FillB \/ EmptyS \/ EmptyB \/ StoB \/ BtoS
NotSolved == big # Goal
Five == 5

====
