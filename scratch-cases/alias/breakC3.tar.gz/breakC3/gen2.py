import os, sys
V="VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n"
INV="INIT Init\nNEXT Next\nINVARIANT Inv\n"
cases={}
def a(n, body, cfg, ext="Naturals, TLC", N=None):
    cases[n]=("---- MODULE M ----\nEXTENDS "+ext+"\n"+body+"\n====\n", cfg, N)
def mod(b): return "---- MODULE N ----\n"+b+"====\n"
a("uinst_xsub_str", V+"INSTANCE N\nX == 0\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n", N=mod("Alias == \"a\"\n"))
a("luinst_xsub", V+"LOCAL INSTANCE N\nX == 0\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n", N=mod("Alias == 3\n"))
a("uinst_modsub", V+"INSTANCE N\nX == 0\n", INV+"ALIAS Alias\nCONSTANT X <- [M] Alias\n", N=mod("Alias == 3\n"))
a("uinst_pc_xsub", V+"INSTANCE N\nX == 0\n", INV+"POSTCONDITION PC\nCONSTANT X <- PC\n", N=mod("PC == 3\n"))
a("uinst_pc_xsub_noviol", "VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nINSTANCE N\nX == 0\n", "INIT Init\nNEXT Next\nPOSTCONDITION PC\nCONSTANT X <- PC\n", N=mod("PC == \"s\"\n"))
a("uinst_deadlock_xsub", "VARIABLE x\nInit == x = 0\nNext == x < 2 /\\ x' = x + 1\nINSTANCE N\nX == 0\n", "INIT Init\nNEXT Next\nALIAS Alias\nCONSTANT X <- Alias\n", N=mod("Alias == 3\n"))
a("inner_uinst_xsub", V+"---- MODULE Inner ----\nAlias == 3\n====\nINSTANCE Inner\nX == 0\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n")
a("inner_uinst_alias", V+"---- MODULE Inner ----\nAlias == 3\n====\nINSTANCE Inner\n", INV+"ALIAS Alias\n")
a("uinst_declc_sub", "CONSTANT C\n"+V+"INSTANCE N\n", INV+"ALIAS Alias\nCONSTANT C <- Alias\n", N=mod("Alias == 3\n"))
a("uinst_xsub_x_in_n", V+"INSTANCE N\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n", N=mod("X == 0\nAlias == 3\n"))
a("ext_uinst_chain", V+"INSTANCE N\nX == 0\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n", N=mod("EXTENDS N2\n"))
a("uinst_nested", V+"INSTANCE N\nX == 0\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n", N=mod("INSTANCE N2\n"))
a("uinst_xsub_used", V+"INSTANCE N\nX == 0\nInv2 == x # X\n", INV+"INVARIANT Inv2\nALIAS Alias\nCONSTANT X <- Alias\n", N=mod("Alias == 2\n"))
for n,(t,c,N) in cases.items():
    if len(sys.argv)>1 and n not in sys.argv[1:]: continue
    os.makedirs(n, exist_ok=True)
    open(n+"/M.tla","w").write(t); open(n+"/M.cfg","w").write(c)
    if N: open(n+"/N.tla","w").write(N)
    if n in ("ext_uinst_chain","uinst_nested"): open(n+"/N2.tla","w").write("---- MODULE N2 ----\nAlias == 3\n====\n")
print(" ".join(cases))
