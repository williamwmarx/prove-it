---- MODULE M ----
EXTENDS Naturals, TLC, FiniteSets, Sequences
N == 3
Procs == 1..N
Idle == "idle"
Wait == "wait"
Crit == "crit"
VARIABLES pc, turn
Init == pc = [p \in Procs |-> Idle] /\ turn = 1
Try(p) == pc[p] = Idle /\ pc' = [pc EXCEPT ![p] = Wait] /\ UNCHANGED turn
Enter(p) == pc[p] = Wait /\ turn = p /\ pc' = [pc EXCEPT ![p] = Crit] /\ UNCHANGED turn
Exit(p) == pc[p] = Crit /\ pc' = [pc EXCEPT ![p] = Idle] /\ turn' = (turn % N) + 1
Pass(p) == pc[p] # Crit /\ turn = p /\ turn' = (turn % N) + 1 /\ UNCHANGED pc
Next == \E p \in Procs : Try(p) \/ Enter(p) \/ Exit(p) \/ Pass(p)
Spec == Init /\ [][Next]_<<pc, turn>> /\ WF_<<pc, turn>>(Next)
Mutex == \A p, q \in Procs : p # q => ~(pc[p] = Crit /\ pc[q] = Crit)
Live == \A p \in Procs : pc[p] = Wait ~> pc[p] = Crit
Limit == 2
Cons == turn =< N

====
