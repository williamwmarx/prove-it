#!/bin/bash
# run.sh case... : case3N for each
S=/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad
cd $S/breakC3
for c in "$@"; do echo "== $c"; bash $S/breakC2/case3N.sh $S/breakC3/$c/M.tla $S/breakC3/$c/M.cfg; done
