---- MODULE N ----
CONSTANT c
Alias == 3
====
