#!/bin/bash
# runx.sh case args... : TLC vs main vs branch with extra args (filtered diff)
S=/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad/breakC3
c=$1; shift
F='^Finished\|^Starting\|^Running\|^TLC2\|pid\|tmp\|^Parsing\|^Semantic\|^Linting\|^Computing\|JAVA_TOOL\|Progress\|STARTMSG 2185\|STARTMSG 2186\|STARTMSG 2187\|STARTMSG 2262\|STARTMSG 2220\|STARTMSG 2189\|STARTMSG 2190\|STARTMSG 2201\|STARTMSG 2202\|STARTMSG 2268'
D=$(mktemp -d); cp $S/$c/*.tla $S/$c/M.cfg $D; cd $D
/home/user/ext/tlcbuild/tlc "$@" -config M.cfg M.tla > t.raw 2>&1; te=$?
for b in wt-main6 wt-const; do timeout 60 /home/user/ext/$b/packages/prove-it/native/target/release/prove-it "$@" -config M.cfg M.tla > n.raw 2>&1; ne=$?
if grep -q "not native" n.raw; then echo "  $b: DECLINE $(grep 'not native' n.raw|cut -c22-120)";
elif diff -q <(grep -v "$F" t.raw) <(grep -v "$F" n.raw) >/dev/null && [ $te = $ne ]; then echo "  $b: SAME";
else echo "  $b: DIFF($te/$ne)"; diff <(grep -v "$F" t.raw) <(grep -v "$F" n.raw) | head -${DL:-6} | sed 's/^/     /'; fi; done
cd /; rm -rf $D
