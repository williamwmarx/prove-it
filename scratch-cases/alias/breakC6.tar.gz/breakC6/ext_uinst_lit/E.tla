---- MODULE E ----
EXTENDS Naturals
VARIABLE x
INSTANCE N WITH c <- 1
====
