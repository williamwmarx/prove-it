exec(open("lib.py").read())
AL=INV+"ALIAS Alias\n"
EX="Naturals, TLC, E"
LV="VARIABLE x\nInit == x = 0\nNext == x' = (x + 1) % 3\nSpec == Init /\\ [][Next]_x\nLive == <>(x = 5)\n"
LC="SPECIFICATION Spec\nPROPERTY Live\nALIAS Alias\n"
a("sub_lit_ext_inst", "Init == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\nI == INSTANCE E WITH c <- 1\nAlias == [z |-> x]\n", AL+"CONSTANT c = 2\nCONSTANT Alias <- L\n", ext=EX, E="VARIABLE x\nCONSTANT c\nL == 3\n")
a("inner_uinst_asg", "VARIABLE x\n---- MODULE Inner ----\nVARIABLE x\nAlias == [z |-> x]\n====\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\nINSTANCE Inner\n", AL+"CONSTANT Alias = 3\n")
a("inner_uinst_lit", "VARIABLE x\n---- MODULE Inner ----\nAlias == 3\n====\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\nINSTANCE Inner\n", AL)
a("live_sub_lit", LV+"Alias == [z |-> x]\nL == 3\n", LC+"CONSTANT Alias <- L\n")
a("live_asg", LV+"Alias == [z |-> x]\n", LC+"CONSTANT Alias = \"k\"\n")
a("live_lit_target_decl", LV+"CONSTANT C\nAlias == 3\n", LC+"CONSTANT C <- Alias\n")
a("act_prop_sub", "VARIABLE x\nInit == x = 0\nNext == x' = (x + 1) % 3\nSpec == Init /\\ [][Next]_x\nAP == [][x' > x]_x\nAlias == [z |-> x]\nL == \"s\"\n", "SPECIFICATION Spec\nPROPERTY AP\nALIAS Alias\nCONSTANT Alias <- L\n")
a("rterr_asg", "VARIABLE x\nInit == x = 0\nNext == x' = x + 1 /\\ (x = 2 => 1 \\div 0 = 0)\nAlias == [z |-> x]\n", "INIT Init\nNEXT Next\nALIAS Alias\nCONSTANT Alias = <<1>>\n")
write()
