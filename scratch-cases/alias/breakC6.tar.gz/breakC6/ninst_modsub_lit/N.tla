---- MODULE N ----
CONSTANT c
D == c
====
