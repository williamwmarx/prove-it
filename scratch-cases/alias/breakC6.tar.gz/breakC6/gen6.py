exec(open("lib.py").read())
AL=INV+"ALIAS Alias\n"
V2="Init == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n"
EX="Naturals, TLC, E"
a("ext_modsub_alias", V2+"Q == [y |-> x]\n", AL+"CONSTANT Alias <- [E] Q\n", ext=EX, E="VARIABLE x\nAlias == [z |-> x]\n")
a("ext_modsub_alias_constq", V2+"Q == [y |-> 1]\n", AL+"CONSTANT Alias <- [E] Q\n", ext=EX, E="VARIABLE x\nAlias == [z |-> x]\n")
a("ext_modsub_alias_lit", V2+"Q == [y |-> x]\n", AL+"CONSTANT Alias <- [E] Q\n", ext=EX, E="VARIABLE x\nAlias == 3\n")
a("ext_modsub_alias_litq", V2+"Q == 4\n", AL+"CONSTANT Alias <- [E] Q\n", ext=EX, E="VARIABLE x\nAlias == [z |-> x]\n")
a("ext_modsub_alias_constalias", V2+"Q == [y |-> x]\n", AL+"CONSTANT Alias <- [E] Q\n", ext=EX, E="VARIABLE x\nAlias == [z |-> 1]\n")
a("uinst_modsub_alias", V+"INSTANCE N\nQ == [y |-> x]\n", AL+"CONSTANT Alias <- [N] Q\n", N="VARIABLE x\nAlias == [z |-> x]\n")
a("uinst_modsub_alias_lit", V+"INSTANCE N\nQ == [y |-> x]\n", AL+"CONSTANT Alias <- [N] Q\n", N="Alias == 3\n")
write()
