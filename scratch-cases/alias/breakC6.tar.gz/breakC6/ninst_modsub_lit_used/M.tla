---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < 2
I == INSTANCE N WITH c <- 1
Alias == 3
Inv2 == I!D = 3

====
