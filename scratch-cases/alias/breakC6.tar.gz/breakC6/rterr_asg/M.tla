---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
Next == x' = x + 1 /\ (x = 2 => 1 \div 0 = 0)
Alias == [z |-> x]

====
