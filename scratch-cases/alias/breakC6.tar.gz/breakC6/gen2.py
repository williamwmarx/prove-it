exec(open("lib.py").read())
AL=INV+"ALIAS Alias\n"
Nv="VARIABLE x\nR == [y |-> x]\n"
a("inst_named_alias", V+"Alias == INSTANCE N\n", AL, N="K == 1\n")
a("inst_named_alias_asg", V+"Alias == INSTANCE N\n", AL+"CONSTANT Alias = 3\n", N="K == 1\n")
a("inst_named_alias_p", V+"Alias(p) == INSTANCE N WITH c <- p\n", AL+"CONSTANT Alias = 3\n", N="CONSTANT c\nK == c\n")
a("inst_named_alias_sub", V+"Alias == INSTANCE N\nQ == [y |-> x]\n", AL+"CONSTANT Alias <- Q\n", N="K == 1\n")
a("dup_sub_last", V+"D == 0\nQ == 1\nAlias == 3\n", AL+"CONSTANT D <- Alias\nCONSTANT D <- Q\n")
a("dup_sub_first", V+"D == 0\nQ == 1\nAlias == 3\n", AL+"CONSTANT D <- Q\nCONSTANT D <- Alias\n")
a("dup_alias_sub", V+"Q == [y |-> x]\nR == [z |-> x]\nAlias == 3\n", AL+"CONSTANT Alias <- Q\nCONSTANT Alias <- R\n")
a("dup_alias_sub_lit", V+"Q == [y |-> x]\nR == 4\nAlias == [w |-> x]\n", AL+"CONSTANT Alias <- Q\nCONSTANT Alias <- R\n")
a("dup_alias_asg_then_sub_lit", V+"R == 4\nAlias == [w |-> x]\n", AL+"CONSTANTS\n Alias = 3\n Alias <- R\n")
a("block_mixed", V+"D == 0\nAlias == 3\n", AL+"CONSTANTS\n D <- Alias\n")
write()
