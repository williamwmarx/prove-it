---- MODULE E ----
VARIABLE x
CONSTANT c
Alias == [z |-> x]
====
