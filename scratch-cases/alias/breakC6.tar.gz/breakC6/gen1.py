exec(open("lib.py").read())
AL=INV+"ALIAS Alias\n"
# named instance with params, mod-scoped override in N targeting root literal
a("ninst_modsub_lit", V+"I == INSTANCE N WITH c <- 1\nAlias == 3\nInv2 == I!D = 1\n", AL+"CONSTANT D <- [N] Alias\n", N="CONSTANT c\nD == c\n")
a("ninst_modsub_lit_used", V+"I == INSTANCE N WITH c <- 1\nAlias == 3\nInv2 == I!D = 3\n", AL+"INVARIANT Inv2\nCONSTANT D <- [N] Alias\n", N="CONSTANT c\nD == c\n")
# unnamed instance w/ params, mod-scoped
a("uinst_modsub_lit", V+"INSTANCE N WITH c <- 1\nAlias == 3\n", AL+"CONSTANT D <- [N] Alias\n", N="CONSTANT c\nD == c\n")
# extended N without params, mod-scoped
a("ext_modsub_lit", V+"Alias == 3\n", AL+"CONSTANT D <- [N] Alias\n", ext="Naturals, TLC, N", N="D == 1\n")
# named instance no params; root-level override of I!? not possible; mod-scoped
a("ninst_np_modsub_lit", V+"I == INSTANCE N\nAlias == 3\n", AL+"CONSTANT D <- [N] Alias\n", N="D == 1\n")
# mod-scoped override for a nonzero-arity? D(a) <-[N] Alias arity mismatch skip
# substitution target string literal named instance
a("ninst_modsub_str", V+"I == INSTANCE N WITH c <- 1\nAlias == \"s\"\n", AL+"CONSTANT D <- [N] Alias\n", N="CONSTANT c\nD == c\n")
write()
