exec(open("lib.py").read())
AL=INV+"ALIAS Alias\n"
V2="Init == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n"
a("uinst_implicit_var_lit", V+"INSTANCE N\n", AL, N="VARIABLE x\nAlias == 3\n")
a("uinst_var_param_lit", V+"INSTANCE N WITH v <- x\n", AL, N="VARIABLE v\nAlias == 3\n")
a("uinst_var_param_str", V+"INSTANCE N WITH v <- x\n", AL, N="VARIABLE v\nAlias == \"s\"\n")
a("ext_uinst_lit", V2, AL, ext="Naturals, TLC, E", E="EXTENDS Naturals\nVARIABLE x\nINSTANCE N WITH c <- 1\n", N="CONSTANT c\nAlias == 3\n")
a("ext_uinst_var_lit", V2, AL, ext="Naturals, TLC, E", E="EXTENDS Naturals\nVARIABLE x\nINSTANCE N\n", N="VARIABLE x\nAlias == 3\n")
a("uinst_implicit_var_pc", "VARIABLE x\nInit == x = 0\nNext == x' = (x + 1) % 3\nINSTANCE N\n", CC+"POSTCONDITION PC\n", N="VARIABLE x\nPC == 3\n")
a("sub_trace", V+"Alias == [w |-> x]\n", AL+"CONSTANT Alias <- Trace\n", ext="Naturals, TLC, TLCExt")
a("sub_cex", V+"Alias == [w |-> x]\n", AL+"CONSTANT Alias <- CounterExample\n", ext="Naturals, TLC, TLCExt")
a("lit_target_of_trace_lhs", V+"Alias == 3\n", AL+"CONSTANT Trace <- Alias\n", ext="Naturals, TLC, TLCExt")
write()
