---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x \in {0, 1}
Next == x < 3 /\ x' = x + 1
Inv == x < 2
Alias == "q"

====
