---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x \in {0, 1}
Next == x' = (x + 1) % 4
Inv == x < 2
Alias == 3

====
