---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
CONSTANT S
Init == x \in S
Next == x' \in S
Inv == x # a
Alias == 3
Sym == Permutations(S)

====
