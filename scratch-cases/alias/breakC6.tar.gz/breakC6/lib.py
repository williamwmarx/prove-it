import os, sys
V="VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n"
INV="INIT Init\nNEXT Next\nINVARIANT Inv\n"
C="VARIABLE x\nInit == x = 0\nNext == x' = (x + 1) % 3\n"
CC="INIT Init\nNEXT Next\n"
cases={}
def a(n, body, cfg, ext="Naturals, TLC", **mods):
    cases[n]=("---- MODULE M ----\n"+("EXTENDS "+ext+"\n" if ext else "")+body+"\n====\n", cfg, mods)
def mod(b, name="N"): return "---- MODULE "+name+" ----\n"+b+"====\n"
def write():
    for n,(t,c,mods) in cases.items():
        os.makedirs(n, exist_ok=True)
        open(n+"/M.tla","w").write(t); open(n+"/M.cfg","w").write(c)
        for k,v in mods.items(): open(n+"/"+k+".tla","w").write(mod(v,k))
    print(" ".join(cases))
