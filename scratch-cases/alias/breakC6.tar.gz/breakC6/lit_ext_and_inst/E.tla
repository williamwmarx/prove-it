---- MODULE E ----
VARIABLE x
CONSTANT c
Alias == 3
====
