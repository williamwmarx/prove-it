#!/bin/bash
# flags.sh case flags... : TLC vs main vs branch with flags (filtered)
S=/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad/breakC6
D=$(mktemp -d); cp $S/$1/*.tla $S/$1/M.cfg $D/; cd $D; shift
F='^Finished\|^Starting\|^Running\|^TLC2\|pid\|tmp\|^Parsing\|^Semantic\|^Linting\|^Computing\|JAVA_TOOL\|Progress\|STARTMSG 2185\|STARTMSG 2186\|STARTMSG 2187\|STARTMSG 2262\|STARTMSG 2220\|STARTMSG 2189\|STARTMSG 2190\|STARTMSG 2201\|STARTMSG 2202\|STARTMSG 2268'
/home/user/ext/tlcbuild/tlc -nowarning -noGenerateSpecTE "$@" -config M.cfg M.tla 2>&1 | grep -v "$F" > t.out; echo "tlc exit ${PIPESTATUS[0]}"
for b in wt-main6 wt-const; do timeout 60 /home/user/ext/$b/packages/prove-it/native/target/release/prove-it -nowarning -noGenerateSpecTE "$@" -config M.cfg M.tla 2>&1 | grep -v "$F" > n.out; e=${PIPESTATUS[0]}
if grep -q "not native" n.out; then echo "$b: DECLINE $(grep 'not native' n.out|cut -c1-120)"; elif diff -q t.out n.out >/dev/null; then echo "$b: SAME($e)"; else echo "$b: DIFF($e)"; diff t.out n.out | head -${N:-6}; fi; done
cd /; rm -rf $D
