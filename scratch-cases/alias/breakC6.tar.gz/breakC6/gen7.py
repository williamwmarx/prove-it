exec(open("lib.py").read())
AL=INV+"ALIAS Alias\n"
a("te_asg", V+"Alias == [y |-> x]\n", AL+"CONSTANT Alias = 3\n")
a("te_asg_mv", V+"Alias == [y |-> x]\n", AL+"CONSTANT Alias = {a, b}\n")
a("te_lit", V+"Alias == 3\n", AL)
write()
