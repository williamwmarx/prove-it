#!/bin/bash
# mb.sh case [flags]: show main vs branch output diff (w1)
S=/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad/breakC6
D=$(mktemp -d); cp $S/$1/*.tla $S/$1/M.cfg $D/; cd $D; shift
/home/user/ext/wt-main6/packages/prove-it/native/target/release/prove-it -workers 1 -nowarning -noGenerateSpecTE "$@" -config M.cfg M.tla > m.out 2>&1
/home/user/ext/wt-const/packages/prove-it/native/target/release/prove-it -workers 1 -nowarning -noGenerateSpecTE "$@" -config M.cfg M.tla > b.out 2>&1
diff <(grep -v '^Finished\|^Starting\|pid\|tmp' m.out) <(grep -v '^Finished\|^Starting\|pid\|tmp' b.out) && echo MB-IDENTICAL
grep -v '^Finished\|^Starting\|pid\|tmp' b.out | head -${N:-12}
cd /; rm -rf $D
