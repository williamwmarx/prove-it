exec(open("lib.py").read())
AL=INV+"ALIAS Alias\n"
CY="VARIABLE x\nInit == x \\in {0, 1}\nNext == x' = (x + 1) % 4\nInv == x < 2\n"
a("cyc_lit", CY+"Alias == 3\n", AL)
a("cyc_asg", CY+"Alias == [y |-> x]\n", AL+"CONSTANT Alias = 3\n")
a("cyc_sub", CY+"Alias == 3\nQ == [y |-> x]\n", AL+"CONSTANT Alias <- Q\n")
write()
