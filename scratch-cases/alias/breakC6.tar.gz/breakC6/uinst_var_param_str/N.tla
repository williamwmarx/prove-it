---- MODULE N ----
VARIABLE v
Alias == "s"
====
