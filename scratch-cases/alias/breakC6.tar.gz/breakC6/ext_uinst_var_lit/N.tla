---- MODULE N ----
VARIABLE x
Alias == 3
====
