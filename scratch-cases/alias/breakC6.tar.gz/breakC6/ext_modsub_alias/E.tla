---- MODULE E ----
VARIABLE x
Alias == [z |-> x]
====
