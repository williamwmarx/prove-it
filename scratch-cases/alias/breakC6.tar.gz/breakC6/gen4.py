exec(open("lib.py").read())
AL=INV+"ALIAS Alias\n"
a("lit_base", V+"Alias == 3\n", AL)
a("lit_base_str", "VARIABLE x\nInit == x \\in {0, 1}\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\nAlias == \"q\"\n", AL)
write()
