---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
---- MODULE Inner ----
Alias == 3
====
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < 2
INSTANCE Inner

====
