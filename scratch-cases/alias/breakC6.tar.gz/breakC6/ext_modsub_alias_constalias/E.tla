---- MODULE E ----
VARIABLE x
Alias == [z |-> 1]
====
