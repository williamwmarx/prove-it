---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
AP == [][x' > x]_x
Alias == [z |-> x]
L == "s"

====
