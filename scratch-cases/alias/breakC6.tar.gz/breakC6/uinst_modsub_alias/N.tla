---- MODULE N ----
VARIABLE x
Alias == [z |-> x]
====
