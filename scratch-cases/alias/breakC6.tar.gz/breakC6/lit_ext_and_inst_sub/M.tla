---- MODULE M ----
EXTENDS Naturals, TLC, E
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < 2
I == INSTANCE E WITH c <- 1
Q == [y |-> x]

====
