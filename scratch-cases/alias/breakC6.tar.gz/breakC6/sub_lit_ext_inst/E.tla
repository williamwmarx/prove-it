---- MODULE E ----
VARIABLE x
CONSTANT c
L == 3
====
