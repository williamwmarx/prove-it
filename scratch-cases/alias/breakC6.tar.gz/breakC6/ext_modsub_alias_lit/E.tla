---- MODULE E ----
VARIABLE x
Alias == 3
====
