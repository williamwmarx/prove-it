---- MODULE M ----
EXTENDS Naturals, TLC, E
Init == x = 0
Next == x' = (x + 1) % 3
Q == FALSE

====
