---- MODULE E ----
VARIABLE x
PC == "a" = "a"
====
