---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLES x, y
Init == x = 0 /\ y = "a"
Next == x < 3 /\ x' = x + 1 /\ y' = y
Inv == x < 2
Alias == "s"

====
