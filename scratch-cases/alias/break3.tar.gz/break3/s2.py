exec(open('/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad/break3/mk.py').read())
B='Init == x = 0\nNext == x\' = x + 1\nInv == x < 2'
mk('sim_g1', G+'Alias == [x |-> IF x = 1 THEN g ELSE x]\n'+B)
mk('sim_g0_len2', G+'Alias == [x |-> IF x = 0 THEN g ELSE x]\nInit == x = 0\nNext == x\' = x + 1\nInv == x < 1')
mk('sim_g0_dead', G+'Alias == [x |-> IF x = 0 THEN g ELSE x]\nInit == x = 0\nNext == x < 2 /\\ x\' = x + 1\nInv == TRUE', cfg='INIT Init\nNEXT Next\nALIAS Alias\n')
mk('cont_g0', G+'Alias == [x |-> IF x = 0 THEN g ELSE x]\nInit == x = 0\nNext == x < 4 /\\ x\' = x + 1\nInv == x # 2 /\\ x # 3', cfg='INIT Init\nNEXT Next\nINVARIANT Inv\nALIAS Alias\nCHECK_DEADLOCK FALSE\n')
mk('cont_g1', G+'Alias == [x |-> IF x = 1 THEN g ELSE x]\nInit == x = 0\nNext == x < 4 /\\ x\' = x + 1\nInv == x # 2 /\\ x # 3', cfg='INIT Init\nNEXT Next\nINVARIANT Inv\nALIAS Alias\nCHECK_DEADLOCK FALSE\n')
