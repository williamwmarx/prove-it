---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
PC == "a"
Init == x = 0
Next == x < 2 /\ x' = x + 1
====
