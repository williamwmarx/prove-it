---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Init == x = {1, TRUE}
Next == x' = x \cup {2}
====
