---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
g[i \in 1..2] == IF i = 2 THEN 1 \div 0 ELSE IF i = 0 THEN g[i] ELSE i
Alias == [x |-> x, c |-> TLCSet(1, TLCGet(1) + 1), v |-> g, r |-> TLCGet(1)]
Init == x = 0 /\ TLCSet(1, 0)
Next == x' = x + 1
Inv == x < 2
====
