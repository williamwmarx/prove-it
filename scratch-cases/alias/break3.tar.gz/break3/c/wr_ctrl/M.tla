---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
R == [b |-> x, a |-> 2]
Alias == [x |-> x, r |-> R]
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
