---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
g[i \in 1..2] == IF i = 2 THEN 1 \div 0 ELSE IF i = 0 THEN g[i] ELSE i
Alias == [x |-> IF x = 0 THEN g ELSE x]
Init == x = 0
Next == x < 4 /\ x' = x + 1
Inv == x # 2 /\ x # 3
====
