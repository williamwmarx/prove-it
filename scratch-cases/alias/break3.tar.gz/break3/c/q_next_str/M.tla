---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = IF x = 2 THEN Cardinality({1, "a"} \cup {2}) ELSE x + 1
====
