---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Alias == [x |-> IF x = 0 THEN [n \in Nat |-> n] ELSE x]
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
