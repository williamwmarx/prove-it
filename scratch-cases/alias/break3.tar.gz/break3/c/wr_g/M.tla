---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
R == [b |-> x, a |-> 2]
g[i \in 1..2] == IF i = 2 THEN (IF R = [a |-> 2, b |-> x] THEN 1 \div 0 ELSE 0) ELSE IF i = 0 THEN g[i] ELSE i
Alias == [x |-> x, r |-> R, v |-> g]
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
