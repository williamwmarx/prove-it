---- MODULE M ----
EXTENDS Naturals
---- MODULE N ----
CONSTANT Alias
Val == Alias
====
VARIABLE x
I == INSTANCE N WITH Alias <- 7
Alias == [x |-> x, v |-> I!Val]
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
