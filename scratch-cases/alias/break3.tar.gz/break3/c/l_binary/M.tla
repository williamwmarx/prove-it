---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Alias == \b101
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
