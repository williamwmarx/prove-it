---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Init == x = 0 /\ PrintT({"a", TRUE} \cup {"a"})
Next == x' = x + 1
Inv == x < 2
====
