---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2 \/ Cardinality({1, TRUE} \cup 1..2) = 0
====
