---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Three == 3
Alias == Three
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
