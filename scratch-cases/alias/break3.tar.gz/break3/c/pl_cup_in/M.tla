---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2 \/ 3 \in ({1, TRUE} \cup {3})
====
