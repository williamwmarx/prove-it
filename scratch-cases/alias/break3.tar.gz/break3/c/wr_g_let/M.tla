---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
g[i \in 1..2] == IF i = 2 THEN (IF TRUE THEN 1 \div 0 ELSE 0) ELSE IF i = 0 THEN g[i] ELSE i
Alias == LET R == [b |-> x, a |-> 2] IN [x |-> x, r |-> R, v |-> g, c |-> R]
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
