---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Alias == (5)
Init == x = 0
Next == x < 2 /\ x' = x + 1
====
