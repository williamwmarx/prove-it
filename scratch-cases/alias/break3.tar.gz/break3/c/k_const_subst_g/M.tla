---- MODULE M ----
EXTENDS Naturals
CONSTANT Alias
VARIABLE x
g[i \in 1..2] == IF i = 2 THEN 1 \div 0 ELSE IF i = 0 THEN g[i] ELSE i
Other == [x |-> x, w |-> g]
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
