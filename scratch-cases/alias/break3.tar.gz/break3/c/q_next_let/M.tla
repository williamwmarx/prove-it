---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == LET s == {1, TRUE} IN x' = IF x = 2 THEN Cardinality(s \cup {x}) ELSE x + 1
====
