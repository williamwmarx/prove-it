---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
R == [b |-> x, a |-> 2]
Alias == [x |-> x, r |-> R, c |-> R = [a |-> 2, b |-> x]]
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
