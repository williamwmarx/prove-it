---- MODULE M ----
EXTENDS Naturals
CONSTANT Alias
VARIABLE x
Other == [x |-> x, w |-> 1]
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
