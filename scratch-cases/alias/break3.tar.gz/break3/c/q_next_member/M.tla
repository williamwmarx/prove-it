---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = IF x = 2 /\ 7 \in ({1, TRUE} \cup {2}) THEN 0 ELSE x + 1
====
