---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = IF x = 2 THEN Cardinality({2} \cup {1, TRUE}) ELSE x + 1
====
