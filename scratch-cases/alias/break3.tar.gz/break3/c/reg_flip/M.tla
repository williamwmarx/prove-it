---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
g[i \in 1..2] == IF i = 2 THEN 1 \div 0 ELSE IF i = 0 THEN g[i] ELSE i
Alias == [x |-> x, v |-> LET old == TLCGet(1) IN IF TLCSet(1, x) /\ old = x THEN g[1] ELSE g = g]
Init == x = 0 /\ TLCSet(1, -1)
Next == x' = x + 1
Inv == x < 2
====
