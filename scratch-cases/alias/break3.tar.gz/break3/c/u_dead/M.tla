---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
g[i \in 1..2] == IF i = 2 THEN 1 \div 0 ELSE IF i = 0 THEN g[i] ELSE i
Alias == IF x >= 0 THEN UNION {{g}, {1}} ELSE {}
Init == x = 0
Next == x < 2 /\ x' = x + 1
====
