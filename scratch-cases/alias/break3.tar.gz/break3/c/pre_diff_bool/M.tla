---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Alias == IF x >= 0 THEN {TRUE, 1} \ {TRUE} ELSE {}
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
