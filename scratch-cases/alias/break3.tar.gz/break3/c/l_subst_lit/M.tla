---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Alias == [x |-> x]
Other == 3
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
