---- MODULE M ----
EXTENDS Naturals
CONSTANT C
VARIABLE x
Alias == [x |-> x, c |-> C]
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
