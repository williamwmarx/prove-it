---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Alias == LET h[i \in 1..2] == IF i = 2 THEN 1 \div 0 ELSE IF i = 0 THEN h[i] ELSE i IN IF x >= 0 THEN UNION {{h}, {1}} ELSE {}
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
