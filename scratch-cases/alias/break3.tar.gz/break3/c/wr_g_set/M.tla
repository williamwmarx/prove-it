---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
R == {x + 2, x}
g[i \in 1..2] == IF i = 2 THEN (IF R = {x, x + 2} THEN 1 \div 0 ELSE 0) ELSE IF i = 0 THEN g[i] ELSE i
Alias == IF x >= 0 THEN <<R>> ELSE <<g>>
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
