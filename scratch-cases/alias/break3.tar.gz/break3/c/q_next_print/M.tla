---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = IF x = 2 THEN PrintT({1, TRUE} \cup {2}) ELSE x + 1
====
