---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
PC == l :: TRUE
Init == x = 0
Next == x < 2 /\ x' = x + 1
====
