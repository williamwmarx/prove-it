---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Init == x = {1}
Next == x' = ({TRUE} \cup x) \cup {3}
Inv == TRUE
====
