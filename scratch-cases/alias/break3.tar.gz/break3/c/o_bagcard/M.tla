---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, Bags, TLCExt
VARIABLE x
g[i \in 1..2] == IF i = 2 THEN 1 \div 0 ELSE IF i = 0 THEN g[i] ELSE i
Alias == [x |-> x, v |-> BagCardinality(g)]
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
