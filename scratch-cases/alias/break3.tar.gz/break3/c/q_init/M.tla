---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Init == x = Cardinality({1, TRUE} \cup {2})
Next == x' = x
====
