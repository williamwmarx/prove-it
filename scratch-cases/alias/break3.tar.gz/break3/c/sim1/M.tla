---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Alias == [x |-> x, y |-> x + 10]
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
