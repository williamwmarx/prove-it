---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, Randomization

VARIABLE x
g[i \in 1..2] == IF i = 2 THEN 1 \div 0 ELSE IF i = 0 THEN g[i] ELSE i
Alias == [x |-> x, r |-> RandomSubset(3, 1..100), v |-> g[1]]
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
