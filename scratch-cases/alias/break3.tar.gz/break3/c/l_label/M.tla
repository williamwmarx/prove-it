---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Alias == lbl :: 3
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
