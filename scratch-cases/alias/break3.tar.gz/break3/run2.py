import sys, os, subprocess
SP='/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad'
exec(open(SP+'/break3/mk.py').read())
exec(open(sys.argv[1]).read())
only=sys.argv[2:]
for name in NAMES:
    if only and name not in only: continue
    d=SP+'/break3/c/'+name
    t=subprocess.run(['/home/user/ext/tlcbuild/tlc','-workers','1','-nowarning','-config','M.cfg','M.tla'],cwd=d,capture_output=True,text=True).stdout.splitlines()
    key=[l for l in t if ('rror' in l or 'violated' in l or 'states generated' in l or 'Deadlock' in l or 'exception' in l) and 'TLC2' not in l][:2]
    r=subprocess.run(['bash',SP+'/break1/case3T.sh',d+'/M.tla',d+'/M.cfg'],capture_output=True,text=True)
    print(f'== {name}  TLC: {key}\n{r.stdout}',flush=True)
