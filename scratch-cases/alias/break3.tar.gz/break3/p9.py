NAMES=[]
B='Init == x = 0\nNext == x\' = x + 1\nInv == x < 2'
H2='EXTENDS Naturals, TLC, Sequences, FiniteSets'
def m(nm, defs):
    NAMES.append(nm); mk(nm, defs+'\n'+B, head=H2)
GR='g[i \\in 1..2] == IF i = 2 THEN (IF R = [a |-> 2, b |-> x] THEN 1 \\div 0 ELSE 0) ELSE IF i = 0 THEN g[i] ELSE i\n'
m('wr_ctrl', 'R == [b |-> x, a |-> 2]\nAlias == [x |-> x, r |-> R]')
m('wr_ctrl_cmp', 'R == [b |-> x, a |-> 2]\nAlias == [x |-> x, r |-> R, c |-> R = [a |-> 2, b |-> x]]')
m('wr_g', 'R == [b |-> x, a |-> 2]\n'+GR+'Alias == [x |-> x, r |-> R, v |-> g]')
m('wr_g_after', 'R == [b |-> x, a |-> 2]\n'+GR+'Alias == [x |-> x, v |-> g, r |-> R]')
m('wr_g_set', 'R == {x + 2, x}\n'+GR.replace('R = [a |-> 2, b |-> x]','R = {x, x + 2}')+'Alias == IF x >= 0 THEN <<R>> ELSE <<g>>')
m('wr_g_let', GR.replace('R = [a |-> 2, b |-> x]','TRUE')+'Alias == LET R == [b |-> x, a |-> 2] IN [x |-> x, r |-> R, v |-> g, c |-> R]')
