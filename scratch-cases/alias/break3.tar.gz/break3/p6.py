NAMES=[]
B='Init == x = 0\nNext == x\' = x + 1\nInv == x < 2'
H2='EXTENDS Naturals, TLC'
def r(n, defs, cfg='INIT Init\nNEXT Next\nINVARIANT Inv\nALIAS Alias\n', body=B):
    NAMES.append(n); mk(n, defs+'\n'+body, head=H2, cfg=cfg)
r('l_paren', 'Alias == (3)')
r('l_paren_str', 'Alias == ((("a")))')
r('l_label', 'Alias == lbl :: 3')
r('l_binary', 'Alias == \\b101')
r('l_hex', 'Alias == \\h1F')
r('l_octal', 'Alias == \\o17')
r('l_zero', 'Alias == 0')
r('l_lead0', 'Alias == 007')
r('l_strempty', 'Alias == ""')
r('l_paren_dead', 'Alias == (5)', cfg='INIT Init\nNEXT Next\nALIAS Alias\n', body='Init == x = 0\nNext == x < 2 /\\ x\' = x + 1')
r('l_pc_paren', 'PC == (3)', cfg='INIT Init\nNEXT Next\nINVARIANT Inv\nPOSTCONDITION PC\n')
r('l_pc_label', 'PC == l :: TRUE', cfg='INIT Init\nNEXT Next\nPOSTCONDITION PC\nCHECK_DEADLOCK FALSE\n', body='Init == x = 0\nNext == x < 2 /\\ x\' = x + 1')
r('l_pc_lit', 'PC == "a"', cfg='INIT Init\nNEXT Next\nPOSTCONDITION PC\nCHECK_DEADLOCK FALSE\n', body='Init == x = 0\nNext == x < 2 /\\ x\' = x + 1')
r('l_subst_lit', 'Alias == [x |-> x]\nOther == 3', cfg='INIT Init\nNEXT Next\nINVARIANT Inv\nALIAS Alias\nCONSTANT Alias <- Other\n')
r('l_subst_paren', 'Alias == [x |-> x]\nOther == (3)', cfg='INIT Init\nNEXT Next\nINVARIANT Inv\nALIAS Alias\nCONSTANT Alias <- Other\n')
r('l_lit_via_def', 'Three == 3\nAlias == Three')
