NAMES=[]
B='Init == x = 0\nNext == x\' = x + 1\nInv == x < 2'
H2='EXTENDS Naturals, TLC, Sequences, FiniteSets'
def both(n, e, defs=G, head=H2):
    NAMES.append('n_'+n); mk('n_'+n, defs+'Alias == IF x >= 0 THEN '+e+' ELSE {}\n'+B, head=head)
    NAMES.append('r_'+n); mk('r_'+n, defs+'Alias == [x |-> x, v |-> '+e+']\n'+B, head=head)
both('card_ss', 'Cardinality({{g}, {1}})')
both('card_s', 'Cardinality({g, 1})')
both('exists_s', '\\E e \\in {g, 1} : TRUE')
both('choose_s', 'CHOOSE e \\in {g, 1} : TRUE')
both('diff_1_s', '{1} \\ {g, 1}')
both('diff_s_1', '{g, 1} \\ {2}')
both('cap_s', '{g, 1} \\cap {1}')
both('filter_s', '{e \\in {g, 1} : TRUE}')
both('map_s', '{0 : e \\in {g, 1}}')
both('fcn_dom', '[k \\in {g, 1} |-> 0]')
both('subseteq', '{g, 1} \\subseteq {1}')
both('eq_sets', '{g, 1} = {1}')
both('in_s', '1 \\in {g, 1}')
both('notin_s', '2 \\notin {g, 1}')
both('union_s', 'UNION {{g, 1}}')
both('union_2', 'UNION {{g}, {1}, {2}}')
both('isfin', 'IsFiniteSet({g, 1})')
