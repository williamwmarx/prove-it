#!/bin/bash
# mb.sh dir [args]: diff main vs branch native outputs (w1)
d=$1; shift; T=$(mktemp -d); cp $d/M.tla $d/M.cfg $T; cd $T
timeout 60 /home/user/ext/wt-base/packages/prove-it/native/target/release/prove-it -workers 1 "$@" -nowarning -fp 0 -lncheck final -noGenerateSpecTE -config M.cfg M.tla 2>&1 | grep -v '^Finished\|^Starting\|pid\|^TLC2\|tmp' > m
timeout 60 /home/user/ext/wt-rec/packages/prove-it/native/target/release/prove-it -workers 1 "$@" -nowarning -fp 0 -lncheck final -noGenerateSpecTE -config M.cfg M.tla 2>&1 | grep -v '^Finished\|^Starting\|pid\|^TLC2\|tmp' > b
if diff -q m b >/dev/null; then echo "$(basename $d): main==branch"; else echo "$(basename $d): main!=branch"; diff m b | head -${N:-6}; fi
cd /; rm -rf $T
