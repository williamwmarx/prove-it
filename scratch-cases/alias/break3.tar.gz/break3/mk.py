import sys,os
S='/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad/break3/c/'
def mk(name, body, cfg='INIT Init\nNEXT Next\nINVARIANT Inv\nALIAS Alias\n', head='EXTENDS Naturals, TLC, Sequences, FiniteSets', var='x'):
    os.makedirs(S+name, exist_ok=True)
    open(S+name+'/M.tla','w').write('---- MODULE M ----\n'+head+'\nVARIABLE '+var+'\n'+body+'\n====\n')
    open(S+name+'/M.cfg','w').write(cfg)
G = 'g[i \\in 1..2] == IF i = 2 THEN 1 \\div 0 ELSE IF i = 0 THEN g[i] ELSE i\n'
