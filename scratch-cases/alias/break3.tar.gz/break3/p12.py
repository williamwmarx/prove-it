NAMES=[]
B='Init == x = 0\nNext == x\' = x + 1\nInv == x < 2'
H2='EXTENDS Naturals, TLC, Sequences, FiniteSets'
def a(nm, alias, defs=G):
    NAMES.append(nm); mk(nm, defs+'Alias == '+alias+'\n'+B, head=H2)
a('pre_union_bool', 'IF x >= 0 THEN UNION {{TRUE}, {1}} ELSE {}', defs='')
a('pre_diff_bool', 'IF x >= 0 THEN {TRUE, 1} \\ {TRUE} ELSE {}', defs='')
a('fin_nonrec', 'IF x >= 0 THEN IsFiniteSet(g) ELSE {}')
a('fin_cond_rec', 'IF IsFiniteSet(g) THEN [x |-> x] ELSE [x |-> x + 1]')
a('fin_except', '[x |-> x, v |-> IsFiniteSet([g EXCEPT ![1] = 3])]')
a('x_nonrec', 'IF x >= 0 THEN {g} \\X {1} ELSE {}')
a('x_card', '[x |-> x, v |-> Cardinality({g} \\X {1, 2})]')
a('recset_card', '[x |-> x, v |-> Cardinality([a : {g}, b : {1, 2}])]')
a('fcnset_print', '[x |-> x, v |-> [{1, 2} -> {g, <<1>>}]]')
a('union_cond_rec', 'IF UNION {{g}, {1}} = {} THEN [x |-> x] ELSE [x |-> x, w |-> 1]')
a('diff_cond_rec', 'IF ({g, 1} \\ {g}) \\in {{}} THEN [x |-> x] ELSE [x |-> x, w |-> 1]')
a('union_isfinite', '[x |-> x, v |-> IsFiniteSet(UNION {{g}, {1}})]')
a('union_subset', '[x |-> x, v |-> SUBSET UNION {{g}, {1}}]')
a('diff_domain', '[x |-> x, v |-> DOMAIN [k \\in {1} |-> {g, 1} \\ {g}]]')
