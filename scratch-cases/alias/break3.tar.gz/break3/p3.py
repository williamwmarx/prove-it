NAMES=[]
B='Init == x = 0\nNext == x\' = x + 1\nInv == x < 2'
H2='EXTENDS Naturals, TLC, Sequences, FiniteSets'
def r(n, e, defs=G, head=H2):
    NAMES.append(n); mk(n, defs+'Alias == '+e+'\n'+B, head=head)
r('u_nonrec_union', 'IF x >= 0 THEN UNION {{g}, {1}} ELSE {}')
r('u_nonrec_union_gg', 'IF x >= 0 THEN UNION {{g}, {g}} ELSE {}')
r('u_rec_union_gg', '[x |-> x, v |-> UNION {{g}, {g}}]')
r('u_rec_union_1g', '[x |-> x, v |-> UNION {{1}, {g}}]')
r('u_rec_card_union', '[x |-> x, v |-> Cardinality(UNION {{g}, {1}})]')
r('u_rec_dom_union', '[x |-> x, v |-> 1 \\in UNION {{g}, {1}}]')
r('u_nonrec_setset', 'IF x >= 0 THEN {{g}, {1}} ELSE {}')
r('u_nonrec_g', 'IF x >= 0 THEN g ELSE {}')
r('u_nonrec_tuple', '<<x, UNION {{g}, {1}}>>')
