NAMES=[]
B='Init == x = 0\nNext == x\' = x + 1\nInv == x < 2'
H2='EXTENDS Naturals, TLC, Sequences, FiniteSets'
def n(nm, e, form='IF x >= 0 THEN {} ELSE {}'):
    NAMES.append(nm); mk(nm, G+'Alias == '+form.replace('{}', e, 1)+'\n'+B, head=H2)
n('d_n_gg', '{g, 1} \\ {g}')
n('d_r_gg', '{g, 1} \\ {g}', form='[x |-> x, v |-> {}]')
n('d_n_g2', '{g, "a"} \\ {g, 2}')
n('d_n_bool', '{g, TRUE} \\ {g}')
n('d_n_card', 'Cardinality({g, 1} \\ {g})')
n('d_n_eqempty', '({g, 1} \\ {g}) = {}')
n('d_n_ss', '{{g}, {1}} \\ {{g}}')
n('d_n_union_of_diff', 'UNION {{g, 1} \\ {g}}')

