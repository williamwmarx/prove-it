NAMES=[]
H2='EXTENDS Naturals, TLC, Sequences, FiniteSets'
def p(n, body, cfg='INIT Init\nNEXT Next\n'):
    NAMES.append(n); mk(n, body, cfg=cfg, head=H2)
p('q_next_str', 'Init == x = 0\nNext == x\' = IF x = 2 THEN Cardinality({1, "a"} \\cup {2}) ELSE x + 1')
p('q_next_rev', 'Init == x = 0\nNext == x\' = IF x = 2 THEN Cardinality({2} \\cup {1, TRUE}) ELSE x + 1')
p('q_next_empty', 'Init == x = 0\nNext == x\' = IF x = 2 THEN Cardinality({1, TRUE} \\cup {}) ELSE x + 1')
p('q_next_ivl', 'Init == x = 0\nNext == x\' = IF x = 2 THEN Cardinality({1, TRUE} \\cup 2..3) ELSE x + 1')
p('q_next_member', 'Init == x = 0\nNext == x\' = IF x = 2 /\\ 7 \\in ({1, TRUE} \\cup {2}) THEN 0 ELSE x + 1')
p('q_init', 'Init == x = Cardinality({1, TRUE} \\cup {2})\nNext == x\' = x')
p('q_next_var', 'Init == x = {1, TRUE}\nNext == x\' = x \\cup {2}')
p('q_next_uu', 'Init == x = 0\nNext == x\' = IF x = 2 THEN Cardinality({1, TRUE} \\cup {TRUE, 1}) ELSE x + 1')
p('q_next_print', 'Init == x = 0\nNext == x\' = IF x = 2 THEN PrintT({1, TRUE} \\cup {2}) ELSE x + 1')
p('q_next_let', 'Init == x = 0\nNext == LET s == {1, TRUE} IN x\' = IF x = 2 THEN Cardinality(s \\cup {x}) ELSE x + 1')
