import sys; sys.path.insert(0,'/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad/break3')
from common import mk2
C=[]
G = 'g[i \\in 1..2] == IF i = 2 THEN 1 \\div 0 ELSE IF i = 0 THEN g[i] ELSE i'
H = 'EXTENDS Naturals, TLC, Sequences, FiniteSets'
def add(n, alias, **k):
    k.setdefault('head', H); C.append((n,)+mk2(G+'\nAlias == '+alias, **k))
# register written in pass 1, read again in pass 2
add('reg_flip', "[x |-> x, v |-> LET old == TLCGet(1) IN IF TLCSet(1, x) /\\ old = x THEN g[1] ELSE g = g]", init="x = 0 /\\ TLCSet(1, -1)")
add('reg_count', "[x |-> x, c |-> TLCSet(1, TLCGet(1) + 1), r |-> TLCGet(1), v |-> IF x = 0 THEN <<g>> = <<g>> ELSE 0]", init="x = 0 /\\ TLCSet(1, 0)")
add('reg_count_lazyok', "[x |-> x, c |-> TLCSet(1, TLCGet(1) + 1), r |-> TLCGet(1), v |-> IF x = 0 THEN {g} ELSE g]", init="x = 0 /\\ TLCSet(1, 0)")
add('reg_count_lazyok2', "[x |-> x, c |-> TLCSet(1, TLCGet(1) + 1), v |-> g, r |-> TLCGet(1)]", init="x = 0 /\\ TLCSet(1, 0)")
# random draws consumed by pass 1
add('rnd_before', "[x |-> x, r |-> RandomElement(1..1000), v |-> g]")
add('rnd_after', "[x |-> x, v |-> g, r |-> RandomElement(1..1000)]")
add('rnd_subset', "[x |-> x, r |-> RandomSubset(3, 1..100), v |-> g[1]]", head=H+', Randomization')
CASES=C
