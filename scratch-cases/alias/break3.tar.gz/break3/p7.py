NAMES=[]
def raw(n, tla, cfg):
    NAMES.append(n); os.makedirs(S+n, exist_ok=True); open(S+n+'/M.tla','w').write(tla); open(S+n+'/M.cfg','w').write(cfg)
raw('k_inst_const', r'''---- MODULE M ----
EXTENDS Naturals
---- MODULE N ----
CONSTANT Alias
Val == Alias
====
VARIABLE x
I == INSTANCE N WITH Alias <- 7
Alias == [x |-> x, v |-> I!Val]
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
''', 'INIT Init\nNEXT Next\nINVARIANT Inv\nALIAS Alias\n')
raw('k_inst_const_cfg', r'''---- MODULE M ----
EXTENDS Naturals
---- MODULE N ----
CONSTANT Alias
Val == Alias
====
VARIABLE x
I == INSTANCE N WITH Alias <- 7
Alias == [x |-> x, v |-> I!Val]
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
''', 'INIT Init\nNEXT Next\nINVARIANT Inv\nALIAS Alias\nCONSTANT Alias = 5\n')
raw('k_const_param', r'''---- MODULE M ----
EXTENDS Naturals
CONSTANT C
VARIABLE x
Alias == [x |-> x, c |-> C]
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
''', 'INIT Init\nNEXT Next\nINVARIANT Inv\nALIAS Alias\nCONSTANT C = Alias\n')
raw('k_const_mv_alias', r'''---- MODULE M ----
EXTENDS Naturals
CONSTANT Alias
VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
''', 'INIT Init\nNEXT Next\nINVARIANT Inv\nALIAS Alias\nCONSTANT Alias = Alias\n')
raw('k_const_subst_op', r'''---- MODULE M ----
EXTENDS Naturals
CONSTANT Alias
VARIABLE x
Other == [x |-> x, w |-> 1]
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
''', 'INIT Init\nNEXT Next\nINVARIANT Inv\nALIAS Alias\nCONSTANT Alias <- Other\n')
raw('k_const_subst_g', r'''---- MODULE M ----
EXTENDS Naturals
CONSTANT Alias
VARIABLE x
g[i \in 1..2] == IF i = 2 THEN 1 \div 0 ELSE IF i = 0 THEN g[i] ELSE i
Other == [x |-> x, w |-> g]
Init == x = 0
Next == x' = x + 1
Inv == x < 2
====
''', 'INIT Init\nNEXT Next\nINVARIANT Inv\nALIAS Alias\nCONSTANT Alias <- Other\n')
