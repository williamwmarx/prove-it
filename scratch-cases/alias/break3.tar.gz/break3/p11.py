NAMES=[]
H2='EXTENDS Naturals, TLC, Sequences, FiniteSets'
def m(nm, body, cfg):
    NAMES.append(nm); mk(nm, body, head=H2, cfg=cfg)
m('u_dead', G+'Alias == IF x >= 0 THEN UNION {{g}, {1}} ELSE {}\nInit == x = 0\nNext == x < 2 /\\ x\' = x + 1', 'INIT Init\nNEXT Next\nALIAS Alias\n')
m('u_live', G+'Alias == IF x >= 0 THEN UNION {{g}, {1}} ELSE {}\nInit == x = 0\nNext == x\' = (x + 1) % 3\nProp == <>(x = 5)', 'INIT Init\nNEXT Next\nPROPERTY Prop\nALIAS Alias\n')
m('u_err_next', G+'Alias == IF x >= 0 THEN UNION {{g}, {1}} ELSE {}\nInit == x = 0\nNext == x\' = IF x = 2 THEN 1 \\div 0 ELSE x + 1', 'INIT Init\nNEXT Next\nALIAS Alias\n')
m('u_aprop', G+'Alias == IF x >= 0 THEN UNION {{g}, {1}} ELSE {}\nInit == x = 0\nNext == x\' = x + 1\nAP == [][x\' < 3]_x', 'INIT Init\nNEXT Next\nPROPERTY AP\nALIAS Alias\n')
m('u_let_rec', 'Alias == LET h[i \\in 1..2] == IF i = 2 THEN 1 \\div 0 ELSE IF i = 0 THEN h[i] ELSE i IN IF x >= 0 THEN UNION {{h}, {1}} ELSE {}\nInit == x = 0\nNext == x\' = x + 1\nInv == x < 2', 'INIT Init\nNEXT Next\nINVARIANT Inv\nALIAS Alias\n')
m('u_state_rec', 'g[i \\in 0..x] == IF i = x THEN 1 \\div 0 ELSE IF i < 0 THEN g[i] ELSE i\nAlias == IF x >= 0 THEN UNION {{g}, {"a"}} ELSE {}\nInit == x = 0\nNext == x\' = x + 1\nInv == x < 2', 'INIT Init\nNEXT Next\nINVARIANT Inv\nALIAS Alias\n')
m('u_str', G+'Alias == IF x >= 0 THEN UNION {{g}, {"s"}} ELSE {}\nInit == x = 0\nNext == x\' = x + 1\nInv == x < 2', 'INIT Init\nNEXT Next\nINVARIANT Inv\nALIAS Alias\n')
