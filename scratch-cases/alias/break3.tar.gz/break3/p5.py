NAMES=[]
H2='EXTENDS Naturals, TLC, Sequences, FiniteSets'
def p(n, body, cfg='INIT Init\nNEXT Next\nINVARIANT Inv\n'):
    NAMES.append(n); mk(n, body, cfg=cfg, head=H2)
p('pl_cup_uu_inv', 'Init == x = 0\nNext == x\' = x + 1\nInv == x < 2 \\/ Cardinality({1, TRUE} \\cup {TRUE, 1}) = 0')
p('pl_cup_ui_inv', 'Init == x = 0\nNext == x\' = x + 1\nInv == x < 2 \\/ Cardinality({1, TRUE} \\cup 1..2) = 0')
p('pl_cup_ue_inv', 'Init == x = 0\nNext == x\' = x + 1\nInv == x < 2 \\/ ({1, TRUE} \\cup {}) = {}')
p('pl_cup_us_next', 'Init == x = 0\nNext == x\' = IF x = 2 THEN Cardinality({1, TRUE} \\cup {2}) ELSE x + 1\nInv == TRUE')
p('pl_cup_uvar_next', 'Init == x = {1}\nNext == x\' = ({TRUE} \\cup x) \\cup {3}\nInv == TRUE')
p('pl_cup_print', 'Init == x = 0\nNext == x\' = x + 1\nInv == x < 2 \\/ PrintT({1, TRUE} \\cup {"a"})')
p('pl_cup_print2', 'Init == x = 0 /\\ PrintT({"a", TRUE} \\cup {"a"})\nNext == x\' = x + 1\nInv == x < 2')
p('pl_cup_in', 'Init == x = 0\nNext == x\' = x + 1\nInv == x < 2 \\/ 3 \\in ({1, TRUE} \\cup {3})')
