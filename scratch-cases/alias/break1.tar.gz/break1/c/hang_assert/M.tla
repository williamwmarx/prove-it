---- MODULE M ----
EXTENDS Naturals, TLC

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == Assert(x < 2, g2[2, 2])
g2[i \in 1..2, j \in 1..2] == IF i = 1 THEN j ELSE g2[i - 1, j] + 1
====
