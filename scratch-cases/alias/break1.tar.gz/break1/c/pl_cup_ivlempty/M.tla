---- MODULE M ----
EXTENDS Naturals, FiniteSets

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
Alias == IF x >= 0 THEN {1, TRUE} \cup 1..0 ELSE {}
====
