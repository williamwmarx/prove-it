---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
f[n \in Nat] == IF n = 0 THEN 1 ELSE n * f[n - 1]
Alias == [x |-> x, v |-> f]
====
