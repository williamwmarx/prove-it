---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
Alias == [x |-> x, v |-> LET g[i \in 0..3] == IF i = 0 THEN 0 ELSE g[i - 1] + 2 IN g]
====
