---- MODULE M ----
EXTENDS Naturals
---- MODULE Inner ----
CONSTANT Alias
R == Alias
====
I == INSTANCE Inner WITH Alias <- 5

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < I!R - 3
Alias == [x |-> x]
====
