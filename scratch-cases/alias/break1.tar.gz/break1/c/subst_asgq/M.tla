---- MODULE M ----
EXTENDS Naturals
CONSTANT Q
VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
Alias == [x |-> x]
====
