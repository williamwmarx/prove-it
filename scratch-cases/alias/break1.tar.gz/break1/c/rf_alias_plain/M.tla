---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
g[i \in 1..1] == IF i = 1 THEN 1 \div 0 ELSE g[i]
Alias == g
====
