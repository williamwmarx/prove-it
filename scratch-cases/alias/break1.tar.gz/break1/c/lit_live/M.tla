---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = 1 - x

Alias == 3
Spec == Init /\ [][Next]_x
P == <>(x = 2)
====
