---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
g[i \in 0..2] == IF i = 0 THEN g[5] ELSE i
Alias == [x |-> x, v |-> g]
====
