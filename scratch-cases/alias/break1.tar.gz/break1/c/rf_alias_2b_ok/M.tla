---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
g[i \in 1..2, j \in 1..2] == IF i = 1 THEN j ELSE g[i - 1, j] + 1
Alias == [x |-> x, v |-> g]
====
