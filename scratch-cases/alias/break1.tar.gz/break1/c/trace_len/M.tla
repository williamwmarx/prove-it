---- MODULE M ----
EXTENDS Naturals, Sequences, TLCExt

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
Alias == [x |-> x, t |-> Len(Trace)]
====
