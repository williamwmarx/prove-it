---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
Q == [x |-> x, q |-> 1]
Alias == 3
====
