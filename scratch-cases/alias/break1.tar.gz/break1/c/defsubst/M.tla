---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
Q == [x |-> x, y |-> 1]
Alias == [x |-> x]
====
