---- MODULE M ----
EXTENDS Naturals

VARIABLE x, y
Init == x = 0 /\ y = 0
Next == x' = 1 - x /\ y' = y

g[i \in 1..1] == IF i = 1 THEN 1 \div 0 ELSE g[i]
Spec == Init /\ [][Next]_<<x, y>>
P == <>(x = 5)
Alias == [x |-> x, y |-> g]
====
