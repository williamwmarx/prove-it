---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
RECURSIVE R(_)
R(n) == IF n = 0 THEN 1 \div 0 ELSE R(n - 1)
Alias == [x |-> x, v |-> [i \in 1..1 |-> R(i)]]
====
