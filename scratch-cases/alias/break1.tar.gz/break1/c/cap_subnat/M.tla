---- MODULE M ----
EXTENDS Naturals

VARIABLE x, y
Init == x = 0 /\ y = 0
Next == x' = x + 1 /\ y' = y
Inv == x < 2
Alias == [x |-> x, y |-> SUBSET {1} \cap SUBSET Nat]
====
