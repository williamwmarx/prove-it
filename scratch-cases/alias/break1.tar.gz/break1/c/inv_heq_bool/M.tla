---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2 \/ h = h
g[i \in 1..2] == IF i = 1 THEN 1 \div 0 ELSE g[i - 1]
h[i \in 1..2] == IF i = 1 THEN 1 \div 0 ELSE IF i = 2 THEN 5 ELSE h[i - 1]
====
