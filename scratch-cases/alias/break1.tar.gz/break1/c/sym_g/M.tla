---- MODULE M ----
EXTENDS Naturals, TLC
CONSTANT a, b
VARIABLE x, y
Init == x = 0 /\ y = 0
Next == x' = x + 1 /\ y' = y
Inv == x < 2
g[i \in 1..1] == IF i = 1 THEN 1 \div 0 ELSE g[i]
S == {a, b}
Sym == Permutations(S)
Alias == [x |-> x, y |-> g]
====
