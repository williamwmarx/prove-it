---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
f[i \in 1..2] == i + x
Alias == [x |-> x, f |-> f]
====
