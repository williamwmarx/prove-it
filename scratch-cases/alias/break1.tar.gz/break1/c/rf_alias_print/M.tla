---- MODULE M ----
EXTENDS Naturals, TLC

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
g[i \in 0..1] == IF i = 0 THEN Print("p", 1 \div 0) ELSE g[i - 1]
Alias == [x |-> x, v |-> g]
====
