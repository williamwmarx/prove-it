---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
q[i \in 1..3] == IF i = 1 THEN 0 ELSE q[i - 1] + q[i - 1]
Alias == [x |-> x, v |-> q[3]]
====
