---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
f[i \in 1..2] == IF i = 2 THEN 1 \div 0 ELSE i
Alias == [x |-> x, f |-> f[1]]
====
