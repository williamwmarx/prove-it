---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
g[s \in SUBSET {1, 2}] == IF s = {} THEN 0 ELSE 1 + g[s \ {CHOOSE e \in s : TRUE}]
Alias == [x |-> x, v |-> g]
====
