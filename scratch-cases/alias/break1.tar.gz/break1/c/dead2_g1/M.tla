---- MODULE M ----
EXTENDS Naturals

VARIABLE x, y
Init == x = 0 /\ y = 0
Next == x < 1 /\ x' = x + 1 /\ y' = y
Inv == TRUE
g[i \in 1..1] == IF i = 1 THEN 1 \div 0 ELSE g[i]
Alias == [x |-> x, y |-> IF x = 1 THEN g ELSE 0]
====
