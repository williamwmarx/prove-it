---- MODULE M ----
EXTENDS Naturals
---- MODULE Inner ----
CONSTANT Alias
VARIABLE z
R == [z |-> z, a |-> Alias]
====
I == INSTANCE Inner WITH Alias <- 5, z <- x

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
Alias == I!R
====
