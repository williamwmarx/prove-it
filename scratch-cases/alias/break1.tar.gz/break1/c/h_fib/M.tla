---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
f[i \in 0..18] == IF i < 2 THEN i ELSE f[i - 1] + f[i - 2]
Alias == [x |-> x, v |-> f[18]]
====
