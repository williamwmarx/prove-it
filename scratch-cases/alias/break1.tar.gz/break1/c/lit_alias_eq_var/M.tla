---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = Alias
Next == x' = x + 1
Inv == x < 5
Alias == 3
====
