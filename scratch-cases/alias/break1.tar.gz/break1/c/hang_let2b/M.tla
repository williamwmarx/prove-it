---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
Alias == [x |-> x, v |-> LET q[i \in 1..2, j \in 1..2] == IF i = 1 THEN j ELSE q[i - 1, j] + 1 IN q[2, 1]]
====
