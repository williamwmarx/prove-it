---- MODULE M ----
EXTENDS Integers

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
Alias == -3
====
