---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = 1 - x

Alias == "z"
Spec == Init /\ [][Next]_x /\ WF_x(Next)
P == <>(x = 2)
====
