---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
Alias == [x |-> x, v |-> LET g[i \in 1..1] == IF i = 1 THEN 1 \div 0 ELSE g[i] IN g]
====
