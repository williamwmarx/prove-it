---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
g[i \in 0..2] == IF i = x THEN 1 \div 0 ELSE IF i = 0 THEN 0 ELSE g[i - 1]
Alias == [x |-> x, v |-> g]
====
