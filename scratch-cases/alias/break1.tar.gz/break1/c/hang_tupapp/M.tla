---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
q[<<i, j>> \in (1..2) \X (1..2)] == IF i = 1 THEN j ELSE q[<<i - 1, j>>] + 1
Alias == [x |-> x, v |-> q[<<2, 2>>]]
====
