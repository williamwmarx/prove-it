---- MODULE M ----
EXTENDS Naturals

VARIABLE x, y
Init == x = 0 /\ y = 0
Next == x' = x + 1 /\ y' = y
Inv == x < 2
V == x
Alias == [x |-> x, y |-> Nat]
====
