---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
f[i \in 0..3] == IF i = 0 THEN 0 ELSE LET q[k \in 0..1] == f[i - 1] IN q[0] + 1
Alias == [x |-> x, v |-> f]
====
