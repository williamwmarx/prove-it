---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x < 2 /\ x' = x + 1

Alias == 3
PC == 7
====
