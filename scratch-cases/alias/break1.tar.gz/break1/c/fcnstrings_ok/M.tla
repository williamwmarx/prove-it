---- MODULE M ----
EXTENDS Naturals

VARIABLE x, y
Init == x = 0 /\ y = 0
Next == x' = x + 1 /\ y' = y
Inv == x < 2
Alias == [k \in {"x", "y"} |-> IF k = "x" THEN x ELSE 5]
====
