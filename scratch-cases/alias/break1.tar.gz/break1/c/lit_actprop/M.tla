---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1

Alias == 3
AP == [][x' = x + 1 /\ x < 1]_x
====
