---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
f[i \in 0..40] == IF i = 0 THEN 0 ELSE f[i - 1] + 1
Alias == [x |-> x, v |-> f[40]]
====
