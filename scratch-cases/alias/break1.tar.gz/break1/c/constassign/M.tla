---- MODULE M ----
EXTENDS Naturals
CONSTANT Alias
VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2

====
