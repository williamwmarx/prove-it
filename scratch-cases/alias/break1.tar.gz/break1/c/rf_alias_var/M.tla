---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
g[i \in 0..x] == IF i = 0 THEN x ELSE g[i - 1] + 1
Alias == [x |-> x, v |-> g]
====
