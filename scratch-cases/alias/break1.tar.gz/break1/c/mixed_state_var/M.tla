---- MODULE M ----
EXTENDS Naturals, FiniteSets

VARIABLE x
Init == x = {1, 2}
Next == x' = x \cup {Cardinality(x) + 1}
Inv == Cardinality(x) < 4
Alias == [x |-> x]
====
