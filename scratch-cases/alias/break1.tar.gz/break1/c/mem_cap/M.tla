---- MODULE M ----
EXTENDS Naturals, FiniteSets

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 1 \/ 7 \notin ({1, TRUE} \cap {2})

====
