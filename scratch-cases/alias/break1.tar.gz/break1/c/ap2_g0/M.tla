---- MODULE M ----
EXTENDS Naturals

VARIABLE x, y
Init == x = 0 /\ y = 0
Next == x' = x + 1 /\ y' = y

g[i \in 1..1] == IF i = 1 THEN 1 \div 0 ELSE g[i]
AP == [][x' = x + 1 => x < 0]_x
Alias == [x |-> x, y |-> IF x = 0 THEN g ELSE 0]
====
