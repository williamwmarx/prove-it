---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
Alias == [x |-> x, _format |-> "%1$s"]
====
