---- MODULE M ----
EXTENDS Naturals

VARIABLE x, y
Init == x = 0 /\ y = 0
Next == x' = x + 1 /\ y' = y
Inv == x < 2
Alias == [x |-> x, y |-> IF x = 1 THEN 1 \div 0 ELSE g]
g[i \in 1..1] == IF i = 1 THEN 1 \div 0 ELSE g[i]
====
