---- MODULE M ----
EXTENDS Naturals
x0 == 2

VARIABLE x
Init == x = f[x0]
Next == x' = x + 1
Inv == x < 2
f[i \in 0..2] == IF i = 2 THEN 1 \div 0 ELSE IF i = 0 THEN 0 ELSE f[i - 1]
====
