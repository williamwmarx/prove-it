---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = g
Inv == TRUE
g[i \in 1..1] == IF i = 1 THEN 1 \div 0 ELSE g[i]
====
