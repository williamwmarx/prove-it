---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
g[i \in {}] == g[i]
Alias == [x |-> x, v |-> g]
====
