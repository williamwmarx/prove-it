---- MODULE M ----
EXTENDS Naturals

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == f[3] = 3 /\ (x < 2 \/ 1 \div 0 = 0)
f[i \in 0..3] == IF i = 0 THEN 0 ELSE f[i - 1] + 1
====
