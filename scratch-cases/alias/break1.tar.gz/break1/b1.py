def mk(defs, alias='Alias', inv='Inv == x < 2', extra_cfg='', head='EXTENDS Naturals', consts='', vars_='x', init='x = 0', nxt="x' = x + 1", cfg_inv='INVARIANT Inv'):
    tla=f"---- MODULE M ----\n{head}\n{consts}\nVARIABLE {vars_}\nInit == {init}\nNext == {nxt}\n{inv}\n{defs}\n====\n"
    cfg=f"INIT Init\nNEXT Next\n{cfg_inv}\n{('ALIAS '+alias) if alias else ''}\n{extra_cfg}\n"
    return tla,cfg
C=[]
def add(n,*a,**k): C.append((n,)+mk(*a,**k))
add('lit3','Alias == 3')
add('litneg','Alias == -3', head='EXTENDS Integers')
add('litstr','Alias == "a"')
add('litparen','Alias == (3)')
add('litlet','Alias == LET a == 3 IN a')
add('littrue','Alias == TRUE')
add('litset','Alias == {1,2}')
add('litrec','Alias == [a |-> 1]')
add('litwide','Alias == 10000000000')
add('litbig','Alias == 2147483648')
add('litmax','Alias == 2147483647')
add('litexpr','Alias == 1 + 2')
add('constassign','', consts='CONSTANT Alias', extra_cfg='CONSTANT Alias = 3')
add('constmv','', consts='CONSTANT Alias', extra_cfg='CONSTANT Alias = Alias')
add('constmvdef','Alias == [x |-> x]', extra_cfg='CONSTANT Alias = 3')
add('constsubst','Q == [x |-> x, y |-> 1]', consts='CONSTANT Alias', extra_cfg='CONSTANT Alias <- Q')
add('defsubst','Q == [x |-> x, y |-> 1]\nAlias == [x |-> x]', extra_cfg='CONSTANT Alias <- Q')
add('defsubstlit','Q == 3\nAlias == [x |-> x]', extra_cfg='CONSTANT Alias <- Q')
add('defsubstq','Q == [x |-> x, y |-> 7]\nAlias == 3', extra_cfg='CONSTANT Alias <- Q')
add('constassign_str','', consts='CONSTANT Alias', extra_cfg='CONSTANT Alias = "s"')
add('constassign_set','', consts='CONSTANT Alias', extra_cfg='CONSTANT Alias = {1,2}')
add('lit3_dead','Alias == 3', inv='Inv == TRUE', nxt="x < 2 /\\ x' = x + 1")
add('lit3_init','Alias == 3', inv='Inv == x > 0')
add('litstr_tool','Alias == "abc"', inv='Inv == x < 3')
add('constdep','Alias == N', consts='CONSTANT N', extra_cfg='CONSTANT N = 3')
add('constdeprec','Alias == [x |-> x, n |-> N]', consts='CONSTANT N', extra_cfg='CONSTANT N = 3')
CASES=C
