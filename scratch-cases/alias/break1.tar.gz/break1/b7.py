import sys; sys.path.insert(0,'/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad/break1')
from common import mk
C=[]
def add(n,*a,**k): C.append((n,)+mk(*a,**k))
G2='g2[i \\in 1..2, j \\in 1..2] == IF i = 1 THEN j ELSE g2[i - 1, j] + 1'
add('hang_inv_err', G2, alias='', inv='Inv == x < 2 \\/ g2[2, 2] = 1 \\div 0')
add('hang_inv_err2', G2, alias='', inv='Inv == g2[2, 2] = 3 /\\ (x < 2 \\/ g2[2, 2] = 1 \\div 0)')
add('hang_next_err', G2, alias='', inv='Inv == TRUE', nxt="x' = x + 1 /\\ (x < 2 \\/ g2[2, 2] = 1 \\div 0)")
add('hang_postcond', G2+'\nPC == g2[2, 2] = 4', alias='', inv='', nxt="x < 2 /\\ x' = x + 1", cfg_inv='POSTCONDITION PC\nCHECK_DEADLOCK FALSE')
add('hang_print', G2, alias='', inv='Inv == x < 2 \\/ PrintT(g2[2, 2])', head='EXTENDS Naturals, TLC')
add('hang_let2b','Alias == [x |-> x, v |-> LET q[i \\in 1..2, j \\in 1..2] == IF i = 1 THEN j ELSE q[i - 1, j] + 1 IN q[2, 1]]')
add('hang_1b_2arg','q[i \\in 1..3] == IF i = 1 THEN 0 ELSE q[i - 1] + q[i - 1]\nAlias == [x |-> x, v |-> q[3]]')
add('hang_tupapp','q[<<i, j>> \\in (1..2) \\X (1..2)] == IF i = 1 THEN j ELSE q[<<i - 1, j>>] + 1\nAlias == [x |-> x, v |-> q[<<2, 2>>]]')
add('hang_assert', G2, alias='', inv='Inv == Assert(x < 2, g2[2, 2])', head='EXTENDS Naturals, TLC')
CASES=C
