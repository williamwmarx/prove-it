# tlc1.sh name [binary-flag]  -> show TLC output and branch output
D=/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad/break1/c/$1
T=$(mktemp -d); cp $D/M.tla $D/M.cfg $T; cd $T
echo "--- TLC"; /home/user/ext/tlcbuild/tlc -workers 1 -nowarning -fp 0 -lncheck final -noGenerateSpecTE -config M.cfg M.tla 2>&1 | grep -v '^Starting\|^Finished\|^TLC2\|^Running\|pid\|^Parsing\|^Semantic\|^Computing\|^Progress\|^Implied\|^Checking\|^Model checking completed\|JAVA'
echo "--- branch"; /home/user/ext/wt-rec/packages/prove-it/native/target/release/prove-it -workers 1 -nowarning -fp 0 -lncheck final -noGenerateSpecTE -config M.cfg M.tla 2>&1 | grep -v '^Starting\|^Finished\|^TLC2\|^Running\|pid\|^Parsing\|^Semantic\|^Computing\|^Progress\|^Implied\|^Checking\|^Model checking completed'
echo "--- main"; /home/user/ext/wt-base/packages/prove-it/native/target/release/prove-it -workers 1 -nowarning -fp 0 -lncheck final -noGenerateSpecTE -config M.cfg M.tla 2>&1 | grep -v '^Starting\|^Finished\|^TLC2\|^Running\|pid\|^Parsing\|^Semantic\|^Computing\|^Progress\|^Implied\|^Checking\|^Model checking completed'
cd /; rm -rf $T
