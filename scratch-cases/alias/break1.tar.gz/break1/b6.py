import sys; sys.path.insert(0,'/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad/break1')
from common import mk
C=[]
def add(n,*a,**k): C.append((n,)+mk(*a,**k))
G='g[i \\in 1..2] == IF i = 1 THEN 1 \\div 0 ELSE g[i - 1]'
H='h[i \\in 1..2] == IF i = 1 THEN 1 \\div 0 ELSE IF i = 2 THEN 5 ELSE h[i - 1]'
ops={'eqconst':'g = [i \\in 1..2 |-> 0]','in':'g \\in [1..2 -> Nat]','card':'Cardinality({g})','except':'[g EXCEPT ![2] = 0]',
     'tupeq':'<<g>> = <<g>>','neq':'g # g','setmem':'g \\in {g}','h_eq':'h = h', 'h_app2':'h[2]', 'h_except_app':'[h EXCEPT ![1] = 0][2]',
     'g_domain_card':'Cardinality(DOMAIN g)','g_seqlen':'Len(g)','g_concat':'g \\o <<1>>'}
for k,e in ops.items():
    add('al_'+k, G+'\n'+H+f'\nAlias == [x |-> x, v |-> {e}]', head='EXTENDS Naturals, FiniteSets, Sequences')
for k in ['eqconst','in','tupeq','h_eq','h_app2','h_except_app','g_seqlen']:
    add('inv_'+k, G+'\n'+H, alias='', inv=f'Inv == x < 2 \\/ ({ops[k]}) = 7', head='EXTENDS Naturals, FiniteSets, Sequences')
add('inv_heq_bool', G+'\n'+H, alias='', inv='Inv == x < 2 \\/ h = h', head='EXTENDS Naturals')
add('next_err_h', H, alias='', inv='Inv == TRUE', nxt="x' = x + 1 /\\ (x < 2 \\/ h = h)", head='EXTENDS Naturals')
add('h_deep','f[i \\in 0..40] == IF i = 0 THEN 0 ELSE f[i - 1] + 1\nAlias == [x |-> x, v |-> f[40]]')
add('h_fib','f[i \\in 0..18] == IF i < 2 THEN i ELSE f[i - 1] + f[i - 2]\nAlias == [x |-> x, v |-> f[18]]')
add('h_2b_app','g2[i \\in 1..3, j \\in 1..2] == IF i = 1 THEN j ELSE g2[i - 1, j] + 1\nAlias == [x |-> x, v |-> g2[3, 2]]')
add('h_2b_inv','g2[i \\in 1..2, j \\in 1..2] == IF i = 1 THEN j ELSE g2[i - 1, j] + 1', alias='', inv='Inv == g2[2, 2] = 3 /\\ (x < 2 \\/ 1 \\div 0 = 0)')
add('h_1b_inv','f[i \\in 0..3] == IF i = 0 THEN 0 ELSE f[i - 1] + 1', alias='', inv='Inv == f[3] = 3 /\\ (x < 2 \\/ 1 \\div 0 = 0)')
add('h_tup_ok','g2[<<i, j>> \\in (1..2) \\X (1..2)] == IF i = 1 THEN j ELSE g2[<<i - 1, j>>] + 1\nAlias == [x |-> x, v |-> g2]')
add('h_mutual','f[i \\in 0..3] == IF i = 0 THEN 0 ELSE LET q[k \\in 0..1] == f[i - 1] IN q[0] + 1\nAlias == [x |-> x, v |-> f]')
CASES=C
