import sys; sys.path.insert(0,'/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad/break1')
from common import mk
C=[]
def add(n,*a,**k): C.append((n,)+mk(*a,**k))
exprs={
 'cup_empty_r':'{1, TRUE} \\cup {}',
 'cup_empty_l':'{} \\cup {1, TRUE}',
 'cup_self':'{1, TRUE} \\cup {1, TRUE}',
 'cup_true':'{1, TRUE} \\cup {TRUE}',
 'cup_one':'{1, TRUE} \\cup {1}',
 'cup_ivl':'{1, TRUE} \\cup 1..2',
 'ivl_cup':'1..2 \\cup {1, TRUE}',
 'cup_nat':'{1, TRUE} \\cup Nat',
 'nat_cup':'Nat \\cup {1, TRUE}',
 'cup_subset':'{1, TRUE} \\cup SUBSET {1}',
 'cup_str':'{"a", 1} \\cup {"a"}',
 'cup_tup':'{<<1>>, 2} \\cup {3}',
 'cup_nested':'({1, TRUE} \\cup {}) \\cup {2}',
 'cup_ivlempty':'{1, TRUE} \\cup 1..0',
 'cap':'{1, TRUE} \\cap {2}',
 'diff':'{1, TRUE} \\ {2}',
 'union':'UNION {{1, TRUE}, {2}}',
 'filter':'{e \\in {1, TRUE} : TRUE}',
 'map':'{e : e \\in {1, TRUE}}',
 'fnset':'[{1, TRUE} -> {2}]',
 'recset':'[a : {1, TRUE}]',
 'card':'Cardinality({1, TRUE} \\cup {2})',
}
for k,e in exprs.items():
    add('al_'+k, f'Alias == [x |-> x, v |-> {e}]', head='EXTENDS Naturals, FiniteSets')
    add('pl_'+k, f'Alias == IF x >= 0 THEN {e} ELSE {{}}', head='EXTENDS Naturals, FiniteSets')
for k in ['cup_empty_r','cup_true','cup_one','cup_ivl','ivl_cup','nat_cup','cup_str','cup_tup','cap','diff']:
    add('inv_'+k, '', alias='', inv=f'Inv == x < 1 \\/ {exprs[k]} # {{}}', head='EXTENDS Naturals, FiniteSets')
    add('mem_'+k, '', alias='', inv=f'Inv == x < 1 \\/ 7 \\notin ({exprs[k]})', head='EXTENDS Naturals, FiniteSets')
CASES=C
