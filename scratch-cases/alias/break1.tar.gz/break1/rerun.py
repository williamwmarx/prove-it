import os, subprocess, glob
B=os.path.dirname(os.path.abspath(__file__))
main={}
for f in sorted(glob.glob(B+'/b*.out')):
    name=None
    for line in open(f):
        if line.startswith('== '): name=line[3:].strip()
        elif name and line.strip().startswith('main:'): main[name]=line.strip()[5:].strip()
for name in sorted(os.listdir(B+'/c')):
    d=f'{B}/c/{name}'
    r=subprocess.run(['bash',B+'/caseT.sh','/home/user/ext/wt-rec/packages/prove-it/native/target/release/prove-it',f'{d}/M.tla',f'{d}/M.cfg'],capture_output=True,text=True)
    br=' '.join(r.stdout.split())[:110]
    print(f'{name}\n  main:   {main.get(name,"?")[:110]}\n  branch: {br}',flush=True)
