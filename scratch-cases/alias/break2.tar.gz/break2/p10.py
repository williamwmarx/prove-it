import sys; sys.path.insert(0,'/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad/break2')
from common import mk2
C=[]
G = 'g[i \\in 1..2] == IF i = 2 THEN 1 \\div 0 ELSE IF i = 0 THEN g[i] ELSE i'
H = 'EXTENDS Naturals, TLC, Sequences, FiniteSets'
def add(n, **k): C.append((n,)+mk2(G, alias=None, head=H, **k))
add('k_next_eq', nxt="x' = IF g = <<1, 2>> THEN 0 ELSE x + 1")
add('k_next_len', nxt="x' = Len(g)")
add('k_next_eq_s2', nxt="x' = IF x = 1 /\\ g = <<1, 2>> THEN 0 ELSE x + 1")
add('k_next_tupmem', nxt="x' = IF g \\in Seq(Nat) THEN 0 ELSE x + 1")
add('k_init_eq', init="x = 0 /\\ g # <<1, 2>>")
add('k_inv_eq_s2', inv="Inv == x < 2 \\/ g = <<1, 2>>")
add('k_next_int_in', nxt="x' = IF 1 \\in {g} THEN 0 ELSE x + 1")
add('k_next_field', nxt="x' = g.a")
CASES=C
