def mk(defs, alias='Alias', inv='Inv == x < 2', extra_cfg='', head='EXTENDS Naturals', consts='', vars_='x', init='x = 0', nxt="x' = x + 1", cfg_inv='INVARIANT Inv', cfg_head='INIT Init\nNEXT Next'):
    tla=f"---- MODULE M ----\n{head}\n{consts}\nVARIABLE {vars_}\nInit == {init}\nNext == {nxt}\n{inv}\n{defs}\n====\n"
    cfg=f"{cfg_head}\n{cfg_inv}\n{('ALIAS '+alias) if alias else ''}\n{extra_cfg}\n"
    return tla,cfg

def mk2(defs, alias='Alias', inv='Inv == x < 2', extra_cfg='', head='EXTENDS Naturals', consts='', vars_='x', init='x = 0', nxt="x' = x + 1", cfg_inv='INVARIANT Inv', cfg_head='INIT Init\nNEXT Next'):
    tla=f"---- MODULE M ----\n{head}\n{consts}\nVARIABLE {vars_}\n{defs}\nInit == {init}\nNext == {nxt}\n{inv}\n====\n"
    cfg=f"{cfg_head}\n{cfg_inv}\n{('ALIAS '+alias) if alias else ''}\n{extra_cfg}\n"
    return tla,cfg
