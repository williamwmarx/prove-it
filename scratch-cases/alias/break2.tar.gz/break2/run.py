import sys, os, subprocess, importlib.util
S='/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad'
B=S+'/break1'; C2=S+'/break2'
spec=importlib.util.spec_from_file_location('cases', sys.argv[1]); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
only=sys.argv[2:] 
for name,tla,cfg in m.CASES:
    if only and name not in only: continue
    d=f'{C2}/c/{name}'; os.makedirs(d,exist_ok=True)
    open(f'{d}/M.tla','w').write(tla); open(f'{d}/M.cfg','w').write(cfg)
    # check TLC reaches checking
    r=subprocess.run(['bash',B+'/case3T.sh',f'{d}/M.tla',f'{d}/M.cfg'],capture_output=True,text=True)
    t=subprocess.run(['/home/user/ext/tlcbuild/tlc','-workers','1','-nowarning','-config','M.cfg','M.tla'],cwd=d,capture_output=True,text=True).stdout.splitlines()
    key=[l for l in t if ('rror' in l or 'violated' in l or 'states generated' in l or 'Deadlock' in l) and 'TLC2' not in l][:2]
    print(f'== {name}  TLC: {key}\n{r.stdout}',flush=True)
