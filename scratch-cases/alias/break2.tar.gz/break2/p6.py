import sys; sys.path.insert(0,'/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad/break2')
from common import mk
C=[]
G = 'g[i \\in 1..2] == IF i = 2 THEN 1 \\div 0 ELSE IF i = 0 THEN g[i] ELSE i'
H = 'EXTENDS Naturals, TLC, Sequences, FiniteSets, Bags'
def al(n, e, **k): C.append((n,)+mk(G+'\nAlias == [x |-> x, v |-> '+e+']', head=H, **k))
al('e_int_eq', '1 = g')
al('e_rec_eq', '[a |-> 1] = g')
al('e_set_eq', '{1} = g')
al('e_str_eq', '"s" = g')
al('e_eq_str', 'g = "s"')
al('e_recset', 'g \\in [a : Nat]')
al('e_nat', 'g \\in Nat')
al('e_tup_eq', '<<g>> = <<g>>')
al('e_int_in', '1 \\in {g}')
al('e_g_in_int', 'g \\in {1}')
al('e_bool_eq', 'TRUE = g')
al('e_neq_tuple', 'g # <<1, 2>>')
al('e_subseteq', '{g} \\subseteq [1..2 -> Nat]')
al('e_isfcnset_domain', '[k \\in DOMAIN g |-> 0]')
al('e_copies', 'CopiesIn(1, g)')
al('e_issubbag', 'g \\sqsubseteq g')
al('e_except_at', '[g EXCEPT ![1] = @ + 1]')
al('e_except_at2', '[g EXCEPT ![2] = @ + 1]')
al('e_except_print2', '[g EXCEPT ![2] = 9, ![1] = 8]')
al('e_choose_eq', 'CHOOSE k \\in {g} : TRUE')
CASES=C
