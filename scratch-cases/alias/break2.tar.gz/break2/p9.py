import sys; sys.path.insert(0,'/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad/break2')
from common import mk, mk2
C=[]
G = 'g[i \\in 1..2] == IF i = 2 THEN 1 \\div 0 ELSE IF i = 0 THEN g[i] ELSE i'
H = 'EXTENDS Naturals, TLC, Sequences, FiniteSets'
def al(n, e, **k): C.append((n,)+mk(G+'\nAlias == [x |-> x, v |-> '+e+']', head=H, **k))
al('m_int_in_g2', '1 \\in {g, 2}')
al('m_str_in_g', '"s" \\in {g}')
al('m_tup_in_g', '<<1, 2>> \\in {g}')
al('m_rec_in_g', '[a |-> 1] \\in {g}')
al('m_set_in_g', '{1} \\in {g}')
al('m_g_in_tup', 'g \\in {<<1, 2>>}')
al('m_g_in_g_tup', 'g \\in {<<1, 2>>, g}')
al('m_notin', '1 \\notin {g}')
al('m_set_eq', '{g} = {g}')
al('m_choose_eq', 'CHOOSE k \\in {1} : k = g')
al('m_card', 'Cardinality({g})')
al('m_cap', '{g} \\cap {1}')
al('m_cup', '{g} \\cup {1}')
al('m_minus', '{1} \\ {g}')
al('m_subset', 'SUBSET {g}')
al('m_union', 'UNION {{g}}')
al('m_in_inv', '1', inv='Inv == x < 2 /\\ 1 \\notin {g}')
C.append(('m_in_inv_noalias',)+mk2(G, alias=None, head=H, inv='Inv == x < 2 /\\ 1 \\notin {g}'))
C.append(('m_in_inv_noalias2',)+mk2(G, alias=None, head=H, inv='Inv == x < 2 /\\ ~(1 \\in {g, 2})'))
C.append(('m_in_next_noalias',)+mk2(G, alias=None, head=H, nxt="x' = IF 1 \\in {g} THEN 0 ELSE x + 1"))
CASES=C
