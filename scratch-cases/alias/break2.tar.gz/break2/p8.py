import sys; sys.path.insert(0,'/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad/break2')
from common import mk
C=[]
H = 'EXTENDS Naturals, TLC, Sequences, FiniteSets'
def add(n,*a,**k): C.append((n,)+mk(*a,**k))
INNER = 'EXTENDS Naturals\n---- MODULE Inner ----\nVARIABLE z\ng[i \\in 1..2] == IF i = 2 THEN 1 \\div 0 ELSE IF i = 0 THEN g[i] ELSE i\nR == [z |-> z, v |-> g]\nR2 == [z |-> z]\nRL == "lit"\n===='
add('s_inst_rec', 'I == INSTANCE Inner WITH z <- x\nAlias == I!R2', head=INNER)
add('s_inst_rec_g', 'I == INSTANCE Inner WITH z <- x\nAlias == I!R', head=INNER)
add('s_inst_subst_lit', 'I == INSTANCE Inner WITH z <- x\nQ == I!RL\nAlias == [x |-> x]', head=INNER, extra_cfg='CONSTANT Alias <- Q')
add('lit_string_def_used', '', head='EXTENDS Naturals\nAlias == "abc"', inv='Inv == x < 2 /\\ Alias = "abc"')
add('rf_alias_strdom', 'h[s \\in {"x", "v"}] == IF s = "x" THEN x ELSE IF s = "q" THEN h[s] ELSE 7\nAlias == h', head=H)
add('rf_alias_strdom_fail', 'h[s \\in {"x", "v"}] == IF s = "x" THEN x ELSE IF s = "q" THEN h[s] ELSE 1 \\div 0\nAlias == h', head=H)
add('rf_alias_ivl', 'h[s \\in 1..2] == IF s = 0 THEN h[s] ELSE x\nAlias == h', head=H)
add('nrf_alias_strdom', 'h[s \\in {"x", "v"}] == IF s = "x" THEN x ELSE 7\nAlias == h', head=H)
add('rf_alias_strdom_let', 'Alias == LET h[s \\in {"x", "v"}] == IF s = "x" THEN x ELSE IF s = "q" THEN h[s] ELSE 7 IN h', head=H)
add('rf_alias_strdom_except', 'h[s \\in {"x", "v"}] == IF s = "x" THEN x ELSE IF s = "q" THEN h[s] ELSE 7\nAlias == [h EXCEPT !["v"] = 8]', head=H)
add('view_alias_str', 'V == x + 1\nAlias == [x |-> "s"]', head=H, extra_cfg='VIEW V')
add('view_alias_str_s2', 'V == x + 1\nAlias == [x |-> IF x = 1 THEN "s" ELSE x]', head=H, extra_cfg='VIEW V')
add('view_y_alias_nat_x', 'V == y\nAlias == [x |-> IF x = 1 THEN Nat ELSE x, y |-> y]', vars_='x, y', init='x = 0 /\\ y = 0', nxt="x' = x + 1 /\\ y' = y + 1", head=H, extra_cfg='VIEW V')
add('alias_extra_nat', 'Alias == [x |-> x, z |-> Nat]', head=H)
add('alias_combine_rec', 'Alias == [x |-> x] @@ [y |-> Nat]', head=H)
add('alias_combine_rec_var', 'Alias == [x |-> x] @@ [w |-> 1]', head=H)
add('sym_alias_mv', 'Sym == Permutations(P)\nAlias == [x |-> x, n |-> Cardinality(x)]', consts='CONSTANT P', init='x = {}', nxt="\\E p \\in P : x' = x \\cup {p}", inv='Inv == Cardinality(x) < 2', head=H, extra_cfg='CONSTANT P = {p1, p2}\nSYMMETRY Sym')
CASES=C
