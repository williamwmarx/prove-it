import sys; sys.path.insert(0,'/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad/break2')
from common import mk
C=[]
H = 'EXTENDS Naturals, TLC, Sequences, FiniteSets'
L = 'LET h[i \\in {RandomElement(1..1000)}] == IF i > 0 THEN 1 \\div 0 ELSE h[i] IN '
def add(n,*a,**k): C.append((n,)+mk(*a,head=H,**k))
add('r_lazy_text', 'Alias == [x |-> x, v |-> '+L+'h]')
add('r_eq_then_draw', 'Alias == [x |-> x, w |-> RandomElement(1..1000), v |-> IF x = 0 THEN '+L+'h = h ELSE 0]')
add('r_draw_only', 'Alias == [x |-> x, w |-> RandomElement(1..1000), v |-> IF x = 0 THEN '+L+'h[1] ELSE 0]')
add('r_domain_then_draw', 'Alias == [x |-> x, v |-> '+L+'DOMAIN h, w |-> RandomElement(1..1000)]')
CASES=C
