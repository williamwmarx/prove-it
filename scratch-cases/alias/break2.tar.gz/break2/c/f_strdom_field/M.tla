---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
g[i \in {"a", "b"}] == IF i = "b" THEN 1 \div 0 ELSE IF i = "z" THEN g[i] ELSE 1
Alias == [x |-> x, v |-> g.a]
====
