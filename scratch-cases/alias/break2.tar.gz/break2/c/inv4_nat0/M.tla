---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 3
Alias == [x |-> IF x = 0 THEN Nat ELSE x]
====
