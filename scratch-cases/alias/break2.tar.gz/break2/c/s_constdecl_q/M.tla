---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT Alias
VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
Q == [x |-> x + 10]
====
