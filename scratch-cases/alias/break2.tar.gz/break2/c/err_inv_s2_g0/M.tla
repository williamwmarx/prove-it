---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == IF x = 1 THEN 1 \div 0 = 1 ELSE TRUE
g[i \in 1..1] == IF i = 1 THEN 1 \div 0 ELSE g[i]
Alias == [x |-> IF x = 0 THEN g ELSE x]
====
