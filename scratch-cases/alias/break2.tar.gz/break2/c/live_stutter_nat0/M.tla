---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
Init == x = 0
Next == x < 2 /\ x' = x + 1
Inv == TRUE
Alias == [x |-> IF x = 0 THEN Nat ELSE x]
Spec == Init /\ [][Next]_x
L == <>(x = 5)
====
