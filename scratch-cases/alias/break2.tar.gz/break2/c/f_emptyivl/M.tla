---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
g[i \in 1..0] == g[i]
Alias == [x |-> x, v |-> g]
====
