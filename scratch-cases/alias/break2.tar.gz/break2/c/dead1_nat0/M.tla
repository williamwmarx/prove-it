---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
Init == x = 0
Next == FALSE /\ x' = x
Inv == TRUE
Alias == [x |-> IF x = 0 THEN Nat ELSE x]
====
