---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == TRUE
Alias == [x |-> IF x = 1 THEN Nat ELSE x]
AP == [][x < 1]_x
====
