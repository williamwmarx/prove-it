---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
h[i \in 0..x] == IF i = 2 THEN 1 \div 0 ELSE IF i = 0 THEN 0 ELSE h[i - 1] + i
Init == x = 0
Next == x' = x + 1
Inv == h = h
====
