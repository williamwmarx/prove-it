---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == TRUE
Alias == [x |-> IF x = 0 THEN Nat ELSE x]
====
