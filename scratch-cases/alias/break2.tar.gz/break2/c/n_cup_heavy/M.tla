---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x

Init == x = 0
Next == x' \in ({x + 1} \cup {x + 2}) \cup ({} \cup 1..2)
Inv == x < 4
====
