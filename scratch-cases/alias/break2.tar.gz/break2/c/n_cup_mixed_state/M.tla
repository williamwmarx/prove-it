---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x

Init == x = {}
Next == x' = x \cup {"a"} \cup {1}
Inv == TRUE
====
