---- MODULE M ----
EXTENDS Naturals
---- MODULE Inner ----
VARIABLE z
g[i \in 1..2] == IF i = 2 THEN 1 \div 0 ELSE IF i = 0 THEN g[i] ELSE i
R == [z |-> z, v |-> g]
R2 == [z |-> z]
RL == "lit"
====

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
I == INSTANCE Inner WITH z <- x
Q == I!RL
Alias == [x |-> x]
====
