---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
Init == x = 0
Next == x < 1 /\ x' = x + 1
Inv == TRUE
Alias == [x |-> x]
====
