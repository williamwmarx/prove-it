---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x, y
Init == x = 0 /\ y = 0
Next == x' = x + 1 /\ IF x = 0 THEN TRUE ELSE y' = y
Inv == TRUE
Alias == [x |-> IF x = 0 THEN Nat ELSE x, y |-> y]
====
