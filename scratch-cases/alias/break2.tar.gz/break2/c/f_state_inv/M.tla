---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2 /\ g[0] = 0
g[i \in 0..x] == IF i = 2 THEN 1 \div 0 ELSE IF i = 0 THEN 0 ELSE g[i - 1] + 1
Alias == [x |-> x, v |-> g[0]]
====
