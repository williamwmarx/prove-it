---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 3
Inv == TRUE
Alias == 3
Spec == Init /\ [][Next]_x
L == <>(x = 5)
====
