---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
g[i \in 1..2] == IF i = 2 THEN 1 \div 0 ELSE IF i = 0 THEN g[i] ELSE i
h[j \in 1..2] == IF j = 0 THEN h[j] ELSE g
Alias == [x |-> x, v |-> h[1][1]]
====
