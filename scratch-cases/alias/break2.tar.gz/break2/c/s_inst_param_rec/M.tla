---- MODULE M ----
EXTENDS Naturals
---- MODULE Inner ----
CONSTANT c
VARIABLE z
R == [z |-> z, c |-> c]
====
I == INSTANCE Inner WITH c <- "s", z <- x

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
Alias == I!R
====
