---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
h[s \in 1..2] == IF s = 0 THEN h[s] ELSE x
Alias == h
====
