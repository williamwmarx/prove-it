---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
Alias == [x |-> IF x = 1 THEN Nat \X {1} ELSE x]
====
