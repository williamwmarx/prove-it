---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
Init == x = 0
Next == x' = IF x = 2 THEN 1 \div 0 ELSE x + 1
Inv == TRUE
Alias == [x |-> IF x = 1 THEN Nat ELSE x]
====
