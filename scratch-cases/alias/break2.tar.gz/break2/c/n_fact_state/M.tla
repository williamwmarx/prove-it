---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
fact[n \in 0..4] == IF n = 0 THEN 1 ELSE n * fact[n - 1]
Init == x = 0
Next == x' = IF x = 0 THEN fact ELSE x
Inv == x = 0
====
