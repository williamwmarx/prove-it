---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
Alias == [x |-> x, v |-> LET h[i \in {RandomElement(1..1000)}] == IF i > 0 THEN 1 \div 0 ELSE h[i] IN DOMAIN h, w |-> RandomElement(1..1000)]
====
