---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == IF x = 1 THEN 1 \div 0 = 1 ELSE TRUE
Alias == [x |-> IF x = 0 THEN Nat ELSE x]
====
