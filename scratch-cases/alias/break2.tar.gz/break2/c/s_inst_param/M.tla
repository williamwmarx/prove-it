---- MODULE M ----
EXTENDS Naturals
---- MODULE Inner ----
CONSTANT c
R == c
====
I == INSTANCE Inner WITH c <- 3

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
Alias == I!R
====
