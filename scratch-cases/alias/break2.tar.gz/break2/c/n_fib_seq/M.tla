---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
fib[n \in 1..6] == IF n <= 2 THEN 1 ELSE fib[n - 1] + fib[n - 2]
Init == x = 0
Next == x' = x + 1
Inv == x < 2 \/ fib \in Seq(Nat) /\ Len(fib) = 7
====
