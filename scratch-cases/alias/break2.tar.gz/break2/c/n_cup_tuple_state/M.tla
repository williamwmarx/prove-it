---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x

Init == x = {}
Next == x' = x \cup {<<Cardinality(x), "a">>} \cup {<<0, "a">>}
Inv == Cardinality(x) < 3
====
