---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
g[i \in 1..2] == IF i = 2 THEN g[2] ELSE i
Alias == [x |-> x, v |-> g[1]]
====
