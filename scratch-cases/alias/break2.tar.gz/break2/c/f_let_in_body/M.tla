---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
g[i \in 1..2] == LET q == IF i = 2 THEN 1 \div 0 ELSE i IN IF i = 0 THEN g[i] ELSE q
Alias == [x |-> x, v |-> g]
====
