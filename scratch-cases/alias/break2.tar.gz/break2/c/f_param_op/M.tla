---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
G(n) == LET g[i \in 1..n] == IF i = 2 THEN 1 \div 0 ELSE IF i = 0 THEN g[i] ELSE i IN g
Alias == [x |-> x, v |-> G(2)]
====
