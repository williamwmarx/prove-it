---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
V == x + 1
Alias == [x |-> IF x = 1 THEN "s" ELSE x]
====
