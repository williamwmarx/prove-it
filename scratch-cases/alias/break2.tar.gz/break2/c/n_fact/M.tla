---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
fact[n \in Nat] == IF n = 0 THEN 1 ELSE n * fact[n - 1]
Init == x = 0
Next == x' = fact[x + 1]
Inv == x < 100
====
