---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT P
VARIABLE x
Init == x = {}
Next == \E p \in P : x' = x \cup {p}
Inv == Cardinality(x) < 2
Sym == Permutations(P)
Alias == [x |-> x, n |-> Cardinality(x)]
====
