---- MODULE M ----
EXTENDS Naturals
Alias == "abc"

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2 /\ Alias = "abc"

====
