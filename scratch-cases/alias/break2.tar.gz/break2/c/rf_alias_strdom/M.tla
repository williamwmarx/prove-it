---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x
Init == x = 0
Next == x' = x + 1
Inv == x < 2
h[s \in {"x", "v"}] == IF s = "x" THEN x ELSE IF s = "q" THEN h[s] ELSE 7
Alias == h
====
