---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets

VARIABLE x

Init == x = {}
Next == x' = x \cup {Cardinality(x)} \cup {}
Inv == Cardinality(x) < 3
====
