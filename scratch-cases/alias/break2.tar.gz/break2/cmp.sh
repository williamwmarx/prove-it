#!/bin/bash
# cmp.sh dir binary(main|branch) [args] : full diff TLC vs native
d=$1; [ $2 = main ] && N=/home/user/ext/wt-base/packages/prove-it/native/target/release/prove-it || N=/home/user/ext/wt-rec/packages/prove-it/native/target/release/prove-it
shift 2; T=$(mktemp -d); cp $d/M.tla $d/M.cfg $T; cd $T
F='^Finished\|^Starting\|^Running\|^TLC2\|pid\|tmp\|^Parsing\|^Semantic\|^Linting\|^Computing\|JAVA_TOOL\|Progress'
/home/user/ext/tlcbuild/tlc -workers 1 "$@" -nowarning -fp 0 -lncheck final -noGenerateSpecTE -config M.cfg M.tla 2>&1 | grep -v "$F" > t; echo "tlc exit ${PIPESTATUS[0]}"
timeout 60 $N -workers 1 "$@" -nowarning -fp 0 -lncheck final -noGenerateSpecTE -config M.cfg M.tla 2>&1 | grep -v "$F" > n; echo "native exit ${PIPESTATUS[0]}"
diff t n; echo ---; cat t | head -${LINES_T:-0}
