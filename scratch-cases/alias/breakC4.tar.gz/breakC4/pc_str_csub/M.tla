---- MODULE M ----
EXTENDS Naturals, TLC
CONSTANT C
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 3
PC == "a"

====
