---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x, Alias
Init == x = 0 /\ Alias = 1
Next == x < 3 /\ x' = x + 1 /\ UNCHANGED Alias
Inv == x < 2

====
