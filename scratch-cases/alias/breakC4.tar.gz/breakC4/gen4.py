exec(open("lib.py").read())
AL=INV+"ALIAS Alias\n"
a("fn_alias_num", V+"Alias[i \\in {1}] == 3\n", AL)
a("fn_alias_str", V+"Alias[i \\in {1, 2}] == \"s\"\n", AL)
a("fn_pc_num", C+"PC[i \\in {1}] == 3\n", CC+"POSTCONDITION PC\n")
a("fn_alias_num_deadlock", "VARIABLE x\nInit == x = 0\nNext == x < 2 /\\ x' = x + 1\nAlias[i \\in {1}] == 3\n", CC+"ALIAS Alias\n")
write()
