---- MODULE N ----
CONSTANT c
K == 3
====
