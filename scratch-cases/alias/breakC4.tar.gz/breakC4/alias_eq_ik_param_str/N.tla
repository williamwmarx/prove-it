---- MODULE N ----
CONSTANT c
K == "s"
====
