exec(open("lib.py").read())
AL=INV+"ALIAS Alias\n"
R="Alias == [y |-> x]\n"
VY="VARIABLE x, y\nInit == x = 0 /\\ y = S\nNext == x < 3 /\\ x' = x + 1 /\\ UNCHANGED y\nInv == x < 2\n"
a("asg_alias_mv_and_set", "CONSTANT S\n"+VY+R, AL+"CONSTANT Alias = 3\nCONSTANT S = {Alias}\n")
a("asg_alias_mv_self", V+R, AL+"CONSTANT Alias = Alias\n")
a("asg_alias_mvself_used", "VARIABLE x, y\nAlias == 7\nInit == x = 0 /\\ y = Alias\nNext == x < 3 /\\ x' = x + 1 /\\ UNCHANGED y\nInv == x < 2\n"+"", AL+"CONSTANT Alias = Alias\n")
a("asg_alias_param_named", V.replace("Inv ==","F(Alias) == Alias + 1\nInv == F(x) < 3 /\\")+R, AL+"CONSTANT Alias = 3\n")
a("asg_alias_bound_named", V.replace("Inv ==","Inv == (\\E Alias \\in {x} : Alias < 2) /\\")+R, AL+"CONSTANT Alias = 3\n")
a("asg_alias_let_named", V.replace("Inv ==","Inv == (LET Alias == x IN Alias < 2) /\\")+R, AL+"CONSTANT Alias = 3\n")
a("asg_alias_field_named", "VARIABLE x, y\nInit == x = 0 /\\ y = [Alias |-> 1]\nNext == x < 3 /\\ x' = x + 1 /\\ UNCHANGED y\nInv == x < 2\n"+R, AL+"CONSTANT Alias = 3\n")
a("asg_alias_used_init", "VARIABLE x, y\nAlias == 7\nInit == x = 0 /\\ y = Alias\nNext == x < 3 /\\ x' = x + 1 /\\ UNCHANGED y\nInv == x < 2\n", AL+"CONSTANT Alias = 3\n")
a("asg_alias_used_in_n", V+R+"I == INSTANCE N\nInv2 == I!K = 1\n", AL+"INVARIANT Inv2\nCONSTANT Alias = 3\n", N="Alias == 1\nK == Alias\n")
a("asg_alias_ext_used", "VARIABLE x, y\nInit == x = 0 /\\ y = K\nNext == x < 3 /\\ x' = x + 1 /\\ UNCHANGED y\nInv == x < 2\n", AL+"CONSTANT Alias = 3\n", ext="Naturals, TLC, N", N="Alias == 1\nK == Alias\n")
a("asg_alias_inst_bodyname", V+R+"I == INSTANCE N WITH c <- 2\nInv2 == I!K = 2\n", AL+"INVARIANT Inv2\nCONSTANT Alias = 3\n", N="CONSTANT c\nK == LET Alias == c IN Alias\n")
a("asg_alias_and_view", "VARIABLE x, y\nInit == x = 0 /\\ y = 0\nNext == x < 3 /\\ x' = x + 1 /\\ y' = 1 - y\nInv == x < 2\nV2 == x\n"+R, AL+"VIEW V2\nCONSTANT Alias = 3\n")
write()
