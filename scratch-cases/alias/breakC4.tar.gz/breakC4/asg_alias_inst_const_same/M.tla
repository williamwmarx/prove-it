---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < 2
Alias == [y |-> x]
I == INSTANCE N WITH Alias <- 5
Inv2 == I!K = 5

====
