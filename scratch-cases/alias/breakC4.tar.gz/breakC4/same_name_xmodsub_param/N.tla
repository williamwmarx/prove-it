---- MODULE N ----
CONSTANT c
Alias == 4
X == 0
====
