---- MODULE N2 ----
K == 3
====
