---- MODULE N ----
J == INSTANCE N2
====
