exec(open("lib.py").read())
AL=INV+"ALIAS Alias\n"
a("fn_alias_big", V+"Alias[i \\in {1}] == 3000000000\n", AL)
a("alias_decimal", V+"Alias == 1.5\n", AL)
a("fn_alias_decimal", V+"Alias[i \\in {1}] == 1.5\n", AL)
a("fn_alias_used_inv", "VARIABLE x\nAlias[i \\in {1}] == 3\nInit == x = 0\nNext == x < 3 /\\ x' = x + Alias[1] - 2\nInv == x < 2\n", AL)
a("fn_pc_str", C+"PC[i \\in {1}] == \"a\"\n", CC+"POSTCONDITION PC\n")
a("fn_alias_sim_spec", V+"Alias[i \\in {1}] == 3\nSpec == Init /\\ [][Next]_x\n", "SPECIFICATION Spec\nINVARIANT Inv\nALIAS Alias\n")
write()
