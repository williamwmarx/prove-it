---- MODULE M ----
EXTENDS Naturals, TLC, N
VARIABLE x, y
Init == x = 0 /\ y = K
Next == x < 3 /\ x' = x + 1 /\ UNCHANGED y
Inv == x < 2

====
