---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x, y
Alias == 7
Init == x = 0 /\ y = Alias
Next == x < 3 /\ x' = x + 1 /\ UNCHANGED y
Inv == x < 2

====
