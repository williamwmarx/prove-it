---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == (LET Alias == x IN Alias < 2) /\ x < 2
Alias == [y |-> x]

====
