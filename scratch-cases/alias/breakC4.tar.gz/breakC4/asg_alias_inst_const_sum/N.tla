---- MODULE N ----
EXTENDS Naturals
CONSTANT Alias
K == Alias + 0
====
