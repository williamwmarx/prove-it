---- MODULE N ----
RECURSIVE Alias
Alias == 3
====
