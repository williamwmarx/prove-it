---- MODULE N ----
Alias[i \in {1}] == "t"
====
