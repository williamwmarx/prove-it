---- MODULE M ----
EXTENDS Naturals, TLC
CONSTANT C
VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < 2
Alias == [y |-> x]
Lit == 3

====
