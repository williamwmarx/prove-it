---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1
F(Alias) == Alias + 1
Inv == F(x) < 3 /\ x < 2
Alias == [y |-> x]

====
