---- MODULE M ----
EXTENDS Naturals, TLC
CONSTANT S
VARIABLE x, y
Init == x = 0 /\ y = S
Next == x < 3 /\ x' = x + 1 /\ UNCHANGED y
Inv == x < 2
Alias == [y |-> x]

====
