---- MODULE N ----
CONSTANT c
K == LET Alias == c IN Alias
====
