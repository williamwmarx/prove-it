---- MODULE N ----
VARIABLE Alias
K == Alias
====
