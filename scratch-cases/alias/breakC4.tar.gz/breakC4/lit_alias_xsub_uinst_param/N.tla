---- MODULE N ----
CONSTANT c
X == c
====
