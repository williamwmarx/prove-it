---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x, y
Init == x = 0 /\ y = 0
Next == x < 3 /\ x' = x + 1 /\ y' = 1 - y
Inv == x < 2
V2 == x
Alias == [y |-> x]

====
