---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Alias[i \in {1}] == 3
Init == x = 0
Next == x < 3 /\ x' = x + Alias[1] - 2
Inv == x < 2

====
