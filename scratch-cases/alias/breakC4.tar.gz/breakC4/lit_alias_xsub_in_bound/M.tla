---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < 2
Inv3 == \A Alias \in {1} : Alias = 1
Alias == 3
X == 0

====
