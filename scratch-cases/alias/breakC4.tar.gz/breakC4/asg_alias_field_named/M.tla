---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x, y
Init == x = 0 /\ y = [Alias |-> 1]
Next == x < 3 /\ x' = x + 1 /\ UNCHANGED y
Inv == x < 2
Alias == [y |-> x]

====
