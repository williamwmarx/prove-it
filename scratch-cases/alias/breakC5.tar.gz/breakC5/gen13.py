exec(open("lib.py").read())
AL=INV+"ALIAS Alias\n"
a("thm_uinst_param", V+"INSTANCE N WITH c <- 1\n", AL, N="CONSTANT c\nTHEOREM Alias == 3\n")
a("thm_xsub_lhs", V+"THEOREM Alias == 3\nQ == [y |-> x]\n", AL+"CONSTANT Alias <- Q\n")
a("thm_cfg_asg", V+"THEOREM Alias == 3\n", AL+"CONSTANT Alias = 4\n")
a("thm_alias_num_view", V+"THEOREM Alias == 3\nVw == x\n", AL+"VIEW Vw\n")
write()
