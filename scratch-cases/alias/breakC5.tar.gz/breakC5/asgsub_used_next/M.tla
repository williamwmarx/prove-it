---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Alias == 1
Q == [y |-> x]
Init == x = 0
Next == x < 3 /\ x' = x + Alias
Inv == x < 2

====
