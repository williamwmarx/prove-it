exec(open("lib.py").read())
AL=INV+"ALIAS Alias\n"
a("decl_asgsub_used_crec", "CONSTANT Alias\nVARIABLE x\nQ == [y |-> 1]\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2 /\\ Alias = Alias\n", AL+"CONSTANT Alias = 1\nCONSTANT Alias <- Q\n")
a("decl_asgsub_unused_crec", "CONSTANT Alias\nVARIABLE x\nQ == [y |-> 1]\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n", AL+"CONSTANT Alias = 1\nCONSTANT Alias <- Q\n")
a("asgsub_used_ext", "VARIABLE x\nQ == [y |-> x]\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2 /\\ Alias = Alias\n", AL+"CONSTANT Alias = 1\nCONSTANT Alias <- Q\n", ext="Naturals, TLC, N", N="Alias == 1\n")
a("asgsub_used_str", "VARIABLE x\nAlias == \"a\"\nQ == [y |-> x]\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2 /\\ Alias = Alias\n", AL+"CONSTANT Alias = \"b\"\nCONSTANT Alias <- Q\n")
write()
