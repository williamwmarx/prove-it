---- MODULE M ----
EXTENDS Naturals, TLC
CONSTANT Alias
VARIABLE x
Q == [y |-> x]
Init == x = 0
Next == x < 3 /\ x' = x + Alias
Inv == x < 2

====
