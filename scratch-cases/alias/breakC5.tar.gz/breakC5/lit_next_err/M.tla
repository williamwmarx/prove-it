---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
Next == x' = x + 1 /\ (x < 2 \/ CHOOSE i \in {} : TRUE)
Alias == 3

====
