exec(open("lib.py").read())
AL=INV+"ALIAS Alias\n"
a("uinst_set", V+"INSTANCE N\n", AL, N="Alias == {1, 2}\n")
a("uinst_param_set", V+"INSTANCE N WITH c <- 1\n", AL, N="CONSTANT c\nAlias == {c, 2}\n")
a("luinst_set", V+"LOCAL INSTANCE N\n", AL, N="Alias == {1, 2}\n")
a("ext_ext_set", V, AL, ext="Naturals, TLC, N", N="EXTENDS P\n", P="Alias == {1, 2}\n")
a("uinst_ext_set", V+"INSTANCE N\n", AL, N="EXTENDS P\n", P="Alias == {1, 2}\n")
a("uinst_pc_set", C+"INSTANCE N\n", CC+"POSTCONDITION PC\n", N="PC == TRUE\n")
write()
