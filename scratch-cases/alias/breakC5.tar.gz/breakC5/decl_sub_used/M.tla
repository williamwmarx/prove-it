---- MODULE M ----
EXTENDS Naturals, TLC
CONSTANT Alias
VARIABLE x
Q == [y |-> x]
One == 1
Init == x = 0
Next == x < 3 /\ x' = x + Alias
Inv == x < 2

====
