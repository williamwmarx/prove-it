exec(open("lib.py").read())
AL=INV+"ALIAS Alias\n"
a("thm_sub_rhs", V+"THEOREM T == 3\nAlias == [z |-> x]\n", AL+"CONSTANT Alias <- T\n")
a("thm_sub_rhs_lit", V+"THEOREM T == 3\nAlias == 4\n", AL+"CONSTANT Alias <- T\n")
a("thm_x_sub", V+"THEOREM T == 3\nAlias == 4\nX == 1\n", AL+"CONSTANT X <- T\n")
a("thm_alias_xlevel", V+"THEOREM Alias == [y |-> x]\n", AL)
a("thm_alias_and_lit_q", V+"THEOREM Alias == 3\nQ == [y |-> x]\n", AL+"CONSTANT Q <- Alias\n")
a("thm_decl_sub", "CONSTANT K\n"+V+"THEOREM Alias == 3\n", AL+"CONSTANT K <- Alias\n")
write()
