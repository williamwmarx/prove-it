exec(open("lib.py").read())
AL=INV+"ALIAS Alias\n"
U="VARIABLE x\nAlias == 1\nQ == [y |-> x]\nInit == x = 0\nNext == x < 3 /\\ x' = x + Alias\nInv == x < 2\n"
a("asgsub_used_next", U, AL+"CONSTANT Alias = 1\nCONSTANT Alias <- Q\n")
a("subasg_used_next", U, AL+"CONSTANT Alias <- Q\nCONSTANT Alias = 1\n")
U2="VARIABLE x\nAlias == 1\nQ == [y |-> x]\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2 /\\ Alias = Alias\n"
a("asgsub_used_inv", U2, AL+"CONSTANT Alias = 1\nCONSTANT Alias <- Q\n")
U3="CONSTANT Alias\nVARIABLE x\nQ == [y |-> x]\nInit == x = 0\nNext == x < 3 /\\ x' = x + Alias\nInv == x < 2\n"
a("decl_asgsub_used", U3, AL+"CONSTANT Alias = 1\nCONSTANT Alias <- Q\n")
U4="CONSTANT Alias\nVARIABLE x\nQ == [y |-> x]\nOne == 1\nInit == x = 0\nNext == x < 3 /\\ x' = x + Alias\nInv == x < 2\n"
a("decl_sub_used", U4, AL+"CONSTANT Alias <- One\n")
write()
