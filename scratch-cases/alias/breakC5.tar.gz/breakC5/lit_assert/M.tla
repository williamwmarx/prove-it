---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
Next == Assert(x < 2, "boom") /\ x' = x + 1
Alias == 3

====
