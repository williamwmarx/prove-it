---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Alias == 3
Q == 4
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < 2 /\ Alias = Alias

====
