---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Alias == 1
Q == [y |-> x]
Init == x = 0 /\ Alias = Alias
Next == x < 3 /\ x' = x + 1
Inv == x < 2

====
