---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Alias == 1
Q == 5
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < 2 /\ Alias = Alias

====
