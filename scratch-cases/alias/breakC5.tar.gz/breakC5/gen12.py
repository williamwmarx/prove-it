exec(open("lib.py").read())
AL=INV+"ALIAS Alias\n"
a("modasg_used", "VARIABLE x\nAlias == [z |-> x]\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2 /\\ Alias = Alias\n", AL+"CONSTANT Alias = [M] 1\n")
a("modasg_used_lit", "VARIABLE x\nAlias == 3\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2 /\\ Alias = Alias\n", AL+"CONSTANT Alias = [M] 1\n")
a("modasg_used_ext", "VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2 /\\ Alias = Alias\n", AL+"CONSTANT Alias = [N] 1\n", ext="Naturals, TLC, N", N="VARIABLE y\nAlias == 3\n")
a("modsub_used_lit", "VARIABLE x\nAlias == 3\nQ == 4\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2 /\\ Alias = Alias\n", AL+"CONSTANT Alias <- [M] Q\n")
write()
