---- MODULE N ----
THEOREM Alias == 3
====
