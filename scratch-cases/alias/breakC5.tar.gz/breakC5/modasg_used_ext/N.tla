---- MODULE N ----
VARIABLE y
Alias == 3
====
