exec(open("lib.py").read())
AL=INV+"ALIAS Alias\n"
a("modasg_inst_other", V+"I == INSTANCE N\nAlias == [z |-> x]\n", AL+"CONSTANT Alias = [N] 3\n", N="Alias == 7\nUse == Alias\n")
a("modasg_inst_other_lit", V+"I == INSTANCE N\nAlias == 5\n", AL+"CONSTANT Alias = [N] 3\n", N="Alias == 7\n")
a("modsub_inst_other", V+"I == INSTANCE N\nQ == 4\nAlias == [z |-> x]\n", AL+"CONSTANT Alias <- [N] Q\n", N="Alias == 7\n")
a("inst_const_named_alias_asg", V+"I == INSTANCE N WITH Alias <- 1\nAlias == [z |-> x]\n", AL, N="CONSTANT Alias\nU == Alias\n")
a("asg_sim", V+"Alias == [z |-> x]\n", AL+"CONSTANT Alias = 3\n")
write()
