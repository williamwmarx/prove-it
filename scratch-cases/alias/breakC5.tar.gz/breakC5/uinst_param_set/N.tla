---- MODULE N ----
CONSTANT c
Alias == {c, 2}
====
