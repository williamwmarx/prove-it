exec(open("lib.py").read())
AL=INV+"ALIAS Alias\n"
a("axiom_alias", V+"AXIOM Alias == 3\n", AL)
a("assume_lit_alias", V+"ASSUME Alias == 3\n", AL)
a("prop_alias", V+"PROPOSITION Alias == \"p\"\n", AL)
a("thm_proof_alias", V+"THEOREM Alias == 3\nOBVIOUS\n", AL)
a("thm_pc_lit_and_ok", C+"THEOREM PC1 == 3\nPC2 == x \\in Nat\n", CC+"POSTCONDITION PC1\n")
write()
