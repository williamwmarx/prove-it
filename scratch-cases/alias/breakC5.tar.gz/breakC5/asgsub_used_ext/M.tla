---- MODULE M ----
EXTENDS Naturals, TLC, N
VARIABLE x
Q == [y |-> x]
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < 2 /\ Alias = Alias

====
