---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Alias == 1
Q == [y |-> x]
Init == x = 0
Next == x < 2 /\ Alias = Alias /\ x' = x + 1

====
