---- MODULE N ----
CONSTANT c
THEOREM Alias == 3
====
