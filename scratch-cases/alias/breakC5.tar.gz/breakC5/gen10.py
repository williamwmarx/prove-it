exec(open("lib.py").read())
AL=INV+"ALIAS Alias\n"
B="VARIABLE x\nAlias == 1\nQ == [y |-> x]\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\n"
a("subasg_used_inv", B+"Inv == x < 2 /\\ Alias = Alias\n", AL+"CONSTANT Alias <- Q\nCONSTANT Alias = 1\n")
a("asgsub_used_unreached", B+"Inv == x < 2\nUnused == Alias\n", AL+"CONSTANT Alias = 1\nCONSTANT Alias <- Q\n")
a("asgsub_used_assume", B+"Inv == x < 2\nASSUME Alias = Alias\n", AL+"CONSTANT Alias = 1\nCONSTANT Alias <- Q\n")
a("asgsub_used_init", "VARIABLE x\nAlias == 1\nQ == [y |-> x]\nInit == x = 0 /\\ Alias = Alias\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n", AL+"CONSTANT Alias = 1\nCONSTANT Alias <- Q\n")
a("asgsub_used_inv_qlit", "VARIABLE x\nAlias == 1\nQ == 5\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2 /\\ Alias = Alias\n", AL+"CONSTANT Alias = 1\nCONSTANT Alias <- Q\n")
a("asgsub_used_deadlock", "VARIABLE x\nAlias == 1\nQ == [y |-> x]\nInit == x = 0\nNext == x < 2 /\\ Alias = Alias /\\ x' = x + 1\n", CC+"ALIAS Alias\nCONSTANT Alias = 1\nCONSTANT Alias <- Q\n")
write()
