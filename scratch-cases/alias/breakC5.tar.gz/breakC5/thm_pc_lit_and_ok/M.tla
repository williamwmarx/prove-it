---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 3
THEOREM PC1 == 3
PC2 == x \in Nat

====
