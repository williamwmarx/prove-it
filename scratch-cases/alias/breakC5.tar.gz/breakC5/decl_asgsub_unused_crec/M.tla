---- MODULE M ----
EXTENDS Naturals, TLC
CONSTANT Alias
VARIABLE x
Q == [y |-> 1]
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < 2

====
