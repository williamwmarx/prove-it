exec(open("lib.py").read())
AL=INV+"ALIAS Alias\n"
a("lit_modasg", V+"Alias == 3\n", AL+"CONSTANT Alias = [M] 4\n")
a("strlit_modasg", V+"Alias == \"a\"\n", AL+"CONSTANT Alias = [M] 4\n")
a("lit_modasg_ext", V, AL+"CONSTANT Alias = [N] 4\n", ext="Naturals, TLC, N", N="Alias == 3\n")
a("pc_lit_modasg", C+"PC == 3\n", CC+"POSTCONDITION PC\nCONSTANT PC = [M] TRUE\n")
a("pc_str_sim", C+"PC == \"a\"\n", CC+"POSTCONDITION PC\n")
a("pc_lit_and_good", C+"PC1 == x \\in Nat\nPC2 == 3\n", CC+"POSTCONDITION PC2\nPOSTCONDITION PC1\n")
write()
