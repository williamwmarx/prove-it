---- MODULE M ----
EXTENDS Naturals, TLC, FiniteSets
VARIABLE x
Init == x = {"a", "m"}
Next == x' = x \cup {"b"}
Inv == Cardinality(x) < 3
Alias == [z |-> x]

====
