---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Alias == [z |-> x]
Init == x = Alias
Next == x < 5 /\ x' = x + 1
Inv == x < 5

====
