---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < 2
Q == 3
Alias == [z |-> x]
Inv2 == Q = 3

====
