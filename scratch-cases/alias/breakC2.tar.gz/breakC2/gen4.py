import os, sys
V="VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n"
INV="INIT Init\nNEXT Next\nINVARIANT Inv\n"
cases={}
def a(n, body, cfg, ext="Naturals, TLC", pre=""):
    cases[n]=("---- MODULE M ----\n"+pre+"EXTENDS "+ext+"\n"+body+"\n====\n", cfg)
a("inst_c_sub3", V+"I == INSTANCE N WITH c <- 3\nAlias == I!K\n", INV+"ALIAS Alias\n", pre="---- MODULE N ----\nCONSTANT c\nK == c\n====\n")
a("asg_str_order", "VARIABLE x\nInit == x = {\"a\", \"zz\", \"m\"}\nNext == x' = x\nInv == FALSE\nAlias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANT Alias = "zz"\n')
a("asg_str_order2", "VARIABLE x\nInit == x = {\"a\", \"m\"}\nNext == x' = x \\cup {\"b\"}\nInv == Cardinality(x) < 3\nAlias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANT Alias = "b"\n', ext="Naturals, TLC, FiniteSets")
a("asg_mv_order", "CONSTANT A\nVARIABLE x\nInit == x = {A, Alias}\nNext == x' = x\nInv == FALSE\nAlias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANTS Alias = zb\nA = za\n')
a("asg_mv_order2", "CONSTANT A\nVARIABLE x\nInit == x = {A, Alias}\nNext == x' = x\nInv == FALSE\nAlias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANTS A = za\nAlias = zb\n')
a("asg_mvset_used", "VARIABLE x\nInit == x \\in Alias\nNext == x' = x\nInv == FALSE\nAlias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANT Alias = {m2, m1}\n')
a("asg_str_used_view", "VARIABLE x, y\nInit == x = 0 /\\ y = Alias\nNext == x < 3 /\\ x' = x + 1 /\\ y' = y\nInv == x < 2\nVw == x\nAlias == [z |-> x]\n", INV+'VIEW Vw\nALIAS Alias\nCONSTANT Alias = "q"\n')
a("asg_print_assume", V+"Alias == [z |-> x]\nASSUME PrintT(Alias)\n", INV+'ALIAS Alias\nCONSTANT Alias = {"x", "a"}\n')
a("xsub_tool_cfg2", V+"X == 0\nAlias == 3\n", INV+"ALIAS Alias\nCONSTANTS X <- Alias\n")
a("xsub_postcond_alias", V+"X == 0\nAlias == TRUE\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n")
a("xsub_def_before", V+"Alias == 3\nX == Alias + 1\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n")
a("pc_xsub_lit_viol", V+"X == 0\nPC == \"a\"\n", INV+"POSTCONDITION PC\nCONSTANT X <- PC\n")
a("alias_sub_q_xsub", V+"Q == 3\nX == 0\nAlias == [z |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias <- Q\nX <- Q\n")
a("alias_sub_q_xsub_rec", V+"Q == [y |-> 1]\nX == 0\nAlias == [z |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias <- Q\nX <- Q\n")
for n,(t,c) in cases.items():
    if len(sys.argv)>1 and n not in sys.argv[1:]: continue
    os.makedirs(n, exist_ok=True)
    open(n+"/M.tla","w").write(t); open(n+"/M.cfg","w").write(c)
print(" ".join(cases))
