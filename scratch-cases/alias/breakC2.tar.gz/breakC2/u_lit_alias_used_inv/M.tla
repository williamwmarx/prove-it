---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Alias == 2
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < Alias

====
