---- MODULE N ----
VARIABLE x
Alias == [a |-> x]
====
