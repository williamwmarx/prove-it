#!/bin/bash
# case.sh NATIVE TLAFILE CFGFILE : compares TLC and native at 1/4 workers, plain and -tool
B=/home/user/ext/tlcbuild; N=$1; T=$2; C=$3
D=$(mktemp -d); cp $(dirname $T)/*.tla $D/; cp $C $D/M.cfg; cd $D
F='^Finished\|^Starting\|^Running\|^TLC2\|pid\|tmp\|^Parsing\|^Semantic\|^Linting\|^Computing\|JAVA_TOOL\|Progress\|STARTMSG 2185\|STARTMSG 2186\|STARTMSG 2187\|STARTMSG 2262\|STARTMSG 2220\|STARTMSG 2189\|STARTMSG 2190\|STARTMSG 2201\|STARTMSG 2202\|STARTMSG 2268'
out=""
for w in 1 4; do for t in "" "-tool"; do
$B/tlc -workers $w $t -nowarning -fp 0 -lncheck final -noGenerateSpecTE -config M.cfg M.tla > t.raw 2>&1; te=$?
timeout 60 $1 -workers $w $t -nowarning -fp 0 -lncheck final -noGenerateSpecTE -config M.cfg M.tla > n.raw 2>&1; ne=$?
if grep -q "not native" n.raw; then out="$out w$w$t:DECLINE"; reason="$(grep 'not native' n.raw | cut -c22-220)";
elif diff -q <(grep -v "$F" t.raw) <(grep -v "$F" n.raw) >/dev/null && [ $te = $ne ]; then out="$out w$w$t:SAME";
else out="$out w$w$t:DIFF($te/$ne)"; dif="$(diff <(grep -v "$F" t.raw) <(grep -v "$F" n.raw) | head -8)"; fi
done; done
echo "$out"; [ -n "$reason" ] && echo "   $reason"; [ -n "$dif" ] && echo "$dif" | sed 's/^/   /'
cd /; rm -rf $D
