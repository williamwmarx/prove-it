#!/bin/bash
# tlcok.sh case...: does TLC reach model checking?
S=/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad/breakC2
for n in "$@"; do D=$(mktemp -d); cp $S/$n/*.tla $S/$n/M.cfg $D; cd $D; /home/user/ext/tlcbuild/tlc -workers 1 -nowarning -noGenerateSpecTE -config M.cfg M.tla > t 2>&1; if grep -q "Computing initial states" t; then echo "$n: ok"; else echo "$n: NO: $(grep -i -m2 'error\|fail' t | tr '\n' ' ' | cut -c1-150)"; fi; cd /; rm -rf $D; done
