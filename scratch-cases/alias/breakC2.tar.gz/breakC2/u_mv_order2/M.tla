---- MODULE M ----
EXTENDS Naturals, TLC
CONSTANT A
VARIABLE x
Alias == [z |-> x]
Init == x = {Alias, A}
Next == x' = x
Inv == FALSE

====
