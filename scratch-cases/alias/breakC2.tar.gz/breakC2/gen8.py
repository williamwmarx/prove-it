import os, sys
V="VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n"
INV="INIT Init\nNEXT Next\nINVARIANT Inv\n"
cases={}
def a(n, body, cfg, ext="Naturals, TLC", N=None):
    cases[n]=("---- MODULE M ----\nEXTENDS "+ext+"\n"+body+"\n====\n", cfg, N)
def mod(b): return "---- MODULE N ----\n"+b+"====\n"
a("n_uinst_param_str", V+"INSTANCE N WITH c <- \"a\"\n", INV+"ALIAS Alias\n", N=mod("CONSTANT c\nAlias == c\n"))
a("n_uinst_param_c_deadlock", "VARIABLE x\nInit == x = 0\nNext == x < 2 /\\ x' = x + 1\nINSTANCE N WITH c <- 3\n", "INIT Init\nNEXT Next\nALIAS Alias\n", N=mod("CONSTANT c\nAlias == c\n"))
a("n_uinst_two_params", V+"INSTANCE N WITH c <- 3, d <- 4\n", INV+"ALIAS Alias\n", N=mod("CONSTANT c, d\nAlias == d\n"))
a("n_uinst_local", V+"LOCAL INSTANCE N WITH c <- 3\n", INV+"ALIAS Alias\n", N=mod("CONSTANT c\nAlias == c\n"))
a("n_uinst_param_c_alias_rec", V+"INSTANCE N WITH c <- 3\n", INV+"ALIAS Alias\n", N=mod("CONSTANT c\nAlias == [a |-> c]\n"))
a("n_uinst_var_param", V+"INSTANCE N WITH c <- 3, v <- x\n", INV+"ALIAS Alias\n", N=mod("CONSTANT c\nVARIABLE v\nAlias == c\n"))
a("n_uinst_def_sub", V+"K == 3\nINSTANCE N WITH c <- K\n", INV+"ALIAS Alias\n", N=mod("CONSTANT c\nAlias == c\n"))
a("n_uinst_implicit", V+"c == 3\nINSTANCE N\n", INV+"ALIAS Alias\n", N=mod("CONSTANT c\nAlias == c\n"))
for n,(t,c,N) in cases.items():
    if len(sys.argv)>1 and n not in sys.argv[1:]: continue
    os.makedirs(n, exist_ok=True)
    open(n+"/M.tla","w").write(t); open(n+"/M.cfg","w").write(c)
    if N: open(n+"/N.tla","w").write(N)
print(" ".join(cases))
