---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 3
---- MODULE N ----
CONSTANT c
PC == c
====
INSTANCE N WITH c <- 3
====
