---- MODULE M ----
EXTENDS Naturals, TLC
CONSTANT A
VARIABLE x
Init == x = {A, Alias}
Next == x' = x
Inv == FALSE
Alias == [z |-> x]

====
