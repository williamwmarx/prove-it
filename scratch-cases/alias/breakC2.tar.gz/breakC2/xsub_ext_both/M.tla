---- MODULE M ----
---- MODULE N ----
X == 0
Alias == 3
====
EXTENDS Naturals, TLC, N
VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < 2

====
