---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Alias == "s"
X == 0
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < 2

====
