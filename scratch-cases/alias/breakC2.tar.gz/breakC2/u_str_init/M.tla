---- MODULE M ----
EXTENDS Naturals, TLC, Sequences
VARIABLE x
Alias == [z |-> x]
Init == x = Alias
Next == x' = x \o "b"
Inv == x /= "abb"

====
