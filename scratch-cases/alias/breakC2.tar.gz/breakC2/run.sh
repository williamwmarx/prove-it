#!/bin/bash
S=/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad
cd $S/breakC2
for n in "$@"; do echo "== $n"; bash $S/breakC2/case3N.sh $S/breakC2/$n/M.tla $S/breakC2/$n/M.cfg; done
