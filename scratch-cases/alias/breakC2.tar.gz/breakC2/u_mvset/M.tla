---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Alias == [z |-> x]
Init == x \in Alias
Next == x' = x
Inv == FALSE

====
