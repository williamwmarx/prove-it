---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Alias == [z |-> x]
Init == x = 0
Next == x < 3 /\ x' = (IF x = 2 THEN CHOOSE y \in {} : TRUE ELSE x + 1)

====
