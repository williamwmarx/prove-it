import os, sys
V="VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n"
INV="INIT Init\nNEXT Next\nINVARIANT Inv\n"
cases={}
def a(n, body, cfg, ext="Naturals, TLC", pre=""):
    cases[n]=("---- MODULE M ----\n"+pre+"EXTENDS "+ext+"\n"+body+"\n====\n", cfg)
# literal-rule shapes
a("lbl_num", V+"Alias == lab :: 3\n", INV+"ALIAS Alias\n")
a("lbl_str", V+'Alias == lab :: "a"\n', INV+"ALIAS Alias\n")
a("pc_lbl_num", V+"PC == lab :: 3\n", "INIT Init\nNEXT Next\nPOSTCONDITION PC\n")
a("pc_lbl_true", V+"PC == lab :: TRUE\n", "INIT Init\nNEXT Next\nPOSTCONDITION PC\n")
a("const_ref", "CONSTANT c\n"+V+"Alias == c\n", INV+"ALIAS Alias\nCONSTANT c = 3\n")
a("const_ref_str", "CONSTANT c\n"+V+"Alias == c\n", INV+'ALIAS Alias\nCONSTANT c = "a"\n')
a("inst_param_lit", V+"I == INSTANCE N WITH c <- 1\nAlias == I!K\n", INV+"ALIAS Alias\n",
  pre="---- MODULE N ----\nCONSTANT c\nK == 3\n====\n")
a("uinst_param_lit", V+"INSTANCE N WITH c <- 1\n", INV+"ALIAS Alias\n",
  pre="---- MODULE N ----\nCONSTANT c\nAlias == 3\n====\n")
a("uinst_param_c", V+"INSTANCE N WITH c <- 3\n", INV+"ALIAS Alias\n",
  pre="---- MODULE N ----\nCONSTANT c\nAlias == c\n====\n")
a("uinst_noparam_lit", V+"INSTANCE N\n", INV+"ALIAS Alias\n",
  pre="---- MODULE N ----\nAlias == 3\n====\n")
a("ext_lit", V, INV+"ALIAS Alias\n", ext="Naturals, TLC, N",
  pre="---- MODULE N ----\nAlias == \"a\"\n====\n")
a("pc_uinst_param_c", V+"INSTANCE N WITH c <- 3\n", "INIT Init\nNEXT Next\nPOSTCONDITION PC\n",
  pre="---- MODULE N ----\nCONSTANT c\nPC == c\n====\n")
a("pc_uinst_param_true", V+"INSTANCE N WITH c <- TRUE\n", "INIT Init\nNEXT Next\nPOSTCONDITION PC\n",
  pre="---- MODULE N ----\nCONSTANT c\nPC == c\n====\n")
# substitution with builtins
a("sub_nat", V+"Alias == [z |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias <- Nat\n")
a("sub_javatime", V+"Alias == [z |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias <- JavaTime\n")
a("sub_int", V+"Alias == [z |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias <- Int\n", ext="Integers, TLC")
a("alias_nat", V, INV+"ALIAS Nat\n")
a("alias_javatime", V, INV+"ALIAS JavaTime\n")
a("sub_emptybag", V+"Alias == [z |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias <- EmptyBag\n", ext="Naturals, TLC, Bags")
a("sub_lit_q_used", V+"Q == 3\nAlias == [z |-> x]\nInv2 == Q = 3\n", INV+"INVARIANT Inv2\nALIAS Alias\nCONSTANT Alias <- Q\n")
a("sub_q_rec_const", V+"Q == [y |-> 1]\nAlias == [z |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias <- Q\n")
a("sub_q_str", V+"Q == \"s\"\nAlias == [z |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias <- Q\n")
# assignment shapes
a("asg_str", V+"Alias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANT Alias = "a"\n')
a("asg_mv", V+"Alias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANT Alias = mv\n')
a("asg_mvset", V+"Alias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANT Alias = {m1, m2}\n')
a("asg_empty", V+"Alias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANT Alias = {}\n')
a("asg_tuple", V+"Alias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANT Alias = <<1, 2>>\n')
a("asg_used_init", V.replace("Init == x = 0","Init == x = 0 /\\ Alias = Alias")+"Alias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANT Alias = 3\n')
a("asg_used_inv", V.replace("Inv == x < 2","Inv == x < Alias")+"Alias == 2\n", INV+'ALIAS Alias\nCONSTANT Alias = 2\n')
a("asg_used_assume", V+"Alias == [z |-> x]\nASSUME Alias = 3\n", INV+'ALIAS Alias\nCONSTANT Alias = 3\n')
a("asg_cfgget", V+"Alias == [z |-> x]\nASSUME PrintT(TLCGet(\"config\").install)\n", INV+'ALIAS Alias\nCONSTANT Alias = 3\n')
a("asg_view_too", V+"Alias == [z |-> x]\n", INV+'ALIAS Alias\nVIEW Alias\nCONSTANT Alias = 3\n')
a("asg_deadlock", "VARIABLE x\nInit == x = 0\nNext == x < 2 /\\ x' = x + 1\nAlias == [z |-> x]\n", "INIT Init\nNEXT Next\nALIAS Alias\nCONSTANT Alias = 3\n")
a("asg_len1", "VARIABLE x\nInit == x = 0\nNext == x' = x\nInv == x > 0\nAlias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANT Alias = 3\n')
a("asg_noviol", V.replace("Inv == x < 2","Inv == x < 9")+"Alias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANT Alias = 3\n')
a("asg_decl_noviol", "CONSTANT Alias\n"+V.replace("Inv == x < 2","Inv == x < 9"), INV+'ALIAS Alias\nCONSTANT Alias = 3\n')
a("asg_decl", "CONSTANT Alias\n"+V, INV+'ALIAS Alias\nCONSTANT Alias = 3\n')
a("asg_decl_used", "CONSTANT Alias\n"+V.replace("Inv == x < 2","Inv == x < Alias"), INV+'ALIAS Alias\nCONSTANT Alias = 2\n')
a("asg_twice", V+"Alias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANT Alias = 3\nCONSTANT Alias = 4\n')
a("asg_sub_same_line", V+"Q == [y |-> x]\nAlias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANTS Alias = 3 Alias <- Q\n')
a("asg_sub_rev", V+"Q == [y |-> x]\nAlias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANTS Alias <- Q\nAlias = 3\n')
a("asg_modsub", V+"Q == [y |-> x]\nAlias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANT Alias = 3\nCONSTANT Alias <- [M] Q\n')
a("asg_inner_decl", V+"I == INSTANCE N WITH Alias <- 1\nAlias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANT Alias = 3\n',
  pre="---- MODULE N ----\nCONSTANT Alias\nK == Alias\n====\n")
a("asg_inner_decl_noroot", V+"I == INSTANCE N WITH Alias <- 1\n", INV+'ALIAS Alias\nCONSTANT Alias = 3\n',
  pre="---- MODULE N ----\nCONSTANT Alias\nK == Alias\n====\n")
a("asg_ext_def", V, INV+'ALIAS Alias\nCONSTANT Alias = 3\n', ext="Naturals, TLC, N",
  pre="---- MODULE N ----\nVARIABLE y\nAlias == 1\n====\n")
a("asg_op_args", V+"Alias(p) == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANT Alias = 3\n')
a("asg_view_lit", V+"Vw == 3\n", INV+'VIEW Vw\n')
a("asg_func", V+"Alias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANT Alias = [a |-> 1]\n')
a("asg_neg", V+"Alias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANT Alias = -3\n')
a("asg_bool", V+"Alias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANT Alias = TRUE\n')
a("asg_mvset_tool", V+"Alias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANT Alias = {}\nCONSTANT mvv = mvv\n')
for n,(t,c) in cases.items():
    if len(sys.argv)>1 and n not in sys.argv[1:]: continue
    os.makedirs(n, exist_ok=True)
    open(n+"/M.tla","w").write(t); open(n+"/M.cfg","w").write(c)
print(" ".join(cases))
