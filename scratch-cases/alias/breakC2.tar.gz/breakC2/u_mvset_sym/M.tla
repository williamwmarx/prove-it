---- MODULE M ----
EXTENDS Naturals, TLC
CONSTANT S
VARIABLE x
Alias == [z |-> x]
Sym == Permutations(Alias)
Init == x \in Alias
Next == x' = x
Inv == FALSE

====
