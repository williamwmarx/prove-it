---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = {"a", "zz", "m"}
Next == x' = x
Inv == FALSE
Alias == [z |-> x]

====
