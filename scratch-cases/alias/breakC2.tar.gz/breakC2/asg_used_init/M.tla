---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0 /\ Alias = Alias
Next == x < 3 /\ x' = x + 1
Inv == x < 2
Alias == [z |-> x]

====
