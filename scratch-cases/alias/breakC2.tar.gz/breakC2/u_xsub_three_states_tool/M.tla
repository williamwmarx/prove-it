---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x, y
Alias == 7
X == 0
Init == x = 0 /\ y = 0
Next == x < 3 /\ x' = x + 1 /\ y' = 1 - y
Inv == x < 3

====
