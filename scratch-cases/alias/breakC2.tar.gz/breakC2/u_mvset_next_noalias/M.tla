---- MODULE M ----
EXTENDS Naturals, TLC
CONSTANT S
VARIABLE x
Init == x = {}
Next == \E m \in S : m \notin x /\ x' = x \cup {m}
Inv == x # S
====
