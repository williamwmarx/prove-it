---- MODULE M ----
---- MODULE N ----
VARIABLE y
Alias == 1
====
EXTENDS Naturals, TLC, N
VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < 2

====
