#!/bin/bash
# case3.sh TLA CFG : main binary vs branch binary, each against TLC
S=/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad
m=$(bash $S/breakC2/caseTN.sh /home/user/ext/wt-main6/packages/prove-it/native/target/release/prove-it $1 $2 | tr '\n' ' ' | cut -c1-90)
b=$(bash $S/breakC2/caseTN.sh /home/user/ext/wt-const/packages/prove-it/native/target/release/prove-it $1 $2 | tr '\n' ' ' | cut -c1-90)
echo "  main:  $m"; echo "  branch:$b"
