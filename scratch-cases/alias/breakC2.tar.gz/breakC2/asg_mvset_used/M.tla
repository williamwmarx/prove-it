---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x \in Alias
Next == x' = x
Inv == FALSE
Alias == [z |-> x]

====
