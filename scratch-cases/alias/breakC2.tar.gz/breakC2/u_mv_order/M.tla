---- MODULE M ----
EXTENDS Naturals, TLC
CONSTANT A
VARIABLE x
Alias == [z |-> x]
Init == x = {A, Alias}
Next == x' = x
Inv == FALSE

====
