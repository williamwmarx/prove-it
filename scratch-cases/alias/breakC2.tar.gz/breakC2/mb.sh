#!/bin/bash
# mb.sh case [extra args]: diff main vs branch output (w1)
S=/tmp/claude-0/-home-user-prove-it/79a75f30-0c9a-5012-89ea-6f563f23ecf9/scratchpad/breakC2
n=$1; shift
D=$(mktemp -d); cp $S/$n/M.tla $S/$n/M.cfg $D; cd $D
for b in wt-main6 wt-const; do /home/user/ext/$b/packages/prove-it/native/target/release/prove-it -workers 1 -nowarning -fp 0 -lncheck final -noGenerateSpecTE "$@" -config M.cfg M.tla 2>&1 | grep -v "pid:\|^Starting\|^Finished" > $b.out; echo "exit $?" >> $b.out; done
if diff -q wt-main6.out wt-const.out >/dev/null; then echo "$n: main==branch"; else echo "$n: main!=branch"; diff wt-main6.out wt-const.out | head -20; fi
cd /; rm -rf $D
