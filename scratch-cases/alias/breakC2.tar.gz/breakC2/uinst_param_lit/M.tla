---- MODULE M ----
---- MODULE N ----
CONSTANT c
Alias == 3
====
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < 2
INSTANCE N WITH c <- 1

====
