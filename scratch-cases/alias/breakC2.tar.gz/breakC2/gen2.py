import os, sys
V="VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n"
INV="INIT Init\nNEXT Next\nINVARIANT Inv\n"
PCC="INIT Init\nNEXT Next\nPOSTCONDITION PC\n"
cases={}
def a(n, body, cfg, ext="Naturals, TLC", pre=""):
    cases[n]=("---- MODULE M ----\n"+pre+"EXTENDS "+ext+"\n"+body+"\n====\n", cfg)
a("xsub_num", V+"X == 0\nAlias == 3\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n")
a("xsub_str", V+"Alias == \"a\"\nX == 0\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n")
a("xsub_num_statex", V+"X == x\nAlias == 3\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n")
a("xsub_num_deadlock", "VARIABLE x\nInit == x = 0\nNext == x < 2 /\\ x' = x + 1\nX == 0\nAlias == 3\n", "INIT Init\nNEXT Next\nALIAS Alias\nCONSTANT X <- Alias\n")
a("xmodsub_num", V+"X == 0\nAlias == 3\n", INV+"ALIAS Alias\nCONSTANT X <- [M] Alias\n")
a("xsub_pc_num", V+"X == 0\nPC == 3\n", PCC+"CONSTANT X <- PC\n")
a("xsub_pc_str", V+"X == 0\nPC == \"a\"\n", PCC+"CONSTANT X <- PC\n")
a("xsub_decl_num", "CONSTANT K\n"+V+"Alias == 3\n", INV+"ALIAS Alias\nCONSTANT K <- Alias\n")
a("xsub_ext", V+"Alias == 3\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n", ext="Naturals, TLC, N", pre="---- MODULE N ----\nX == 0\n====\n")
a("xsub_inner_modsub", V+"I == INSTANCE N\nAlias == 3\n", INV+"ALIAS Alias\nCONSTANT X <- [N] Alias\n", pre="---- MODULE N ----\nX == 0\n====\n")
a("modsub_q_constrec", V+"Q == [y |-> 1]\nAlias == [z |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias <- [M] Q\n")
a("modsub_q_lit", V+"Q == 3\nAlias == [z |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias <- [M] Q\n")
a("modsub_q_str", V+"Q == \"s\"\nAlias == [z |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias <- [M] Q\n")
a("ext_alias_const", V, INV+"ALIAS Alias\n", ext="Naturals, TLC, N", pre="---- MODULE N ----\nAlias == [a |-> 1]\n====\n")
a("uinst_alias_const", V+"INSTANCE N\n", INV+"ALIAS Alias\n", pre="---- MODULE N ----\nAlias == [a |-> 1]\n====\n")
a("uinst_param_alias_const", V+"INSTANCE N WITH c <- 1\n", INV+"ALIAS Alias\n", pre="---- MODULE N ----\nCONSTANT c\nAlias == [a |-> c]\n====\n")
a("ext_alias_sub_q", V+"Q == [y |-> 1]\n", INV+"ALIAS Alias\nCONSTANT Alias <- Q\n", ext="Naturals, TLC, N", pre="---- MODULE N ----\nAlias == [a |-> 1]\n====\n")
a("ext_q_sub", V+"Alias == [z |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias <- Q\n", ext="Naturals, TLC, N", pre="---- MODULE N ----\nQ == [a |-> 1]\n====\n")
a("modasg_ext", V, INV+"ALIAS Alias\nCONSTANT Alias = [N] 3\n", ext="Naturals, TLC, N", pre="---- MODULE N ----\nAlias == [a |-> 1]\n====\n")
a("sub_self_const", V+"Alias == [a |-> 1]\n", INV+"ALIAS Alias\nCONSTANT Alias <- Alias\n")
a("sub_self_num_asg", V+"Alias == [a |-> 1]\n", INV+"ALIAS Alias\nCONSTANT Alias <- Alias\nCONSTANT Alias = 3\n")
a("asg_alias_and_x", V+"Alias == [z |-> x]\nX == 0\n", INV+"ALIAS Alias\nCONSTANT Alias = 3\nCONSTANT X <- Alias\n")
a("asg_set_interval", V+"Alias == [z |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias = {1, 2, 3}\n")
a("asg_nested_set", V+"Alias == [z |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias = {{1}, {}}\n")
a("asg_big", V+"Alias == [z |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias = 2147483647\n")
a("asg_str_used_init", V.replace("Init == x = 0","Init == x = 0 /\\ Alias = \"a\"")+"Alias == [z |-> x]\n", INV+'ALIAS Alias\nCONSTANT Alias = "a"\n')
a("asg_mv_sym", V+"Alias == [z |-> x]\nS == Permutations({m1, m2})\n", INV+'ALIAS Alias\nSYMMETRY S\nCONSTANT Alias = m1\nCONSTANT m1 = m1 m2 = m2\n')
a("asg_live", "VARIABLE x\nInit == x = 0\nNext == x' = 1 - x\nSpec == Init /\\ [][Next]_x\nP == <>(x = 2)\nAlias == [z |-> x]\n", "SPECIFICATION Spec\nPROPERTY P\nALIAS Alias\nCONSTANT Alias = 3\n")
a("asg_action_prop", "VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nSpec == Init /\\ [][Next]_x\nP == [][x' = x + 2]_x\nAlias == [z |-> x]\n", "SPECIFICATION Spec\nPROPERTY P\nALIAS Alias\nCONSTANT Alias = 3\n")
a("asg_runtime_err", "VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1 /\\ (x = 2 => 1 \\in {\"a\"} = TRUE) \nAlias == [z |-> x]\n", "INIT Init\nNEXT Next\nALIAS Alias\nCONSTANT Alias = 3\n")
a("asg_runtime_err2", "VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = (IF x = 2 THEN CHOOSE y \\in {} : TRUE ELSE x + 1)\nAlias == [z |-> x]\n", "INIT Init\nNEXT Next\nALIAS Alias\nCONSTANT Alias = 3\n")
a("lit_runtime_err", "VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = (IF x = 2 THEN CHOOSE y \\in {} : TRUE ELSE x + 1)\nAlias == 3\n", "INIT Init\nNEXT Next\nALIAS Alias\n")
for n,(t,c) in cases.items():
    if len(sys.argv)>1 and n not in sys.argv[1:]: continue
    os.makedirs(n, exist_ok=True)
    open(n+"/M.tla","w").write(t); open(n+"/M.cfg","w").write(c)
print(" ".join(cases))
