---- MODULE N ----
CONSTANT c
Alias == [a |-> c]
====
