---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1 /\ (x = 2 => 1 \in {"a"} = TRUE) 
Alias == [z |-> x]

====
