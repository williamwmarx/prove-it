import os, sys
INV="INIT Init\nNEXT Next\nINVARIANT Inv\n"
cases={}
def a(n, body, cfg, ext="Naturals, TLC"):
    cases[n]=("---- MODULE M ----\nEXTENDS "+ext+"\n"+body+"\n====\n", cfg)
H="VARIABLE x\nAlias == [z |-> x]\n"
a("u_init", H+"Init == x = Alias\nNext == x < 5 /\\ x' = x + 1\nInv == x < 5\n", INV+"ALIAS Alias\nCONSTANT Alias = 3\n")
a("u_inv", H+"Init == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < Alias\n", INV+"ALIAS Alias\nCONSTANT Alias = 2\n")
a("u_assume", H+"Init == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\nASSUME Alias = 3\n", INV+"ALIAS Alias\nCONSTANT Alias = 3\n")
a("u_assume_print", H+"Init == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\nASSUME PrintT(Alias)\n", INV+"ALIAS Alias\nCONSTANT Alias = {\"b\", \"a\"}\n")
a("u_str_init", H+"Init == x = Alias\nNext == x' = x \\o \"b\"\nInv == x /= \"abb\"\n", INV+"ALIAS Alias\nCONSTANT Alias = \"a\"\n", ext="Naturals, TLC, Sequences")
a("u_mv_order", "CONSTANT A\nVARIABLE x\nAlias == [z |-> x]\nInit == x = {A, Alias}\nNext == x' = x\nInv == FALSE\n", INV+'ALIAS Alias\nCONSTANTS Alias = zb\nA = za\n')
a("u_mv_order2", "CONSTANT A\nVARIABLE x\nAlias == [z |-> x]\nInit == x = {Alias, A}\nNext == x' = x\nInv == FALSE\n", INV+'ALIAS Alias\nCONSTANTS A = za\nAlias = zb\n')
a("u_mvset", H+"Init == x \\in Alias\nNext == x' = x\nInv == FALSE\n", INV+'ALIAS Alias\nCONSTANT Alias = {m2, m1}\n')
a("u_mvset_next", H+"Init == x = {}\nNext == \\E m \\in Alias : m \\notin x /\\ x' = x \\cup {m}\nInv == x # Alias\n", INV+'ALIAS Alias\nCONSTANT Alias = {m3, m2, m1}\n')
a("u_mvset_sym", "CONSTANT S\nVARIABLE x\nAlias == [z |-> x]\nSym == Permutations(Alias)\nInit == x \\in Alias\nNext == x' = x\nInv == FALSE\n", INV+'ALIAS Alias\nSYMMETRY Sym\nCONSTANT Alias = {m2, m1}\nS = 1\n')
a("u_view_y", "VARIABLE x, y\nAlias == [z |-> x]\nVw == x\nInit == x = 0 /\\ y = Alias\nNext == x < 3 /\\ x' = x + 1 /\\ y' = y\nInv == x < 2\n", INV+'VIEW Vw\nALIAS Alias\nCONSTANT Alias = "q"\n')
a("u_rt_err", H+"Init == x = 0\nNext == x < 3 /\\ x' = (IF x = 2 THEN CHOOSE y \\in {} : TRUE ELSE x + 1)\n", "INIT Init\nNEXT Next\nALIAS Alias\nCONSTANT Alias = {}\n")
a("u_rt_err_inv", H+"Init == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2 \\/ x \\in {\"a\"}\n", INV+"ALIAS Alias\nCONSTANT Alias = 3\n")
a("u_tlcget_cfg", H+"Init == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\nASSUME PrintT(TLCGet(\"config\").mode)\n", INV+"ALIAS Alias\nCONSTANT Alias = 3\n")
a("u_lit_alias_used_inv", "VARIABLE x\nAlias == 2\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < Alias\n", INV+"ALIAS Alias\n")
a("u_lit_alias_xsub_used", "VARIABLE x\nAlias == 2\nX == 0\nInit == x = X\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n")
a("u_lit_str_xsub_rec", "VARIABLE x\nAlias == \"s\"\nX == 0\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n")
a("u_xsub_three_states_tool", "VARIABLE x, y\nAlias == 7\nX == 0\nInit == x = 0 /\\ y = 0\nNext == x < 3 /\\ x' = x + 1 /\\ y' = 1 - y\nInv == x < 3\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n")
for n,(t,c) in cases.items():
    if len(sys.argv)>1 and n not in sys.argv[1:]: continue
    os.makedirs(n, exist_ok=True)
    open(n+"/M.tla","w").write(t); open(n+"/M.cfg","w").write(c)
print(" ".join(cases))
