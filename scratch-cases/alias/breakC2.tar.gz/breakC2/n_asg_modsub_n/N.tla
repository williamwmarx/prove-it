---- MODULE N ----
VARIABLE x
Q == 1
Alias == [a |-> x]
====
