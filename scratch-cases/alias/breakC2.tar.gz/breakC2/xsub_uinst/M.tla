---- MODULE M ----
---- MODULE N ----
X == 0
====
EXTENDS Naturals, TLC
VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < 2
INSTANCE N
Alias == 3

====
