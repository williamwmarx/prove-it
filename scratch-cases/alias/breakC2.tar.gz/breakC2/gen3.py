import os, sys
V="VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n"
W="VARIABLE x\nInit == x = 0\nNext == x' = (x + 1) % 3\n"
INV="INIT Init\nNEXT Next\nINVARIANT Inv\n"
PCC="INIT Init\nNEXT Next\nPOSTCONDITION PC\n"
cases={}
def a(n, body, cfg, ext="Naturals, TLC", pre=""):
    cases[n]=("---- MODULE M ----\n"+pre+"EXTENDS "+ext+"\n"+body+"\n====\n", cfg)
a("xsub_pc_num_nd", W+"X == 0\nPC == 3\n", PCC+"CONSTANT X <- PC\n")
a("xsub_pc_str_nd", W+"X == 0\nPC == \"a\"\n", PCC+"CONSTANT X <- PC\n")
a("xsub_two", V+"X == 0\nY == 1\nAlias == 3\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\nY <- Alias\n")
a("xsub_args", V+"X == 0\nAlias == 3\nF(p) == p\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n")
a("xsub_x_used", V.replace("Inv == x < 2","Inv == x < X - 1")+"X == 0\nAlias == 3\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n")
a("xsub_noviol", V.replace("Inv == x < 2","Inv == x < 9")+"X == 0\nAlias == 3\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n")
a("xsub_len1", "VARIABLE x\nInit == x = 0\nNext == x' = x\nInv == x > 0\nX == 0\nAlias == \"b\"\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n")
a("xsub_live", "VARIABLE x\nInit == x = 0\nNext == x' = 1 - x\nSpec == Init /\\ [][Next]_x\nP == <>(x = 2)\nX == 0\nAlias == 3\n", "SPECIFICATION Spec\nPROPERTY P\nALIAS Alias\nCONSTANT X <- Alias\n")
a("xsub_assume", V+"X == 0\nAlias == 3\nASSUME X = 3\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n")
a("xsub_view", V+"X == 0\nVw == 3\n", INV+"VIEW Vw\nCONSTANT X <- Vw\n")
a("pc_num_nd", W+"PC == 3\n", PCC)
a("pc_x_sub_true", W+"X == FALSE\nPC == TRUE\n", PCC+"CONSTANT X <- PC\n")
a("xsub_alias_nonlit", V+"X == 0\nAlias == [a |-> 3]\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n")
a("xsub_alias_mutual", V+"Alias == 3\n", INV+"ALIAS Alias\nCONSTANT Alias <- Alias\n")
a("xsub_ext_both", V, INV+"ALIAS Alias\nCONSTANT X <- Alias\n", ext="Naturals, TLC, N", pre="---- MODULE N ----\nX == 0\nAlias == 3\n====\n")
a("xsub_uinst", V+"INSTANCE N\nAlias == 3\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n", pre="---- MODULE N ----\nX == 0\n====\n")
a("xsub_uinst_param", V+"INSTANCE N WITH c <- 1\nAlias == 3\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n", pre="---- MODULE N ----\nCONSTANT c\nX == c\n====\n")
for n,(t,c) in cases.items():
    if len(sys.argv)>1 and n not in sys.argv[1:]: continue
    os.makedirs(n, exist_ok=True)
    open(n+"/M.tla","w").write(t); open(n+"/M.cfg","w").write(c)
print(" ".join(cases))
