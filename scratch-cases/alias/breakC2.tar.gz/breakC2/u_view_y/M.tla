---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x, y
Alias == [z |-> x]
Vw == x
Init == x = 0 /\ y = Alias
Next == x < 3 /\ x' = x + 1 /\ y' = y
Inv == x < 2

====
