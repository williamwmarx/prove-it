import os, sys
V="VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n"
INV="INIT Init\nNEXT Next\nINVARIANT Inv\n"
PCC="INIT Init\nNEXT Next\nPOSTCONDITION PC\n"
W="VARIABLE x\nInit == x = 0\nNext == x' = (x + 1) % 3\n"
cases={}
def a(n, body, cfg, ext="Naturals, TLC", N=None):
    cases[n]=("---- MODULE M ----\nEXTENDS "+ext+"\n"+body+"\n====\n", cfg, N)
def mod(b): return "---- MODULE N ----\n"+b+"====\n"
a("n_inst_param_lit", V+"I == INSTANCE N WITH c <- 1\nAlias == I!K\n", INV+"ALIAS Alias\n", N=mod("CONSTANT c\nK == 3\n"))
a("n_inst_noparam_lit", V+"I == INSTANCE N\nAlias == I!K\n", INV+"ALIAS Alias\n", N=mod("K == 3\n"))
a("n_inst_c_sub3", V+"I == INSTANCE N WITH c <- 3\nAlias == I!K\n", INV+"ALIAS Alias\n", N=mod("CONSTANT c\nK == c\n"))
a("n_uinst_param_lit", V+"INSTANCE N WITH c <- 1\n", INV+"ALIAS Alias\n", N=mod("CONSTANT c\nAlias == 3\n"))
a("n_uinst_param_c", V+"INSTANCE N WITH c <- 3\n", INV+"ALIAS Alias\n", N=mod("CONSTANT c\nAlias == c\n"))
a("n_uinst_noparam_lit", V+"INSTANCE N\n", INV+"ALIAS Alias\n", N=mod("Alias == 3\n"))
a("n_ext_lit", V, INV+"ALIAS Alias\n", ext="Naturals, TLC, N", N=mod("Alias == \"a\"\n"))
a("n_ext_num", V, INV+"ALIAS Alias\n", ext="Naturals, TLC, N", N=mod("Alias == 3\n"))
a("n_pc_uinst_param_c", W+"INSTANCE N WITH c <- 3\n", PCC, N=mod("CONSTANT c\nPC == c\n"))
a("n_pc_uinst_param_true", W+"INSTANCE N WITH c <- TRUE\n", PCC, N=mod("CONSTANT c\nPC == c\n"))
a("n_pc_uinst_param_lit", W+"INSTANCE N WITH c <- TRUE\n", PCC, N=mod("CONSTANT c\nPC == 3\n"))
a("n_ext_alias_const", V, INV+"ALIAS Alias\n", ext="Naturals, TLC, N", N=mod("Alias == [a |-> 1]\n"))
a("n_uinst_alias_const", V+"INSTANCE N\n", INV+"ALIAS Alias\n", N=mod("Alias == [a |-> 1]\n"))
a("n_uinst_param_alias_const", V+"INSTANCE N WITH c <- 1\n", INV+"ALIAS Alias\n", N=mod("CONSTANT c\nAlias == [a |-> c]\n"))
a("n_ext_alias_sub_q", V+"Q == [y |-> 1]\n", INV+"ALIAS Alias\nCONSTANT Alias <- Q\n", ext="Naturals, TLC, N", N=mod("Alias == [a |-> 1]\n"))
a("n_ext_q_sub", V+"Alias == [z |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias <- Q\n", ext="Naturals, TLC, N", N=mod("Q == [a |-> 1]\n"))
a("n_ext_q_lit_sub", V+"Alias == [z |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias <- Q\n", ext="Naturals, TLC, N", N=mod("Q == 3\n"))
a("n_modasg_ext", V, INV+"ALIAS Alias\nCONSTANT Alias = [N] 3\n", ext="Naturals, TLC, N", N=mod("VARIABLE y\nAlias == [a |-> y]\n").replace("y","x"))
a("n_asg_ext_def", V, INV+"ALIAS Alias\nCONSTANT Alias = 3\n", ext="Naturals, TLC, N", N=mod("Alias == 1\n"))
a("n_asg_ext_def_rec", V, INV+"ALIAS Alias\nCONSTANT Alias = 3\n", ext="Naturals, TLC, N", N=mod("Alias == [a |-> 1]\n"))
a("n_asg_inner_decl", V+"I == INSTANCE N WITH Alias <- 1\nAlias == [z |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias = 3\n", N=mod("CONSTANT Alias\nK == Alias\n"))
a("n_asg_inner_decl_noroot", V+"I == INSTANCE N WITH Alias <- 1\n", INV+"ALIAS Alias\nCONSTANT Alias = 3\n", N=mod("CONSTANT Alias\nK == Alias\n"))
a("n_asg_uinst_decl", V+"INSTANCE N WITH Alias <- 1\n", INV+"ALIAS Alias\nCONSTANT Alias = 3\n", N=mod("CONSTANT Alias\nK == Alias\n"))
a("n_xsub_ext", V+"Alias == 3\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n", ext="Naturals, TLC, N", N=mod("X == 0\n"))
a("n_xsub_ext_alias", V+"X == 0\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n", ext="Naturals, TLC, N", N=mod("Alias == 3\n"))
a("n_xsub_ext_both", V, INV+"ALIAS Alias\nCONSTANT X <- Alias\n", ext="Naturals, TLC, N", N=mod("X == 0\nAlias == 3\n"))
a("n_xmodsub_inst", V+"I == INSTANCE N\nAlias == 3\n", INV+"ALIAS Alias\nCONSTANT X <- [N] Alias\n", N=mod("X == 0\n"))
a("n_xmodsub_ext", V+"Alias == 3\n", INV+"ALIAS Alias\nCONSTANT X <- [N] Alias\n", ext="Naturals, TLC, N", N=mod("X == 0\n"))
a("n_xsub_uinst", V+"INSTANCE N\nAlias == 3\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n", N=mod("X == 0\n"))
a("n_xsub_uinst_param", V+"INSTANCE N WITH c <- 1\nAlias == 3\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n", N=mod("CONSTANT c\nX == c\n"))
a("n_xsub_pc_ext", W+"PC == 3\n", PCC+"CONSTANT X <- PC\n", ext="Naturals, TLC, N", N=mod("X == 0\n"))
a("n_asg_modsub_n", V, INV+"ALIAS Alias\nCONSTANT Alias = 3\nCONSTANT Alias <- [N] Q\n", ext="Naturals, TLC, N", N=mod("Q == 1\nAlias == [a |-> x]\n").replace("Q == 1","VARIABLE x\nQ == 1"))
a("n_asg_modsub_inst", V+"I == INSTANCE N\nAlias == [z |-> x]\nQ == [q |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias = 3\nCONSTANT Alias <- [N] Q\n", N=mod("Alias == 1\n"))
for n,(t,c,N) in cases.items():
    if len(sys.argv)>1 and n not in sys.argv[1:]: continue
    os.makedirs(n, exist_ok=True)
    open(n+"/M.tla","w").write(t); open(n+"/M.cfg","w").write(c)
    if N: open(n+"/N.tla","w").write(N)
print(" ".join(cases))
