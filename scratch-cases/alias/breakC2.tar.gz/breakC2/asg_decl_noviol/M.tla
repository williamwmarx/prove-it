---- MODULE M ----
EXTENDS Naturals, TLC
CONSTANT Alias
VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < 9

====
