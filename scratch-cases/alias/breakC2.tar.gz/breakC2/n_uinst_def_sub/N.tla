---- MODULE N ----
CONSTANT c
Alias == c
====
