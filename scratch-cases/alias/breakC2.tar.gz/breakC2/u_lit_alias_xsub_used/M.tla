---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Alias == 2
X == 0
Init == x = X
Next == x < 3 /\ x' = x + 1
Inv == x < 2

====
