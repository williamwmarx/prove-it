---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Alias == [z |-> x]
Init == x = {}
Next == \E m \in Alias : m \notin x /\ x' = x \cup {m}
Inv == x # Alias

====
