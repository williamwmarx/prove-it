---- MODULE M ----
EXTENDS Naturals, TLC, Bags
VARIABLE x
Init == x = 0
Next == x < 3 /\ x' = x + 1
Inv == x < 2
Alias == [z |-> x]

====
