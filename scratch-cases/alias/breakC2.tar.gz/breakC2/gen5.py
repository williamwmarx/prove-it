import os, sys
V="VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nInv == x < 2\n"
INV="INIT Init\nNEXT Next\nINVARIANT Inv\n"
cases={}
def a(n, body, cfg, ext="Naturals, TLC", pre=""):
    cases[n]=("---- MODULE M ----\n"+pre+"EXTENDS "+ext+"\n"+body+"\n====\n", cfg)
a("sub_q_modasg", V+"Q == [y |-> x]\nAlias == [z |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias <- Q\nCONSTANT Q = [M] 3\n")
a("sub_q_modasg_const", V+"Q == [y |-> 1]\nAlias == [z |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias <- Q\nCONSTANT Q = [M] 3\n")
a("asg_block", V+"Alias == [z |-> x]\nA == 0\n", INV+"ALIAS Alias\nCONSTANTS A = 1 Alias = 3\n")
a("asg_mv_self", V+"Alias == [z |-> x]\n", INV+"ALIAS Alias\nCONSTANT Alias = Alias\n")
a("asg_spec", "VARIABLE x\nInit == x = 0\nNext == x < 3 /\\ x' = x + 1\nSpec == Init /\\ [][Next]_x\nInv == x < 2\nAlias == [z |-> x]\n", "SPECIFICATION Spec\nINVARIANT Inv\nALIAS Alias\nCONSTANT Alias = \"s\"\n")
a("view_asg_only", V+"Vw == x\n", INV+"VIEW Vw\nCONSTANT Vw = 3\n")
a("asg_alias_xsub_lit", V+"X == 0\nAlias == 3\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\nAlias = 4\n")
a("xsub_ext_alias_root_x", V+"X == 0\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n", ext="Naturals, TLC, N", pre="---- MODULE N ----\nAlias == 3\n====\n")
a("xsub_root_alias_ext_x", V+"Alias == 3\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n", ext="Naturals, TLC, N", pre="---- MODULE N ----\nX == 0\n====\n")
a("xmodsub_ext", V+"Alias == 3\n", INV+"ALIAS Alias\nCONSTANT X <- [N] Alias\n", ext="Naturals, TLC, N", pre="---- MODULE N ----\nX == 0\n====\n")
a("xsub_label_alias", V+"X == 0\nAlias == lab :: 3\n", INV+"ALIAS Alias\nCONSTANT X <- Alias\n")
for n,(t,c) in cases.items():
    if len(sys.argv)>1 and n not in sys.argv[1:]: continue
    os.makedirs(n, exist_ok=True)
    open(n+"/M.tla","w").write(t); open(n+"/M.cfg","w").write(c)
print(" ".join(cases))
