---- MODULE N ----
CONSTANT c
VARIABLE v
Alias == c
====
