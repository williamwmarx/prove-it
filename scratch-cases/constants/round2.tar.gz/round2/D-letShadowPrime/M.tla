---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Fst(a, b) == a
Snd(a, b) == b
Dbl(a) == a + a
SetX(v) == x' = v
En(a) == ENABLED a
Box(p) == []p
Dia(p) == <>p
Fn(a) == [i \in 1..2 |-> a]
Ch(a) == CHOOSE i \in 0..5 : i = a
Aw(a) == Fst(a, x' = 0)
Next == LET Fst(a, b) == b IN Fst(1 \div 0, x' = (x + 1) % 3)

Init == x = 0
Spec == Init /\ [][Next]_x /\ WF_x(Next)

====
