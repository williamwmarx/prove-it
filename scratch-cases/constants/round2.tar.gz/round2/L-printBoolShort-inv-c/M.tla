---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Op(a, b) == a \/ b
K1 == Op(PrintT("a"), PrintT("b"))
Inv == K1 = K1
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
