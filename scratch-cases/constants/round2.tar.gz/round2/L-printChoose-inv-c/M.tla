---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
K1 == CHOOSE i \in 1..3 : PrintT(i) /\ i = 2
Inv == K1 = K1
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
