---- MODULE M ----
EXTENDS Naturals, TLC
CONSTANT S
VARIABLE x
Sym == {}
Sym2 == IF 1 \div 0 = 1 THEN {} ELSE {}
Init == x \in S
Next == x' \in S
Spec == Init /\ [][Next]_x
====
