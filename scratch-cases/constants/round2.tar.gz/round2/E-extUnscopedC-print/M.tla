---- MODULE M ----
EXTENDS Naturals, TLC, Inner
VARIABLE x
E == PrintT("e")
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
