---- MODULE M ----
EXTENDS Naturals, TLC, Integers
VARIABLE x
Al == FALSE
Inv == x < 2
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
