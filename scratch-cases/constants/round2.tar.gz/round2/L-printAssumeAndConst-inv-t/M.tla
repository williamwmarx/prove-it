---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
K1 == IF PrintT("k1") THEN 1 ELSE 0
ASSUME K1 = 1
ASSUME IF PrintT("as") THEN 1 ELSE 0 = 1
Inv == K1 = K1
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
