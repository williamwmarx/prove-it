---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT K
VARIABLE x
C == IF 1 THEN TRUE ELSE FALSE
Init == x = 0
Init2 == C /\ Init
Next == x' = (x + 1) % 3
Spec == Init /\ C /\ [][Next]_x

====
