---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
I == INSTANCE Inner
Next2 == Next /\ I!IInv
E == x < 1
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next2]_x

====
