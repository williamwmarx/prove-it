---- MODULE M ----
EXTENDS Naturals, TLC, Inner
VARIABLE x
E == TLCEval(LET q == TRUE IN q)
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
