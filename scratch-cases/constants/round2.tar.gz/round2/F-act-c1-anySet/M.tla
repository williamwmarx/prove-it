---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x
C == 1
D == TLCGet("config").mode
Inv == TRUE
Init == x = 0
Next == x' = (x + 1) % 3 /\ C = C
Spec == Init /\ [][Next]_x

====
