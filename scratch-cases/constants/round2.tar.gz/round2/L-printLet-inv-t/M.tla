---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
K1 == LET a == IF PrintT("a") THEN 1 ELSE 0 IN a + a
Inv == K1 = K1
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
