---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Op(a) == a + 1
K1 == Op(IF PrintT("arg") THEN 1 ELSE 0) + Op(IF PrintT("arg2") THEN 1 ELSE 0)
Inv == K1 = K1
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
