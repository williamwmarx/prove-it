---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
K1 == {i \in 1..3 : PrintT(i)}
Init == x = 0
Next == x' = (x + 1) % 3 /\ K1 = K1
Spec == Init /\ [][Next]_x

====
