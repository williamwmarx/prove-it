---- MODULE M ----
EXTENDS Naturals, TLC, FiniteSets
CONSTANT K
VARIABLE x
KD == K = 1
C == x < 10
D == IsFiniteSet({1})
Inv == C /\ x < 10
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
