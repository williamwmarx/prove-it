---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
C == FALSE
D == RandomElement({TRUE})
Inv == C /\ x < 10
Cn == C
Init == x = 0
Next == x' = (x + 1) % 3
Spec == C /\ Init /\ [][Next]_x

====
