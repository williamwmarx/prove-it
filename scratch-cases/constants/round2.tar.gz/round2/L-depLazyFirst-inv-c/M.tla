---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Fst(a, b) == a
K1 == IF PrintT("k1") THEN 1 ELSE 0
K3 == Fst(K2, K1)
K2 == IF PrintT("k2") THEN 2 ELSE 0
Inv == K3 = K3
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
