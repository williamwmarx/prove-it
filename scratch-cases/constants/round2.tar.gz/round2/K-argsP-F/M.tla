---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
I == INSTANCE Inner
Inv == I!IP
Q(a) == FALSE
E == FALSE
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
