---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
E == PrintT("e")
A == [x |-> x]
B == [y |-> E]
Inv == x < 2
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
