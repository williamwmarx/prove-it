---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x
C == IF PrintT("c") THEN 1 ELSE 0
D == RandomElement({TRUE})
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
