---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Ap(G(_), a) == G(a) + G(a)
K1 == Ap(LAMBDA v : IF PrintT("lam") THEN v ELSE 0, IF PrintT("arg") THEN 2 ELSE 0)
Inv == K1 = K1
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
