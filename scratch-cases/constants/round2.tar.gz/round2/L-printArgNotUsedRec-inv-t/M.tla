---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
RECURSIVE R(_, _)
R(n, a) == IF n = 0 THEN 0 ELSE R(n - 1, a)
K1 == R(3, PrintT("deep"))
Inv == K1 = K1
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
