---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT K
VARIABLE x
C == PrintT("c")
Init == x = 0
Init2 == C /\ Init
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x /\ C

====
