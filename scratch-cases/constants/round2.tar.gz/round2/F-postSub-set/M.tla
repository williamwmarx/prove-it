---- MODULE M ----
EXTENDS Naturals, TLC, Integers
VARIABLE x
Post == TRUE
Q == {}
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
