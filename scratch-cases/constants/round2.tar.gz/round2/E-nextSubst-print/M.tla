---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
E == PrintT("e")
Next2 == E /\ x' = 1 - x
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
