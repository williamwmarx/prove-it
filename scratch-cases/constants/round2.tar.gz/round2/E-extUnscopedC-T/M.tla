---- MODULE M ----
EXTENDS Naturals, TLC, Inner
VARIABLE x
E == TRUE
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
