---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Op(a, b) == CASE TRUE -> a [] FALSE -> b
K1 == Op(IF PrintT("a") THEN 1 ELSE 0, IF PrintT("b") THEN 2 ELSE 0)
Init == x = 0
Next == x' = (x + 1) % 3 /\ K1 = K1
Spec == Init /\ [][Next]_x

====
