---- MODULE M ----
EXTENDS Naturals, TLC
CONSTANT S
VARIABLE x
Sym == {}
Sym2 == {}
Init == x \in S
Next == x' \in S
Spec == Init /\ [][Next]_x
====
