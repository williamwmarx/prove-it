---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
K2 == K1 + IF PrintT("k2") THEN 1 ELSE 0
K1 == IF PrintT("k1") THEN 1 ELSE 0
Init == x = 0
Next == x' = (x + 1) % 3 /\ K2 = K2
Spec == Init /\ [][Next]_x

====
