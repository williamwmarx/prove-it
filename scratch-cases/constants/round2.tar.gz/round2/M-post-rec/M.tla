---- MODULE M ----
EXTENDS Naturals, TLC, FiniteSets
CONSTANT K
VARIABLE x
KD == K = 1
C == x < 10
D == LET RECURSIVE R(_) R(n) == IF n = 0 THEN TRUE ELSE R(n - 1) IN R(5)
Inv == C /\ x < 10
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
