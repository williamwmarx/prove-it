---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
F1(a) == LET y == 2 IN a + y
F2(a) == \E i \in 1..2 : a = i
F3(a) == CHOOSE i \in 1..3 : i = a
RECURSIVE R1(_, _)
R1(n, a) == IF n = 0 THEN a ELSE R1(n - 1, n)
RECURSIVE R2(_, _)
R2(n, a) == IF n = 0 THEN a ELSE R2(n - 1, a + n)
G4(a) == a * 2
F4(a) == G4(a + 1)
G5(a, b) == a - b
F5(a, b) == G5(b, a)
Ap(G(_), v) == G(v)
F6(a) == LET i == 10 IN a + i
F7(a) == {a + i : i \in 1..2}
F8(a) == [i \in 1..2 |-> a + i]
F9(a, i) == [j \in 1..2 |-> a + i + j]
RECURSIVE Pass(_, _)
Pass(n, a) == IF n = 0 THEN a ELSE Pass(n - 1, a)
RECURSIVE Pass2(_, _)
Pass2(n, a) == IF n = 0 THEN a ELSE Pass2(n - 1, a + 0)
RECURSIVE Use2(_, _)
Use2(n, a) == IF n = 0 THEN a ELSE Use2(n - 1, (a + a) % 1000)
F10(a) == LET F1(b) == a + b IN F1(a)
F11(a) == LET a2 == a IN \A a3 \in {a2} : a3 = a
F12(S) == \E s \in S : s = 1
K == F5(10, 3)
Inv == PrintT(K)
Init == x = 0
Next == x' = (x + 1) % 1
Spec == Init /\ [][Next]_x

====
