---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
C == TLCEval(LET q == TRUE IN q)
D == x < 9
E == TLCEval(LET q == TRUE IN q)
Inv == C
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
