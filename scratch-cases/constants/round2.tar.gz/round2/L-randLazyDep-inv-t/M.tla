---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Snd(a, b) == b
K2 == Snd(K1, RandomElement(1..1000))
K1 == RandomElement(1..1000)
Inv == K2 = K2
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
