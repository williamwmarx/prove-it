---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT F(_)
VARIABLE x
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x
Inv == PrintT(F(1)) /\ TRUE

====
