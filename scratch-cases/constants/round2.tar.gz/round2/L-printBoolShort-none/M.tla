---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Op(a, b) == a \/ b
K1 == Op(PrintT("a"), PrintT("b"))
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
