---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT K
VARIABLE x
C == "ab"[1] = "a"
Init == x = 0
Next == x' = (x + 1) % 3
Spec == C /\ Init /\ [][Next]_x
Inv == x < 2

====
