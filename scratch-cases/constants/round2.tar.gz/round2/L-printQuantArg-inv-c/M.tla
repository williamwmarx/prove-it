---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Op(S) == \E s \in S : s = 2
K1 == Op({i \in 1..3 : PrintT(i)})
Inv == K1 = K1
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
