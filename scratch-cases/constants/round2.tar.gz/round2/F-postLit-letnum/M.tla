---- MODULE M ----
EXTENDS Naturals, TLC, Integers
VARIABLE x
Post == LET a == 1 IN a
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
