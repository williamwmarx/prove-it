---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Fst(a, b) == a
Snd(a, b) == b
Twice(a) == <<a, a>>
Dbl(a) == a + a
AndRev(a, b) == b /\ a
L1(a) == L2(a)
L2(b) == L3(b)
L3(c) == c + c
IfOp(c, a, b) == IF c THEN a ELSE b
Fn(a) == [i \in 1..3 |-> a]
Rec(a) == [f |-> a, g |-> a]
Ch(a) == CHOOSE i \in 1..5 : i = a
Shadow(a) == LET a2 == a + 1 IN LET a3 == a2 * a IN a3
Ap(G(_), v) == G(v) + G(v)
SetOp(a) == {a, a + 1}
Quant(a) == \A i \in 1..3 : i < a
R[n \in Nat] == IF n = 0 THEN 1 ELSE R[n-1] + 1
RECURSIVE Rr(_, _)
Rr(n, a) == IF n = 0 THEN a ELSE Rr(n - 1, (a + a) % 7)
K == L1(RandomElement(1..1000))
ASSUME PrintT(K)
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
