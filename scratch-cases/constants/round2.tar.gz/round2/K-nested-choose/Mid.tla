---- MODULE Mid ----
EXTENDS Naturals
VARIABLE x
J == INSTANCE Inner
MInv == J!IInv
====
