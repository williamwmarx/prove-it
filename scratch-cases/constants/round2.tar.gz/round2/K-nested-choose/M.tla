---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
K2 == INSTANCE Mid
Inv == K2!MInv
E == CHOOSE i \in {} : TRUE
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
