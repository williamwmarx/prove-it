---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
E == x < 2
Spec2 == E /\ Init /\ [][Next]_x
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
