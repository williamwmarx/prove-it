---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
K1 == LET f[i \in 0..3] == IF i = 0 THEN PrintT(0) ELSE f[i - 1] /\ PrintT(i) IN f[3]
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
