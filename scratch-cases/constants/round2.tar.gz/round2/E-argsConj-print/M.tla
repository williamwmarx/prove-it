---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
P(a) == a < 10
Q(a) == PrintT("e") /\ a < 9
Init == x = 0
Next == x' = (x + 1) % 3
Spec == P(0) /\ Init /\ [][Next]_x

====
