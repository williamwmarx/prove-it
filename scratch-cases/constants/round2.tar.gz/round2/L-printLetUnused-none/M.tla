---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
K1 == LET a == IF PrintT("a") THEN 1 ELSE 0 IN 5
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
