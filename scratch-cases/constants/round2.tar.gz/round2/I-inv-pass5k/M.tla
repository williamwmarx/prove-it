---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
SetF(a) == {a + i : i \in 1..3000}
AllF(a) == \A i \in 1..3000 : i # a
FnF(a) == [i \in 1..3000 |-> a]
ChF(a) == CHOOSE i \in 1..3000 : i = 3000 /\ a > 0
RECURSIVE RecF(_, _)
RecF(n, a) == IF n = 0 THEN 0 ELSE (a % 2) + RecF(n - 1, a)
RECURSIVE RecG(_, _)
RecG(n, a) == IF n = 0 THEN a ELSE RecG(n - 1, a) + 0
SumF(a) == LET f[i \in 0..2000] == IF i = 0 THEN 0 ELSE f[i - 1] + (a % 3) IN f[2000]
Lay1(a) == Lay2(a) + Lay2(a)
Lay2(a) == Lay3(a) + Lay3(a)
Lay3(a) == Lay4(a) + Lay4(a)
Lay4(a) == Lay5(a) + Lay5(a)
Lay5(a) == a + a
LetF(a) == LET b == a IN LET c == b IN \A i \in 1..3000 : c # i
K == RecG(5000, 1)
Inv == K = K
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
