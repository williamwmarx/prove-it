---- MODULE Inner ----
EXTENDS Naturals, TLC
VARIABLE x
C == x < 10
IInv == C
IInv2 == x >= 0 /\ C
IAct == x' # 5 /\ C
P(a) == a < 10
IP == P(x)
====
