---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT K
VARIABLE x
C == \A i \in {0, 1} : 1 \div i = 1
Init == x = 0
Next == x' = (x + 1) % 3
Spec == C /\ Init /\ [][Next]_x
Inv == x < 2

====
