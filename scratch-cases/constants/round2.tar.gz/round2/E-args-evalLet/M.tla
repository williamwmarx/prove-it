---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
P(a) == a < 10
Q(a) == TLCEval(LET q == TRUE IN q) /\ a < 9
Inv == P(x)
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
