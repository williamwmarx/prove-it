---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT K
VARIABLE x
C == [i \in 1..2 |-> i][3] = 1
Init == x = 0
Init2 == C /\ Init
Next == x' = (x + 1) % 3
Spec == Init2 /\ [][Next]_x

====
