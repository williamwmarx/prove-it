---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Op(a, b) == CASE FALSE -> a [] OTHER -> b
K1 == Op(IF PrintT("a") THEN 1 ELSE 0, IF PrintT("b") THEN 2 ELSE 0)
Inv == K1 = K1
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
