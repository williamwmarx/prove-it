---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT K
VARIABLE x
C == LET Fst(a, b) == a IN Fst(TRUE, 1 \div 0)
Init == x = 0
Init2 == C /\ Init
Next == x' = (x + 1) % 3
Spec == Init2 /\ [][Next]_x

====
