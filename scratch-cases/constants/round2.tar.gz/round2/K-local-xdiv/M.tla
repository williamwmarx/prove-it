---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
LOCAL I == INSTANCE Inner
Inv == I!IInv
E == 10 \div (x - 1) > 0
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
