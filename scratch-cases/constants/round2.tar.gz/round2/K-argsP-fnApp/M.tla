---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
I == INSTANCE Inner
Inv == I!IP
Q(a) == [i \in 1..2 |-> TRUE][x + 2]
E == [i \in 1..2 |-> TRUE][x + 2]
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
