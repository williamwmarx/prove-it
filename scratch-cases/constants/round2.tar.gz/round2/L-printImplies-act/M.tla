---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
Op(a, b) == a => b
K1 == Op(PrintT("a") /\ FALSE, PrintT("b"))
Init == x = 0
Next == x' = (x + 1) % 3 /\ K1 = K1
Spec == Init /\ [][Next]_x

====
