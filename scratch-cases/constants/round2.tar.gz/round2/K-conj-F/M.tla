---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
I == INSTANCE Inner
E == FALSE
Init == x = 0
Next == x' = (x + 1) % 3
Spec == I!IInv /\ Init /\ [][Next]_x

====
