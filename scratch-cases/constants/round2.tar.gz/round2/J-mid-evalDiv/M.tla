---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT K
VARIABLE x
C == TLCEval(1 \div 0) = 1
Init == x = 0
Init2 == C /\ Init
Next == x' = (x + 1) % 3
Spec == Init /\ C /\ [][Next]_x

====
