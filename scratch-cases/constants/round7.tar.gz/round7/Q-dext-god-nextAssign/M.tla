---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets, Ext
VARIABLE x
C == 1


Init == x = 0
Next == x' = (x + C) % 3
Spec == Init /\ [][Next]_x

====
