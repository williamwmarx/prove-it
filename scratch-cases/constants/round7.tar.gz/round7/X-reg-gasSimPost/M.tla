---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Po == PrintT(TLCGet(1))
Init == x = 0
Next == x' = (x + 1) % 3 /\ TLCGetAndSet(1, +, 1, 0) >= 0
Spec == Init /\ [][Next]_x

====
