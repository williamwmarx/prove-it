---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
K == TLCGetAndSet(1, +, 1, 0)
Init == x = K
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
