---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, Ext
VARIABLE x
Foo == 1
Foo1(a) == a
FooF[i \in 1..2] == i

Init == x = CHOOSE i \in {0, Bar} : i > 0
Next == x' = x
Spec == Init /\ [][Next]_x
====
