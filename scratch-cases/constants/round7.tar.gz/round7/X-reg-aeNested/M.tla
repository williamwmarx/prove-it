---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x

Init == x = 0 /\ AssertEq(AssertEq(1, 2), FALSE)
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
