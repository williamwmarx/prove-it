---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == a
D(a) == IF PrintT(TLCGet("level")) THEN a ELSE 0

Init == x = C(1) - 1
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
