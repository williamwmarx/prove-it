---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == TLCEval(TLCGetAndSet(7, +, 1, 1))
Ap(Op(_), v) == Op(0)
Init == x = 0
Next == x' = Ap(LAMBDA a : (x + 1) % 3, C)
Spec == Init /\ [][Next]_x

====
