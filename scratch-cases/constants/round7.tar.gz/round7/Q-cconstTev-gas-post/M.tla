---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
CONSTANT C
D == TLCEval(IF TLCGetAndSet(7, +, 1, 0) >= 0 THEN 1 ELSE 0)
Po == C = 1
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
