---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT S
VARIABLE x
Inv == x = 0 \/ S = "zz"
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
