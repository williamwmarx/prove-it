---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == IF AssertEq(1, 2) THEN 0 ELSE 1

Init == x = 0
Next == x' = (x + C) % 3
Spec == Init /\ [][Next]_x

====
