---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
I == INSTANCE N2 WITH K <- 0
Inv == I!CI

Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
