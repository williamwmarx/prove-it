---- MODULE Ext ----
EXTENDS Naturals, TLC, TLCExt
D == IF PrintT(TLCGetOrDefault(7, "u")) THEN 1 ELSE 0
====
