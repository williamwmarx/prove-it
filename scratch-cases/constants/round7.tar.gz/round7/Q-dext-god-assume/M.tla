---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets, Ext
VARIABLE x
C == 1

ASSUME C = 1
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
