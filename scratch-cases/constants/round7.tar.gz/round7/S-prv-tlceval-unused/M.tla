---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == Print("dv", 1)
K == TLCEval(C)

Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
