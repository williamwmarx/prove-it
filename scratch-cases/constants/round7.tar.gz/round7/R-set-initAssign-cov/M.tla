---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == IF TLCSet(7, 5) THEN 1 ELSE 0

Init == x = C
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
