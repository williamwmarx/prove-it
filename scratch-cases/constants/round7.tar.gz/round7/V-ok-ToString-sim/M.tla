---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, Ext
VARIABLE x
I3 == INSTANCE N3
IE == INSTANCE Ext

Init == x = 0 /\ PrintT(ToString(5))
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
====
