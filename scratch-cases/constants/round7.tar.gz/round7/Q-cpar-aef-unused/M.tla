---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == a
D(a) == IF ~AssertEq(1, 2) THEN a ELSE 0

Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
