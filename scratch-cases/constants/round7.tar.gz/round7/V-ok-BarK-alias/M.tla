---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, Ext
VARIABLE x
I3 == INSTANCE N3
IE == INSTANCE Ext
Al == [x |-> x, r |-> BarK]
Inv == x < 2
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
====
