---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == RandomElement({1})

Init == x = CHOOSE i \in 0..C : i = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
