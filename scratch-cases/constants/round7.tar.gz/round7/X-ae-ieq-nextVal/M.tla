---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mv, mv2
VARIABLE x

Init == x = 0
Next == x' = IF AssertEq(1, 1) THEN (x + 1) % 3 ELSE (x + 2) % 3
Spec == Init /\ [][Next]_x

====
