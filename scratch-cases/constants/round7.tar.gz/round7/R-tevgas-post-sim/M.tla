---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == TLCEval(TLCGetAndSet(7, +, 1, 1))
Po == C > 0
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
