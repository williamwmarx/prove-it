---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mv, mv2
VARIABLE x
Cs == AssertEq(1, 1) \/ x > 5
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
