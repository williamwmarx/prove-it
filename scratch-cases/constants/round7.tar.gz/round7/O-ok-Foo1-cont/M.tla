---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, Ext
VARIABLE x
Foo == 1
Foo1(a) == a
FooF[i \in 1..2] == i
Inv == x < Foo1(5) - 41
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
====
