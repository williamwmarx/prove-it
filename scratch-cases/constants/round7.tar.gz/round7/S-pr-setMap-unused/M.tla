---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == IF PrintT("d") THEN 1 ELSE 0
K == {C + i : i \in 1..2}

Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
