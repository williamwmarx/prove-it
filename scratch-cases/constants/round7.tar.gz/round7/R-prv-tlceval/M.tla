---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == Print("dv", 1)

Init == x = TLCEval(C) - 1
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
