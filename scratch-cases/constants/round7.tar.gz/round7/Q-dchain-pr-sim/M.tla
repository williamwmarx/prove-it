---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D0 == IF PrintT("d") THEN 1 ELSE 0
D == D0

Init == x = 0
Next == x' = (x + C) % 3
Spec == Init /\ [][Next]_x

====
