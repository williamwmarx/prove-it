---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Inv == PrintT("ci")
K0 == PrintT("k0")
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
