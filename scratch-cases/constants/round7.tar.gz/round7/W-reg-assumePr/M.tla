---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Inv == TLCGetOrDefault(1, 0) = 0
ASSUME PrintT("as")
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
