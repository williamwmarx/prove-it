---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT N
VARIABLE x
Inv == N = N

Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
