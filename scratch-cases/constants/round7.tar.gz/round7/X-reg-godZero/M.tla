---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x

Init == x = 0 /\ PrintT(TLCGetOrDefault(0, 7))
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
