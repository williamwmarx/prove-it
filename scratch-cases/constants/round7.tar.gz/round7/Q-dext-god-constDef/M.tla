---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets, Ext
VARIABLE x
C == 1

K == C + 1
Init == x = K - 2
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
