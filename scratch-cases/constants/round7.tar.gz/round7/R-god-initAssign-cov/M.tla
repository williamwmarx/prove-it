---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == TLCGetOrDefault(7, 1)

Init == x = C
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
