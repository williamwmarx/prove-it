---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == a
D(a) == IF PrintT(TLCGetOrDefault(7, "u")) THEN a ELSE 0

Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
