---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Inv == TRUE
D == PrintT("d")

Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
