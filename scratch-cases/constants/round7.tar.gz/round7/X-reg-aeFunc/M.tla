---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x

Init == x = 0 /\ PrintT([i \in 1..2 |-> AssertEq(i, 1)])
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
