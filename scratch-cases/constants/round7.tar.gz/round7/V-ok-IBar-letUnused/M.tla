---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, Ext
VARIABLE x
I3 == INSTANCE N3
IE == INSTANCE Ext

Init == x = 0
Next == LET q == IE!Bar IN x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
====
