---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Inv == PrintT("ci")

Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
