---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == TLCGetOrDefault(7, 1)

Init == x = 0
Next == LET q == C IN x' = (x + q) % 3
Spec == Init /\ [][Next]_x

====
