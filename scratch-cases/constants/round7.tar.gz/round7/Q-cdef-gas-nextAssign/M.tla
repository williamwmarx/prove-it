---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == IF TLCGetAndSet(7, +, 1, 0) >= 0 THEN 1 ELSE 0

Init == x = 0
Next == x' = (x + C) % 3
Spec == Init /\ [][Next]_x

====
