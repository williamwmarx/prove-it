---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets, Ext
VARIABLE x

D == IF PrintT(TLCGet("level")) THEN 1 ELSE 0
Al == [x |-> x, c |-> C]
Inv == x < 2
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
