---- MODULE Ext ----
EXTENDS Naturals, TLC, TLCExt
D == IF ~AssertEq(1, 2) THEN 1 ELSE 0
====
