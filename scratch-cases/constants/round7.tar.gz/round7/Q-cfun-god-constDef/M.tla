---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == [i \in 1..2 |-> 1]
D[i \in 1..2] == IF PrintT(TLCGetOrDefault(7, "u")) THEN 1 ELSE 0
K == C[1] + 1
Init == x = K - 2
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
