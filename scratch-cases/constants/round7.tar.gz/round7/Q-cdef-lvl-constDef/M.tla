---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == IF PrintT(TLCGet("level")) THEN 1 ELSE 0
K == C + 1
Init == x = K - 2
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
