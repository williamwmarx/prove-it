---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT S
VARIABLE x

Init == x = 0 /\ PrintT(S)
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
