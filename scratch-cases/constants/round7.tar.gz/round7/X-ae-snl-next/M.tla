---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mv, mv2
VARIABLE x

Init == x = 0
Next == AssertEq("x\ny", "x") /\ x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
