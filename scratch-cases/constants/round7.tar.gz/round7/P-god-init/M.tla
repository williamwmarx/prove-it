---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt
VARIABLE x
D == PrintT(TLCGetOrDefault(7, "u"))
Init == x = 0 /\ D
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
====
