---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets, Ext
VARIABLE x

D == IF PrintT("d") THEN 1 ELSE 0

Init == x = 0
Next == x' = (x + C) % 3
Spec == Init /\ [][Next]_x

====
