---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == Print("dv", 1)

Init == x = 0
Next == x' = (x + C) % 3
Spec == Init /\ [][Next]_x

====
