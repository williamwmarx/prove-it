---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == a
D(a) == IF ~AssertEq(1, 2) THEN a ELSE 0
K == C(1) + 1
Init == x = K - 2
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
