---- MODULE Ext ----
EXTENDS Ext2
Bar == 1
BarK == Bar
====
