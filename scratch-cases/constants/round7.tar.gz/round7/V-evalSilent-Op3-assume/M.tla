---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, Ext
VARIABLE x
I3 == INSTANCE N3
IE == INSTANCE Ext
ASSUME PrintT(I3!Op3)
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
====
