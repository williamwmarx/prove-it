---- MODULE N3 ----
Op3 == 1
Op3P(a) == a
====
