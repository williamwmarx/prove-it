---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mv, mv2
VARIABLE x

Init == x = 0
Next == AssertEq([i \in 1..2 |-> i], <<1, 3>>) /\ x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
