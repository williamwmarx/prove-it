---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == IF ~AssertEq(1, 2) THEN 1 ELSE 0

Init == x = C - 1
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
