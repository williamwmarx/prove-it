---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, Ext
VARIABLE x
Foo == 1
Foo1(a) == a
FooF[i \in 1..2] == i
f[n \in 0..2] == IF n = 0 THEN Deep ELSE f[n - 1]
Init == x = f[2] - 42
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
====
