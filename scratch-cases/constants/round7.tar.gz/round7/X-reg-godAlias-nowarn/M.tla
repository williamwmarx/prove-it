---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Al == [x |-> x, r |-> TLCGetOrDefault(1, "u")]
Inv == x < 2
Init == x = 0
Next == x' = (x + 1) % 3 /\ TLCSet(1, x)
Spec == Init /\ [][Next]_x

====
