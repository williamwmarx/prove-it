---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x

Init == x = 0 /\ PrintT(TLCGetOrDefault("foo", 5))
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
