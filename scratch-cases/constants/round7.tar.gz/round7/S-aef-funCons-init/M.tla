---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == IF AssertEq(1, 2) THEN 0 ELSE 1
K == [i \in 1..2 |-> C]

Init == x = 0 /\ PrintT(K)
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
