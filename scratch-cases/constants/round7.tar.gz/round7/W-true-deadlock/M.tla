---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Inv == TRUE

Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x

====
