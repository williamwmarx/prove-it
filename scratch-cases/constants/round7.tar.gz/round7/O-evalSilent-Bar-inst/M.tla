---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, Ext
VARIABLE x
Foo == 1
Foo1(a) == a
FooF[i \in 1..2] == i
I == INSTANCE N2 WITH K <- Bar
Init == x = I!Op - 43
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
====
