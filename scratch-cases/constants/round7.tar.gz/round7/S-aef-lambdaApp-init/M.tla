---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == IF AssertEq(1, 2) THEN 0 ELSE 1
Ap(Op(_)) == Op(1)
K == Ap(LAMBDA q : C + q)

Init == x = 0 /\ PrintT(K)
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
