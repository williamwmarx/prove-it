---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mv, mv2
VARIABLE x

Init == x = 0 /\ AssertEq(mv, mv2)
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
