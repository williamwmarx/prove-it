---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets, Ext
VARIABLE x

D == IF ~AssertEq(1, 2) THEN 1 ELSE 0
Po == C = 1
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
