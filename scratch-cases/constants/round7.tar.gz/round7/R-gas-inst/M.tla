---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == TLCGetAndSet(7, +, 1, 1)
I == INSTANCE N2 WITH K <- C
Init == x = I!Op - 2
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
