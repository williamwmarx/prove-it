---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, Ext
CONSTANT CN
VARIABLE x
Foo == 1
Foo1(a) == a
FooF[i \in 1..2] == i

Init == x = CN - 42
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
====
