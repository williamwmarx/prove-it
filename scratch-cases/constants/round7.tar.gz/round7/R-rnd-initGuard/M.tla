---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == RandomElement({1})

Init == x = 0 /\ C > 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
