---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D0 == IF TLCGetAndSet(7, +, 1, 0) >= 0 THEN 1 ELSE 0
D == D0

Init == x = C - 1
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
