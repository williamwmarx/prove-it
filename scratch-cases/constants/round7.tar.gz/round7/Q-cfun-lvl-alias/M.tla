---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == [i \in 1..2 |-> 1]
D[i \in 1..2] == IF PrintT(TLCGet("level")) THEN 1 ELSE 0
Al == [x |-> x, c |-> C[1]]
Inv == x < 2
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
