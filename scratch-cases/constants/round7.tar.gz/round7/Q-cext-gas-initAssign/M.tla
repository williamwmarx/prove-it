---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets, Ext
VARIABLE x

D == IF TLCGetAndSet(7, +, 1, 0) >= 0 THEN 1 ELSE 0

Init == x = C - 1
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
