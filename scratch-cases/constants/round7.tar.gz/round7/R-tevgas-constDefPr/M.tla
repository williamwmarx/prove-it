---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == TLCEval(TLCGetAndSet(7, +, 1, 1))
K == PrintT(C)
Init == x = 0 /\ K
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
