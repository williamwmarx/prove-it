---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x

Init == x = 0 /\ \A i \in 1..3 : TRUE \/ AssertEq(i, 2)
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
