---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == IF PrintT("d") THEN 1 ELSE 0
K0 == C
K == K0 + 1

Init == x = 0 /\ (IF FALSE THEN PrintT(K) ELSE TRUE)
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
