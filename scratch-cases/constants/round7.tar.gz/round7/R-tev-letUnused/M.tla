---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == TLCEval(IF PrintT("d") THEN 1 ELSE 0)

Init == x = 0
Next == LET q == C IN x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
