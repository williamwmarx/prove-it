---- MODULE Ext ----
EXTENDS Ext2
Bar == 1
====
