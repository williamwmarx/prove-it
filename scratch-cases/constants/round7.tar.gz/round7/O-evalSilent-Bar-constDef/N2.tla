---- MODULE N2 ----
EXTENDS Naturals
CONSTANT K
Op == K + 1
====
