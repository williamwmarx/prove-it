---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, Ext
VARIABLE x
Foo == 1
Foo1(a) == a
FooF[i \in 1..2] == i
K == Bar + 1
Init == x = K - 43
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
====
