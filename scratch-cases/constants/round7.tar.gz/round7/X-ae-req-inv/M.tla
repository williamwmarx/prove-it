---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mv, mv2
VARIABLE x
Inv == x >= 0 /\ AssertEq([a |-> 1, b |-> 2], [b |-> 2, a |-> 1])
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
