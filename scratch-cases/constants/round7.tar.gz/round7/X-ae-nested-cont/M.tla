---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mv, mv2
VARIABLE x
Inv == x < 1 /\ (AssertEq([a |-> <<1, {2}>>], [a |-> <<1, {3}>>]) \/ TRUE)
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
