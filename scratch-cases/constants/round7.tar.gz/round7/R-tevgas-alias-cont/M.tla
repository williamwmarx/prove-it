---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == TLCEval(TLCGetAndSet(7, +, 1, 1))
Al == [x |-> x, c |-> C]
Inv == x < 2
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
