---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, Ext
VARIABLE x
I3 == INSTANCE N3
IE == INSTANCE Ext
Cs == I3!Op3P(1) # 0
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
====
