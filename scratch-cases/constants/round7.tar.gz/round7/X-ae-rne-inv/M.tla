---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mv, mv2
VARIABLE x
Inv == x >= 0 /\ AssertEq([a |-> 1], [a |-> 2])
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
