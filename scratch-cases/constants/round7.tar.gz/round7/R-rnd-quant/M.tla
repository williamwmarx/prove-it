---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == RandomElement({1})

Init == x = 0
Next == \E i \in 1..C : x' = (x + i) % 3
Spec == Init /\ [][Next]_x

====
