---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == IF AssertEq(<<1>>, <<1>>) THEN 1 ELSE 0
RECURSIVE R(_)
R(n) == IF n = 0 THEN C ELSE R(n - 1)
Init == x = R(2) - 1
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
