---- MODULE Ext ----
EXTENDS Naturals, TLC, TLCExt
D == IF TLCGetAndSet(7, +, 1, 0) >= 0 THEN 1 ELSE 0
====
