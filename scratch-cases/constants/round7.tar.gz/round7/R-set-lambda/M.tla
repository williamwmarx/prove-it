---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
D == IF TLCSet(7, 5) THEN 1 ELSE 0
Ap(Op(_), v) == Op(v)
Init == x = 0
Next == x' = Ap(LAMBDA a : (x + a) % 3, C)
Spec == Init /\ [][Next]_x

====
