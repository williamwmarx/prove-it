---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 1
C2 == C
D == IF PrintT("d") THEN 1 ELSE 0

Init == x = 0
Next == x' = (x + C2) % 3
Spec == Init /\ [][Next]_x

====
