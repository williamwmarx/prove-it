---- MODULE E1 ----
EXTENDS E2
C == 0

====
