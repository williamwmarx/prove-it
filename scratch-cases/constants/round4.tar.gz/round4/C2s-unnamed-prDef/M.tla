---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 0
D == 1
ASSUME C = 1
INSTANCE P
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
