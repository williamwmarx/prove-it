---- MODULE E1 ----
EXTENDS E2
D == PrintT("d")

====
