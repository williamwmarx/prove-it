---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT F(_)
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
FD(a) == a * 10
ASSUME PrintT(F(1))

====
