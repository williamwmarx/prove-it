---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
MyPrint(a) == PrintT(a)
C == 0
D == TLCEval(MyPrint(5))
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x
Ins == INSTANCE I WITH Q <- C
ASSUME Ins!R

====
