---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TLCEval(TLCSet(3, 5)) /\ TLCGet(3) = 5
Init == x = 0 /\ PrintT(C)
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
