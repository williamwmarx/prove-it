---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
MyPrint(a) == PrintT(a)
MyEq(a, b) == AssertEq(a, b)
C == 0
D == TLCSet(1, 5)
Init == x = 0 /\ C = C
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
