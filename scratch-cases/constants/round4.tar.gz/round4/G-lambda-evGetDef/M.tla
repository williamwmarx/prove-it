---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
MyPrint(a) == PrintT(a)
C == 0
D == TLCEval(TLCGetOrDefault(3, 0))
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x
Ap(F(_)) == F(1)
ASSUME Ap(LAMBDA i: C) = C

====
