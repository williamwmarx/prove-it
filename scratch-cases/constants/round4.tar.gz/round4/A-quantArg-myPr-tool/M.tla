---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
MyPrint(a) == PrintT(a)
MyEq(a, b) == AssertEq(a, b)
C == 0
D == MyPrint("d")
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
Op(S) == \A i \in 1..2 : S = S
ASSUME Op(C)

====
