---- MODULE E1 ----
EXTENDS E2
D == TLCEval(PrintT("d"))

====
