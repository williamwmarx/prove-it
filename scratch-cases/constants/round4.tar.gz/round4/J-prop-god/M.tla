---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 0
D == TLCGetOrDefault(3, 0)
Pr == [](C = C)
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
