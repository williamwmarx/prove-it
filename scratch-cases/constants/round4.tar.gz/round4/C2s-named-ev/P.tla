---- MODULE P ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
PD == TLCEval(PrintT("p"))

====
