---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
MyPrint(a) == PrintT(a)
MyEq(a, b) == AssertEq(a, b)
C == 0
D == IF TRUE THEN TLCEval(PrintT(2)) ELSE 3
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
ASSUME LET L(i) == C = C IN L(1) /\ L(2)

====
