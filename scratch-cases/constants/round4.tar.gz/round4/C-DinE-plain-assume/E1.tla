---- MODULE E1 ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
D == 7

====
