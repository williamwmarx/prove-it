---- MODULE P ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT N
PD == PrintT(N)

====
