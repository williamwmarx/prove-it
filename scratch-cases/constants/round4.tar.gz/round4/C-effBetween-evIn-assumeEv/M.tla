---- MODULE M ----
EXTENDS E1, Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 0
P == PrintT("between")
ASSUME P
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x
ASSUME TLCEval(C) = C

====
