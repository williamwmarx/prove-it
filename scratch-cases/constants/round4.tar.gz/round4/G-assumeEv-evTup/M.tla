---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
MyPrint(a) == PrintT(a)
C == 0
D == TLCEval(<<PrintT(1), PrintT(2)>>)
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x
ASSUME TLCEval(C) = C

====
