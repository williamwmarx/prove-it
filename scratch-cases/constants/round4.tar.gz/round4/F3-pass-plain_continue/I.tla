---- MODULE I ----
EXTENDS Naturals, TLC
CONSTANT Lim
IC == 1
ID == 0
IInv == IC < Lim
====
