---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
MyPrint(a) == PrintT(a)
C == 0
D == TLCEval(PrintT("d"))
Init == x \in {0} /\ C = C
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
