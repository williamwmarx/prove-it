---- MODULE E1 ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
D == <<TLCEval(PrintT("e")), 1>>
ASSUME PrintT("E1")

====
