---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == 0
D(a) == AssertEq(a, 0)
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x
ASSUME \A i \in 1..2 : C(i) = C(i)

====
