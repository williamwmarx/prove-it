---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT K
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
Al == [x |-> x]
D == IF TRUE THEN [a |-> 1] ELSE [a |-> 2]
Inv == x < 2

====
