---- MODULE I ----
CONSTANT Q
R == Q = Q
====
