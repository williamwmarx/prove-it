---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
MyPrint(a) == PrintT(a)
C == 0
D == LET q == TLCEval(PrintT(1)) IN q
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x
ASSUME C = C
ASSUME C = C

====
