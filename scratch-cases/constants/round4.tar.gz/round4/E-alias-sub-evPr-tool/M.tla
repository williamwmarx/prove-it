---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT K
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
Al == [x |-> x]
D == [x |-> TLCEval(PrintT(1))]
Inv == x < 2

====
