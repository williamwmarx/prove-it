---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
ASSUME TLCSet(3, 0)
C == 0
D == TLCGetOrDefault(3, 0)
Inv == C = C
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
