---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
MyPrint(a) == PrintT(a)
C == 0
D == TLCEval(PrintT("d"))
Init == x = 0
Next == x' = (x + 1) % 2 /\ C = C
Spec == Init /\ [][Next]_x

====
