---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT W
VARIABLE x
D == TLCGet("level")
Inv == W = W
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
