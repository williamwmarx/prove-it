---- MODULE E1 ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
D == TLCSet(1, 4)

====
