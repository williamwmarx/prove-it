---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
MyPrint(a) == PrintT(a)
MyEq(a, b) == AssertEq(a, b)
C == 0
D == {TLCEval(PrintT(1))}
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
f[n \in 0..2] == IF n = 0 THEN C ELSE f[n-1]
ASSUME f[2] = f[2]

====
