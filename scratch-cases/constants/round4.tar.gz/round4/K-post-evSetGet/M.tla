---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TLCEval(TLCSet(3, 5)) /\ TLCGet(3) = 5
Post == PrintT(C) = PrintT(C)
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
