---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT K
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ (K = 2) /\ [][Next]_x
Inv == x < 2

====
