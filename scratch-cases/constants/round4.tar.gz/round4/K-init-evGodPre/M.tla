---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TLCEval(TLCGetOrDefault(4, 7))
Init == x = 0 /\ PrintT(C)
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
