---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
INSTANCE P WITH N <- 3
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
