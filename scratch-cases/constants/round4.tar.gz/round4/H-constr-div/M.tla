---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT K
VARIABLE x
C == x < 10
Inv == x < 2
D == 1 \div 0 = 0
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
