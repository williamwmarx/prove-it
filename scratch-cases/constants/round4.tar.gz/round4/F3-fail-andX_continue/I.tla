---- MODULE I ----
EXTENDS Naturals, TLC
CONSTANT Lim
IC == 1
ID == 9
IInv == IC < Lim
====
