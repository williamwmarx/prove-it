---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
MyPrint(a) == PrintT(a)
MyEq(a, b) == AssertEq(a, b)
C == 0
D == TLCGetAndSet(1, LAMBDA a, b: a + b, 3, 0)
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
Ins == INSTANCE I WITH Q <- C
ASSUME Ins!R

====
