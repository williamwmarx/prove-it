---- MODULE E1 ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
D == TLCEval(PrintT("d"))
C == 0

====
