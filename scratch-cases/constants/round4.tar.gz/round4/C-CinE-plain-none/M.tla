---- MODULE M ----
EXTENDS E1, Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
D == 7
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
