---- MODULE I ----
EXTENDS Naturals, TLC
CONSTANT Lim
IC == 1
ID == TLCEval(PrintT(0))
IInv == IC < Lim
====
