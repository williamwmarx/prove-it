---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
MyPrint(a) == PrintT(a)
MyEq(a, b) == AssertEq(a, b)
C == 0
D == RandomElement({1})
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
RECURSIVE R(_)
R(n) == IF n = 0 THEN C ELSE R(n-1)
ASSUME R(2) = R(2)

====
