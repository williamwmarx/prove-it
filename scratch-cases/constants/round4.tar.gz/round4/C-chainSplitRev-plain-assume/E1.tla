---- MODULE E1 ----
EXTENDS E2
D == 7

====
