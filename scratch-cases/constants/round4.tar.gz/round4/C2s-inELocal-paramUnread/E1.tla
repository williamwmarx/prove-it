---- MODULE E1 ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
LOCAL INSTANCE P WITH N <- 3
EE == 1

====
