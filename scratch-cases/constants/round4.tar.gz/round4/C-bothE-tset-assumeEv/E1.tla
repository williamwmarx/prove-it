---- MODULE E1 ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
C == 0
D == TLCSet(1, 4)

====
