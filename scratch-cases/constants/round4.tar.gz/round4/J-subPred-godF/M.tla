---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == TLCGetOrDefault(3, 0) = 1 = TLCGetOrDefault(3, 0) = 1
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
