---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == 0
D(a) == AssertEq(a, a)
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x
ASSUME C(1) = C(1)

====
