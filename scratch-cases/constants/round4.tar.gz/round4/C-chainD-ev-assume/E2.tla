---- MODULE E2 ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
D == TLCEval(PrintT("d"))

====
