---- MODULE M ----
EXTENDS E1, Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == 0
Init == x = 0 /\ C = C
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
