---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT K
CONSTANT W
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
WD == TLCEval(PrintT(4))
Al == [x |-> x, w |-> W]
Inv == x < 2

====
