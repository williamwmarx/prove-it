---- MODULE I ----
EXTENDS Naturals, TLC
CONSTANT Lim
IC == 1
ID == PrintT(9)
IInv == IC < Lim
====
