---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
ASSUME TLCSet(3, 0)
Inv == TLCGet(3) = TLCGet(3)
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
