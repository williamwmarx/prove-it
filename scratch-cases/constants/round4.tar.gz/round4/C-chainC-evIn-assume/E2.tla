---- MODULE E2 ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
C == 0

====
