---- MODULE E1 ----
EXTENDS E2
Y == 1

====
