---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT K
CONSTANT W
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
WD == 1 \div 0
Sy == IF W = 0 THEN {} ELSE Permutations({1})

====
