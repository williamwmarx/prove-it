---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
MyPrint(a) == PrintT(a)
MyEq(a, b) == AssertEq(a, b)
C == 0
D == JavaTime > 0
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
Ap(F(_)) == F(1)
ASSUME Ap(LAMBDA i: C = C)

====
