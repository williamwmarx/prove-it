---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT S
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
