---- MODULE P ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
PD == PrintT("p")
ASSUME PD

====
