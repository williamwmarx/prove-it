---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == LET q == TLCEval(TLCGetAndSet(3, LAMBDA a, b: a + b, 1, 0)) IN q
Init == x = 0 /\ C = C
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
