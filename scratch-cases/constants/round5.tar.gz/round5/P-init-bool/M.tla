---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mA, mB
VARIABLE x
A == x > 5
B == FALSE
Init == x = 0
Next == x' = (x + 1) % 3
Init2 == x = 0 /\ AssertEq(A, B)
Spec == Init2 /\ [][Next]_x

====
