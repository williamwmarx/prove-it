---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 4 /\ TLCGetAndSet(1, LAMBDA o, v: o \cup {v}, x, {}) = TLCGet(1) \/ TRUE

Spec == Init /\ [][Next]_x

====
