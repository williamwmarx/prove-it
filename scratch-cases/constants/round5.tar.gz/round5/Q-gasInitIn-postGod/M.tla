---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 4
Init2 == x \in {TLCGetAndSet(1, +, 1, 0), TLCGetAndSet(1, +, 1, 0)}
Post == PrintT(TLCGetOrDefault(1, "none")) = PrintT(TLCGetOrDefault(1, "none"))
Spec == Init2 /\ [][Next]_x

====
