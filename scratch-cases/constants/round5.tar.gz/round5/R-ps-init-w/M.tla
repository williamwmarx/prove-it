---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x \in 0..1
Next == x' = (x + 1) % 3
Init2 == x \in 0..1 /\ PickSuccessor(TRUE)
Spec == Init2 /\ [][Next]_<<x>>

====
