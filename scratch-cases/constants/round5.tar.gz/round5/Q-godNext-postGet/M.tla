---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 4 /\ TLCGetOrDefault(1, 7) = 7
Post == PrintT(TLCGet(1)) = PrintT(TLCGet(1))
Spec == Init /\ [][Next]_x

====
