---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x, y
Init == x \in 0..1 /\ y = 0
Next == x' = (x + 1) % 3 /\ y' = y
Ac == PickSuccessor(TRUE)
Spec == Init /\ [][Next]_<<x, y>>

====
