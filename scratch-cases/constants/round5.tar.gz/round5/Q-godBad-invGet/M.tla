---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 4 /\ TLCGetOrDefault("nosuch", 3) = 3
Inv2 == TLCGetOrDefault(1, 0) < 3
Spec == Init /\ [][Next]_x

====
