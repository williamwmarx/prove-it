---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mA, mB
VARIABLE x
A == mA
B == mA
Init == x = 0
Next == x' = (x + 1) % 3
Ac == AssertEq(A, B)
Spec == Init /\ [][Next]_x

====
