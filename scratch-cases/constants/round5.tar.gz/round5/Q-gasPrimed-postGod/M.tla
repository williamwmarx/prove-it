---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = TLCGetAndSet(1, +, 1, 0) % 4
Post == PrintT(TLCGetOrDefault(1, "none")) = PrintT(TLCGetOrDefault(1, "none"))
Spec == Init /\ [][Next]_x

====
