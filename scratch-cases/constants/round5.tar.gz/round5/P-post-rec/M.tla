---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mA, mB
VARIABLE x
A == [a |-> 2, b |-> "s"]
B == [b |-> "s", a |-> 2]
Init == x = 0
Next == x' = (x + 1) % 3
Post == AssertEq(<<A>>, <<B>>)
Spec == Init /\ [][Next]_x

====
