---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x, y
vars == <<x, y>>
Init == x = 0 /\ y = 1 /\ LET z == x IN UNCHANGED z
Next == x' = (x + 1) % 2 /\ y' = y
Spec == Init /\ [][Next]_vars

====
