---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 4 /\ TLCGetAndSet("k", \o, "a", "") # "zz"

Spec == Init /\ [][Next]_x
InvC == x < 2

====
