---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 3
Init2 == x = 0 /\ PickSuccessor(TRUE)
Spec == Init2 /\ [][Next]_<<x>>

====
