---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 4
Init2 == x = TLCGetAndSet(1, +, 1, 0)
Inv2 == TLCGetOrDefault(1, 0) < 3
Spec == Init2 /\ [][Next]_x

====
