---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mA, mB
VARIABLE x
A == [a |-> x, b |-> "s"]
B == [b |-> "s", a |-> x]
Init == x = 0
Next == x' = (x + 1) % 3
Co == AssertEq(A, B) \/ x = 0
Spec == Init /\ [][Next]_x

====
