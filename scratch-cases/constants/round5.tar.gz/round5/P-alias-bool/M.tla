---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mA, mB
VARIABLE x
A == x > 5
B == FALSE
Init == x = 0
Next == x' = (x + 1) % 3
Al == [v |-> AssertEq(A, B), x |-> x]
Inv == x < 2
Spec == Init /\ [][Next]_x

====
