---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mA, mB
VARIABLE x
A == [n \in {1,3} |-> n]
B == <<1, 3>>
Init == x = 0
Next == x' = (x + 1) % 3
Al == [v |-> AssertEq(A, B), x |-> x]
Inv == x < 2
Spec == Init /\ [][Next]_x

====
