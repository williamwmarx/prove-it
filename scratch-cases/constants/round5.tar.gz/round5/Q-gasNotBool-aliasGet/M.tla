---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 4 /\ TLCGetAndSet(1, +, 1, 0)
Al == [x |-> x, r |-> TLCGetOrDefault(1, "u")]
Inv2 == x < 3
Spec == Init /\ [][Next]_x

====
