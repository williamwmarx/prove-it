---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == PickSuccessor(TRUE) /\ x' = (x + 1) % 3
Spec == Init /\ [][Next]_<<x>>

====
