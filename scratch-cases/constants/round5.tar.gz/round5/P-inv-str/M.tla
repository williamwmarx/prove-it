---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mA, mB
VARIABLE x
A == "a\"b\\c"
B == "a\"b\\c"
Init == x = 0
Next == x' = (x + 1) % 3
Inv == AssertEq(A, B)
Spec == Init /\ [][Next]_x

====
