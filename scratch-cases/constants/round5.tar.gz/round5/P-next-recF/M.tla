---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mA, mB
VARIABLE x
A == [a |-> x]
B == [a |-> x, b |-> 1]
Init == x = 0
Next == x' = (x + 1) % 3 /\ AssertEq(A, B)
Spec == Init /\ [][Next]_x

====
