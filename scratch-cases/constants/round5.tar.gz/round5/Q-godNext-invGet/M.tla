---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 4 /\ TLCGetOrDefault(1, 7) = 7
Inv2 == TLCGetOrDefault(1, 0) < 3
Spec == Init /\ [][Next]_x

====
