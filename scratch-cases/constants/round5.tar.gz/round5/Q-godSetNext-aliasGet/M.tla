---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 4 /\ TLCSet(1, TLCGetOrDefault(1, 0) + 1)
Al == [x |-> x, r |-> TLCGetOrDefault(1, "u")]
Inv2 == x < 3
Spec == Init /\ [][Next]_x

====
