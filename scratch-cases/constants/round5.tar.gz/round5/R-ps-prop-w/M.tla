---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x \in 0..1
Next == x' = (x + 1) % 3
Pr == [][PickSuccessor(TRUE)]_x
Spec == Init /\ [][Next]_<<x>>

====
