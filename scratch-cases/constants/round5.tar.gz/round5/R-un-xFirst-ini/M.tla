---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x, y
vars == <<x, y>>
Init == UNCHANGED x /\ x = 0
Next == x' = (x + 1) % 2 /\ y' = y
Spec == Init /\ [][Next]_vars

====
