---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mA, mB
VARIABLE x
A == <<x, "t">>
B == Append(<<x>>, "t")
Init == x = 0
Next == x' = (x + 1) % 3
Co == AssertEq(A, B) \/ x = 0
Spec == Init /\ [][Next]_x

====
