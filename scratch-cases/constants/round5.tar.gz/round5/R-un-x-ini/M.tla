---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x, y
vars == <<x, y>>
Init == x = 0 /\ UNCHANGED x
Next == x' = (x + 1) % 2 /\ y' = y
Spec == Init /\ [][Next]_vars

====
