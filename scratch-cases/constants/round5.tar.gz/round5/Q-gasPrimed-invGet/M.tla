---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = TLCGetAndSet(1, +, 1, 0) % 4
Inv2 == TLCGetOrDefault(1, 0) < 3
Spec == Init /\ [][Next]_x

====
