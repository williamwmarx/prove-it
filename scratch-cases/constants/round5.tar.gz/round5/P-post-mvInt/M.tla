---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mA, mB
VARIABLE x
A == mA
B == 2
Init == x = 0
Next == x' = (x + 1) % 3
Post == AssertEq(<<A>>, <<B>>)
Spec == Init /\ [][Next]_x

====
