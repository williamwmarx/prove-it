---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mA, mB
VARIABLE x
A == "a\"b\\c"
B == "a\"b\\c"
Init == x = 0
Next == x' = (x + 1) % 3
Init2 == x = 0 /\ AssertEq(A, B)
Spec == Init2 /\ [][Next]_x

====
