---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x, y
vars == <<x, y>>
Init == x \in 0..1 /\ y = 1 /\ UNCHANGED y
Next == x' = (x + 1) % 2 /\ y' = y
Spec == Init /\ [][Next]_vars

====
