---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 4 /\ TLCGetOrDefault("nosuch", 3) = 3
Post == PrintT(TLCGetOrDefault(1, "none")) = PrintT(TLCGetOrDefault(1, "none"))
Spec == Init /\ [][Next]_x

====
