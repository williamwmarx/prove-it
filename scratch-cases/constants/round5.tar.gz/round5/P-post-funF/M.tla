---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mA, mB
VARIABLE x
A == [n \in {1,3} |-> n]
B == <<1, 3>>
Init == x = 0
Next == x' = (x + 1) % 3
Post == AssertEq(<<A>>, <<B>>)
Spec == Init /\ [][Next]_x

====
