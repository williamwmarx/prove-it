---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mA, mB
VARIABLE x
A == "1"
B == 1
Init == x = 0
Next == x' = (x + 1) % 3
Inv == AssertEq(A, B) \/ TRUE
Spec == Init /\ [][Next]_x

====
