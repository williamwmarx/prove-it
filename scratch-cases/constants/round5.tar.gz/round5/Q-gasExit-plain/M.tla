---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 4 /\ TLCGetAndSet("exit", LAMBDA o, v: v, x = 2, FALSE) \in BOOLEAN

Spec == Init /\ [][Next]_x

====
