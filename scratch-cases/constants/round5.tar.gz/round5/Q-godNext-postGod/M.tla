---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 4 /\ TLCGetOrDefault(1, 7) = 7
Post == PrintT(TLCGetOrDefault(1, "none")) = PrintT(TLCGetOrDefault(1, "none"))
Spec == Init /\ [][Next]_x

====
