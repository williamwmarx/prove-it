---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mA, mB
VARIABLE x
A == [n \in 1..2 |-> n + x]
B == <<1 + x, 2 + x>>
Init == x = 0
Next == x' = (x + 1) % 3
Inv == AssertEq(A, B) \/ TRUE
Spec == Init /\ [][Next]_x

====
