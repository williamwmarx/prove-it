---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT mA, mB
VARIABLE x
A == [a |-> 2]
B == [a |-> 2, b |-> 1]
Init == x = 0
Next == x' = (x + 1) % 3
Post == AssertEq(<<A>>, <<B>>)
Spec == Init /\ [][Next]_x

====
