---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 4 /\ TLCSet(1, x)
Inv == TLCGetOrDefault(1, -1) < 100

Spec == Init /\ [][Next]_x

====
