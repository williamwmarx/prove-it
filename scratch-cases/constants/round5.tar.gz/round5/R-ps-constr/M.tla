---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 3
Co == PickSuccessor(TRUE)
Spec == Init /\ [][Next]_<<x>>

====
