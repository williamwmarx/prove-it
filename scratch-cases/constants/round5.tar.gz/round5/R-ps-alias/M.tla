---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 3
Al == [x |-> x, p |-> PickSuccessor(TRUE)]
Inv == x < 2
Spec == Init /\ [][Next]_<<x>>

====
