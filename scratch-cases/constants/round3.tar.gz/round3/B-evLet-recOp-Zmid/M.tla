---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
C == 5
Z == PrintT("z")
D == TLCEval(LET q == PrintT("d") IN q)
RECURSIVE R(_)
R(n) == IF n = 0 THEN C ELSE R(n - 1)
Inv == R(2) = R(2)
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
