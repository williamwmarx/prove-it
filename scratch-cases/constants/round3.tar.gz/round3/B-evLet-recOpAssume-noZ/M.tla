---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
C == 5
D == TLCEval(LET q == PrintT("d") IN q)
RECURSIVE R(_)
R(n) == IF n = 0 THEN C ELSE R(n - 1)
ASSUME R(1) = R(1)
Inv == TRUE
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
