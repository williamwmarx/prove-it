---- MODULE M ----
EXTENDS Naturals, TLC, FiniteSets, E
CONSTANT K
VARIABLE x
D == CHOOSE b \in BOOLEAN : b
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
