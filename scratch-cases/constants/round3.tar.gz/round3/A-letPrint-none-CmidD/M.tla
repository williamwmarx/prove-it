---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
C == 5
Z == PrintT("z")
D == LET P == PrintT("d") IN P
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
