---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
C == 5
D == TLCEval(LET q == PrintT("d") IN q)
f[n \in 0..2] == IF n = 0 THEN C ELSE f[n - 1]
Inv == f[2] = f[2]
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
