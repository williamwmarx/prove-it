---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
C == 5
D == IF PrintT("d") THEN 1 ELSE 2
V == <<x, C>>
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
