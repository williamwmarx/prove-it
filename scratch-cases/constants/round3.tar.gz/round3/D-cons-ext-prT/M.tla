---- MODULE M ----
EXTENDS Naturals, TLC, FiniteSets, E
CONSTANT K
VARIABLE x
D == PrintT(TRUE)
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
