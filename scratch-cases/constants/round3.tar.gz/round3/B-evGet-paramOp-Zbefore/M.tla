---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Z == PrintT("z")
C == 5
D == TLCEval(TLCGet(1))
G(a) == <<C, a>>
Inv == G(1) = G(1)
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
