---- MODULE I ----
EXTENDS Naturals, TLC
C == 5
D == PrintT("d")
PI == PrintT("pi")
====
