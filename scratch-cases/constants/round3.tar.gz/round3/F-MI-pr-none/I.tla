---- MODULE I ----
EXTENDS Naturals, TLC
D == PrintT("d")
PI == PrintT("pi")
====
