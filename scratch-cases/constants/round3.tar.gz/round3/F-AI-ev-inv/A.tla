---- MODULE A ----
EXTENDS Naturals, TLC
C == 5
PA == PrintT("pa")
====
