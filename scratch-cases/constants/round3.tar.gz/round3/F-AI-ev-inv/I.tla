---- MODULE I ----
EXTENDS Naturals, TLC
D == TLCEval(PrintT("d"))
PI == PrintT("pi")
====
