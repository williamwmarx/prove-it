---- MODULE M ----
EXTENDS Naturals, TLC, FiniteSets
CONSTANT K
CONSTANT C
VARIABLE x
D == Print("p", FALSE)
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
