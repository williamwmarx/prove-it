---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT K
VARIABLE x
C == 5
D == 7
Inv == K = K
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
