---- MODULE I ----
EXTENDS Naturals, TLC
C == 5
PI == PrintT("pi")
====
