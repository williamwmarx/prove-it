---- MODULE A ----
EXTENDS Naturals, TLC
D == PrintT("d")
PA == PrintT("pa")
====
