---- MODULE M ----
EXTENDS Naturals, TLC, FiniteSets
CONSTANT K
CONSTANT C
VARIABLE x
D == 1 \div 0 = 1
Init == x = 0
Next == x' = (x + 1) % 3
Spec == C /\ Init /\ [][Next]_x

====
