---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
C == 5
D == TLCEval(TLCGet(1))
Inv == LET q == C IN q = q
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
