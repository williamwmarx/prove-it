---- MODULE A ----
EXTENDS Naturals, TLC
C == 5
D == RandomElement({1, 2})
PA == PrintT("pa")
====
