---- MODULE M ----
EXTENDS Naturals, TLC, FiniteSets
CONSTANT K
VARIABLE x
C == x < 10
D == LET Fst(a, b) == a IN Fst(FALSE, 1 \div 0)
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
