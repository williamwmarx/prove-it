---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
C == 5
D == TLCEval(PrintT("d"))
ASSUME LET C == 1 IN C = 1
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
