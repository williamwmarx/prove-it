---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
C == 5
D == TLCSet(1, 5)
E == LET C == 3 IN C
Inv == E = 3
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
