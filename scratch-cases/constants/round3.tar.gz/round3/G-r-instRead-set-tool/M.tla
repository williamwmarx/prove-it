---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
C == 5
D == TLCSet(1, 2)
Ins == INSTANCE I WITH Q <- C
Inv == Ins!R
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
