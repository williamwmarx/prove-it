---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
C == 5
D == [i \in 1..2 |-> PrintT(i)]
E == C
Inv == E = E
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
