---- MODULE I ----
EXTENDS Naturals, TLC
C == 5
D == TLCEval(PrintT("d"))
PI == PrintT("pi")
====
