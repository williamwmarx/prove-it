---- MODULE A ----
EXTENDS Naturals, TLC
C == 5
D == PrintT("d")
PA == PrintT("pa")
====
