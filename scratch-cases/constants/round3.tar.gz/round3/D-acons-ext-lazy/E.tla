---- MODULE E ----
EXTENDS Naturals
C == 3 < 10
====
