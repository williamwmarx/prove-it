---- MODULE M ----
EXTENDS Naturals, TLC, FiniteSets, E
CONSTANT K
VARIABLE x
D == LET Fst(a, b) == a IN Fst(TRUE, 1 \div 0)
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
