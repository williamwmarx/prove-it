---- MODULE I ----
EXTENDS Naturals, TLC
C == 5
D == RandomElement({1, 2})
PI == PrintT("pi")
====
