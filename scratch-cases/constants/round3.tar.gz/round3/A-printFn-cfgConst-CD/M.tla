---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT K
VARIABLE x
C == 5
D == [i \in 1..2 |-> PrintT(i)]
Inv == K = K
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
