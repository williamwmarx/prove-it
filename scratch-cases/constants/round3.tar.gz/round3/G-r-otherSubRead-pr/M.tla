---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
C == 5
D == PrintT("d")
E == C
F == 1
Inv == F = F
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
