---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Fst(a, b) == a
Twice(a) == <<a, a>>
Ign(a) == 1
InQ(a) == \A i \in 1..3 : a = a
InSet(a) == {a : i \in 1..3}
InFn(a) == [i \in 1..2 |-> a]
Nested(a) == Twice(a)
Cond(a, b) == IF a THEN b ELSE b
LetA(a) == LET q == a IN <<q, q>>
RECURSIVE Rec(_, _)
Rec(n, a) == IF n = 0 THEN a ELSE Rec(n - 1, a)
ASSUME Rec(2, RandomElement(1..1000)) = Rec(2, RandomElement(1..1000))
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
