---- MODULE M ----
EXTENDS Naturals, TLC, A
VARIABLE x
D == 7
PM == PrintT("pm")
In == INSTANCE I
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
Inv == In!C = In!C
C2 == In!C

====
