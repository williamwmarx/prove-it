---- MODULE M ----
EXTENDS Naturals, TLC, FiniteSets, E
CONSTANT K
VARIABLE x
D == x < 1
Init == x = 0
Next == x' = (x + 1) % 3
Spec == C /\ Init /\ [][Next]_x

====
