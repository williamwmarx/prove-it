---- MODULE A ----
EXTENDS Naturals, TLC
D == RandomElement({1, 2})
PA == PrintT("pa")
====
