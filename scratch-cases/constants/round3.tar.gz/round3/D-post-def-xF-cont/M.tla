---- MODULE M ----
EXTENDS Naturals, TLC, FiniteSets
CONSTANT K
VARIABLE x
C == x < 10
D == x < 1
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
