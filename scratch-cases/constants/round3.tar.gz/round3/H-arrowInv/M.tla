---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
P == PrintT("d")
Inv == x < 5
Inv2 == 1 = 1
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x
====
