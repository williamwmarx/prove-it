---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
C == 5
D == TLCGet("level")
E == C
F == 1
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
