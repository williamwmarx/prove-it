---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
FooB == TRUE
Inv == ~FooB
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x
====
