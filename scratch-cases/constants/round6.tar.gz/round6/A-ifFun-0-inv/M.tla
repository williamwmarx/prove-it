---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")

Init == x = 0
Next == x' = 1 - x
Inv == [i \in 1..2 |-> IF i = 1 THEN TRUE ELSE C][2]
Spec == Init /\ [][Next]_x

====
