---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT N
VARIABLE x
C(a) == TRUE
D(a) == PrintT(<<"d", a>>)
NV == 1
Init == x = 0 /\ (IF N = 1 THEN C(1) ELSE TRUE)
Next == x' = x

Spec == Init /\ [][Next]_x

====
