---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")
F(a) == IF a THEN TRUE ELSE C
Init == x = 0
Next == x' = x
ASSUME F(FALSE)
Spec == Init /\ [][Next]_x

====
