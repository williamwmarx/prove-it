---- MODULE Ext ----
Bar == 1
====
