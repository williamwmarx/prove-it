---- MODULE N ----
EXTENDS Naturals
CONSTANT K
Op == K + 1
====
