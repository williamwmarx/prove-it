---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")
F2(a, b) == a
Al == [x |-> x, c |-> F2(TRUE, C)]
Init == x = 0
Next == Al.x = x /\ x' = (x + 1) % 2

Spec == Init /\ [][Next]_x

====
