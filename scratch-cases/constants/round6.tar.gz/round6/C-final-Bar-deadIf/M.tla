---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, Ext
VARIABLE x
Foo == 1
Foo1(a) == a
FooF[i \in 1..2] == i
I == INSTANCE N WITH K <- 1

Init == x = 0 /\ (IF FALSE THEN PrintT(Bar) ELSE TRUE)
Next == x' = x

Spec == Init /\ [][Next]_x
====
