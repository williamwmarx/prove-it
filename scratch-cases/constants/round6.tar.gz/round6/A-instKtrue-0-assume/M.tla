---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")
I == INSTANCE N WITH K <- TRUE
Init == x = 0
Next == x' = x
ASSUME I!Op(C)
Spec == Init /\ [][Next]_x

====
