---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT S
VARIABLE x
Init == x = 0 /\ PrintT(S) /\ PrintT(ToString(S))
Next == x' = x
Inv == x = 0
Spec == Init /\ [][Next]_x

====
