---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == TRUE
D(a) == PrintT(<<"d", a>>)
K == TRUE
KF == FALSE
F(a) == IF K THEN a ELSE C(1)
Init == x = 0
Next == x' = 1 - x
Inv == F(TRUE)
Spec == Init /\ [][Next]_x

====
