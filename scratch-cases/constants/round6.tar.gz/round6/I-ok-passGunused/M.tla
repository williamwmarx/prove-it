---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Foo == 1
G(p, q) == p
F(a, b) == G(a, b)
Init == x = 0 /\ (F(TRUE, PrintT(Foo)))
Next == x' = x
Spec == Init /\ [][Next]_x
====
