---- MODULE M ----
EXTENDS Naturals, Sequences, TLC, Ext
VARIABLE x
Foo == 1
Foo1(a) == a
FooF[i \in 1..2] == i
I == INSTANCE N WITH K <- 1
G(a, b) == a
Init == x = 0 /\ PrintT(G(1, Foo))
Next == x' = x

Spec == Init /\ [][Next]_x
====
