---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x < 2 /\ x' = x + 1 /\ TLCGetAndSet(1, LAMBDA o, v : o + v, 1, "s") = 0

Spec == Init /\ [][Next]_x

====
