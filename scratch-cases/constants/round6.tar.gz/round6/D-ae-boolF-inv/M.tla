---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 2
Inv == AssertEq(TRUE, FALSE)
Spec == Init /\ [][Next]_x

====
