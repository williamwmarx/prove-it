---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
Init == x = 0
Next == x' = x + 1
Al == [x |-> x, e |-> AssertEq([a |-> 1, b |-> "s"], [b |-> "s", a |-> 1])]
Inv == x < 2
Spec == Init /\ [][Next]_x

====
