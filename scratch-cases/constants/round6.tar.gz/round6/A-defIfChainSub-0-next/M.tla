---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")
K == TRUE
KF == FALSE
K2 == K
E1 == IF K2 THEN TRUE ELSE C
Init == x = 0
Next == x' = 1 - x /\ (E1)

Spec == Init /\ [][Next]_x

====
