---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
I == INSTANCE N2 WITH K <- 3
Inv == I!Op

Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
