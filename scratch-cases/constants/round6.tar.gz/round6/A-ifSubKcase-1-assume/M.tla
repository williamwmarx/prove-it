---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == TRUE
D(a) == PrintT(<<"d", a>>)
K == TRUE
KF == FALSE
Init == x = 0
Next == x' = x
ASSUME CASE K -> TRUE [] OTHER -> C(1)
Spec == Init /\ [][Next]_x

====
