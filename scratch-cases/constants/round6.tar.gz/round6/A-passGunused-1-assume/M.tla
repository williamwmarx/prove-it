---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == TRUE
D(a) == PrintT(<<"d", a>>)
G(p, q) == p
F(a, b) == G(a, b)
Init == x = 0
Next == x' = x
ASSUME F(TRUE, C(1))
Spec == Init /\ [][Next]_x

====
