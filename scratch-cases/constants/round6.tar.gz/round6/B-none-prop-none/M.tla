---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")

Al == [x |-> x, c |-> TRUE]
Init == x = 0
Next == x' = x + 1
Pr == [](x < 2)
Spec == Init /\ [][Next]_x

====
