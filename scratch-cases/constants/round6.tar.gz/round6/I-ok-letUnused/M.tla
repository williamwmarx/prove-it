---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Foo == 1
F(a, b) == LET z == b IN a
Init == x = 0 /\ (F(TRUE, PrintT(Foo)))
Next == x' = x
Spec == Init /\ [][Next]_x
====
