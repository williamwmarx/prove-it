---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == TRUE
D(a) == PrintT(<<"d", a>>)
I == INSTANCE N WITH K <- FALSE
Init == x = 0 /\ (I!Op(C(1)))
Next == x' = x

Spec == Init /\ [][Next]_x

====
