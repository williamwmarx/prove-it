---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == TRUE
D(a) == PrintT(<<"d", a>>)

Init == x = 0
Next == x' = x
ASSUME {C(1) : i \in {1}} = {TRUE}
Spec == Init /\ [][Next]_x

====
