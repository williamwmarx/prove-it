---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")
K == TRUE
KF == FALSE
Al == [x |-> x, c |-> IF K THEN TRUE ELSE C]
Init == x = 0
Next == Al.x = x /\ x' = x + 1
Inv == x < 2
Spec == Init /\ [][Next]_x

====
