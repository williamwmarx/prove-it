---- MODULE M ----
EXTENDS Naturals, TLC
VARIABLE x
FooB == TRUE

Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x
====
