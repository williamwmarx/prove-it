---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Cj == TRUE
Dsub == PrintT("p")
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Cj /\ Init /\ [][Next]_x

====
