---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")
G == C
Al == [x |-> x, c |-> G]
Init == x = 0
Next == Al.x = x /\ x' = x + 1
Inv == x < 2
Spec == Init /\ [][Next]_x

====
