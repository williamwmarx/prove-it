---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == TRUE
D(a) == PrintT(<<"d", a>>)
G(p, q) == p
F(a, b) == G(a, b)
Init == x = 0 /\ (F(TRUE, C(1)))
Next == x' = x

Spec == Init /\ [][Next]_x

====
