---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")
Tr(q) == TRUE
Ap(Op(_), v) == Op(v)
Init == x = 0 /\ (Ap(Tr, C))
Next == x' = x

Spec == Init /\ [][Next]_x

====
