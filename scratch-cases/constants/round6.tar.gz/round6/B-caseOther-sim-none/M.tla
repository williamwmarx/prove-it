---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")

Al == [x |-> x, c |-> CASE FALSE -> TRUE [] OTHER -> C]
Init == x = 0
Next == x' = x + 1
Inv == x < 2
Spec == Init /\ [][Next]_x

====
