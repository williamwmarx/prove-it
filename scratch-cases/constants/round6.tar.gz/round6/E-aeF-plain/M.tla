---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
Inv == AssertEq(1, 2)

Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
