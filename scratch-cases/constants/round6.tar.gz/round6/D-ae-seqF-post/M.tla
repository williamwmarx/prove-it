---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 2
Post == AssertEq(<<1, <<2>>, {3}>>, <<1, <<2>>>>)
Spec == Init /\ [][Next]_x

====
