---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 2
Inv == AssertEq([f |-> [i \in 1..1 |-> {<<"x", MA>>}]], [f |-> <<{}>>])
Spec == Init /\ [][Next]_x

====
