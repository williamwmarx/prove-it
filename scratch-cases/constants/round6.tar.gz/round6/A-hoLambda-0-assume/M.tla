---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")
Ap(Op(_), v) == Op(v)
Init == x = 0
Next == x' = x
ASSUME Ap(LAMBDA q : q, C)
Spec == Init /\ [][Next]_x

====
