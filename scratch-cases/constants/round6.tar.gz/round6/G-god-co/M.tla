---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Co == TRUE
Dsub == TLCGetOrDefault(1, TRUE)
Init == x = 0
Next == x' = (x + 1) % 3
Spec == Init /\ [][Next]_x

====
