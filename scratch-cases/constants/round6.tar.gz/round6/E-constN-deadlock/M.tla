---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB, N
VARIABLE x
Inv == N = 1

Init == x = 0
Next == x < 1 /\ x' = x + 1
Spec == Init /\ [][Next]_x

====
