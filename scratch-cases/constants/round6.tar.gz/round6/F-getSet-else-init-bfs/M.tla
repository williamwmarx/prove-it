---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
C == TRUE
D == PrintT("d")
Init == TLCSet(1, FALSE) /\ x = 0 /\ (IF TLCGet(1) THEN TRUE ELSE C)
Next == x' = x

Spec == Init /\ [][Next]_x

====
