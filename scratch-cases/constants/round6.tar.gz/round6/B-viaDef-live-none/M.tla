---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")
G == C
Al == [x |-> x, c |-> G]
Init == x = 0
Next == x' = (x + 1) % 3
Pr == <>(x = 9)
Spec == Init /\ [][Next]_x /\ WF_x(Next)

====
