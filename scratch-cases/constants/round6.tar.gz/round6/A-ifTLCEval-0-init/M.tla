---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")

Init == x = 0 /\ (IF TLCEval(FALSE) THEN TRUE ELSE C)
Next == x' = x

Spec == Init /\ [][Next]_x

====
