---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == TRUE
D(a) == PrintT(<<"d", a>>)
RECURSIVE R(_, _)
R(n, c) == IF n = 0 THEN TRUE ELSE R(n - 1, c)
Init == x = 0
Next == x' = x
ASSUME R(2, C(1))
Spec == Init /\ [][Next]_x

====
