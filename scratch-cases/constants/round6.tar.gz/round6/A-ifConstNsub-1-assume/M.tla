---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT N
VARIABLE x
C(a) == TRUE
D(a) == PrintT(<<"d", a>>)
NV == 1
Init == x = 0
Next == x' = x
ASSUME IF N = 1 THEN C(1) ELSE TRUE
Spec == Init /\ [][Next]_x

====
