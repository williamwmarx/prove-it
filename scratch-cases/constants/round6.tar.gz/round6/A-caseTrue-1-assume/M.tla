---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == TRUE
D(a) == PrintT(<<"d", a>>)

Init == x = 0
Next == x' = x
ASSUME CASE TRUE -> C(1) [] OTHER -> TRUE
Spec == Init /\ [][Next]_x

====
