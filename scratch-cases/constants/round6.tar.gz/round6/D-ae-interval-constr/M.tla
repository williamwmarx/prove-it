---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 2
Co == AssertEq(1..3, {1, 2, 3})
Spec == Init /\ [][Next]_x

====
