---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")

Init == x = 0
Next == x' = x
ASSUME IF 3 \in DOMAIN <<1, 2>> THEN TRUE ELSE C
Spec == Init /\ [][Next]_x

====
