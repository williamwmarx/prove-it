---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == TRUE
D(a) == PrintT(<<"d", a>>)
Ap2(Op(_)) == TRUE
Init == x = 0 /\ (Ap2(LAMBDA q : C(1)))
Next == x' = x

Spec == Init /\ [][Next]_x

====
