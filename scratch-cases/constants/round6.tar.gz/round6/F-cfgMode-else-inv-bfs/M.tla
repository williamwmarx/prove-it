---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
C == TRUE
D == PrintT("d")
Init == x = 0
Next == x' = 1 - x
Inv == IF TLCGet("config").mode = "bfs" THEN TRUE ELSE C
Spec == Init /\ [][Next]_x

====
