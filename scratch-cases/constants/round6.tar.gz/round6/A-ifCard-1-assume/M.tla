---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == TRUE
D(a) == PrintT(<<"d", a>>)
K == Cardinality({1, 2}) = 2
Init == x = 0
Next == x' = x
ASSUME IF K THEN C(1) ELSE TRUE
Spec == Init /\ [][Next]_x

====
