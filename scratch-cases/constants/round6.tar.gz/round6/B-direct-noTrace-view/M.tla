---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")

Al == [x |-> x, c |-> C]
Init == x = 0
Next == x' = (x + 1) % 2

Spec == Init /\ [][Next]_x

====
