---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")

Init == x = 0
Next == x' = 1 - x /\ (CASE 1 = 2 -> TRUE [] 2 = 2 -> C)

Spec == Init /\ [][Next]_x

====
