---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
Inv == \A i \in 1..3 : i > 0

Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
