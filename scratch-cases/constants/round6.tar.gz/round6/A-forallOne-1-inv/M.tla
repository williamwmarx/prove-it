---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == TRUE
D(a) == PrintT(<<"d", a>>)

Init == x = 0
Next == x' = 1 - x
Inv == \A i \in {1} : C(1)
Spec == Init /\ [][Next]_x

====
