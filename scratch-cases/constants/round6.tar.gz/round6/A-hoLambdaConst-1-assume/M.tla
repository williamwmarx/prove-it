---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == TRUE
D(a) == PrintT(<<"d", a>>)
Ap(Op(_), v) == Op(v)
Init == x = 0
Next == x' = x
ASSUME Ap(LAMBDA q : TRUE, C(1))
Spec == Init /\ [][Next]_x

====
