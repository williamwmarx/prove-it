---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets, E2
CONSTANT MA, MB
VARIABLE x


Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
