---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")

Init == x = 0
Next == x' = 1 - x /\ (CASE FALSE -> TRUE [] OTHER -> C)

Spec == Init /\ [][Next]_x

====
