---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")
RK == RandomElement({FALSE})
Init == x = 0
Next == x' = 1 - x
Inv == IF RK THEN TRUE ELSE C
Spec == Init /\ [][Next]_x

====
