---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Init == x = 0
Next == x < 4 /\ TLCGetAndSet(1, LAMBDA o, v : o + v, 1, 0) >= 0 /\ x' = x + 1
Inv == PrintT(<<x, TLCGet(1)>>)
Spec == Init /\ [][Next]_x

====
