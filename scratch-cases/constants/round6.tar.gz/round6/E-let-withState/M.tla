---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
Inv == LET a == 1 IN a = 1
Inv2 == x < 5
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
