---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Add(o, v) == o + v
Init == x = 0
Next == x < 3 /\ x' = TLCGetAndSet("s:c", Add, 2, 10)
Inv == PrintT(TLCGetOrDefault("s:c", -1))
Spec == Init /\ [][Next]_x

====
