---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")

Al == [x |-> x, c |-> IF FALSE THEN C ELSE TRUE]
Init == x = 0
Next == x' = x + 1 /\ Assert(x < 2, "boom")

Spec == Init /\ [][Next]_x

====
