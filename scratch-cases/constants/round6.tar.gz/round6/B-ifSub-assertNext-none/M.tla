---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")
K == TRUE
KF == FALSE
Al == [x |-> x, c |-> IF K THEN TRUE ELSE C]
Init == x = 0
Next == x' = x + 1 /\ Assert(x < 2, "boom")

Spec == Init /\ [][Next]_x

====
