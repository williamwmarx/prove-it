---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
C == TRUE
D == PrintT("d")
Init == TLCSet(1, FALSE) /\ x = 0
Next == x' = 1 - x /\ (IF TLCGet(1) THEN C ELSE TRUE)

Spec == Init /\ [][Next]_x

====
