---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")
G(p, q) == q
F(a, b) == G(a, b)
Init == x = 0 /\ (F(TRUE, C))
Next == x' = x

Spec == Init /\ [][Next]_x

====
