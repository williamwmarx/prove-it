---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
C == TRUE
D == PrintT("d")
Init == x = 0 /\ (IF TLCGet("config").deadlock THEN TRUE ELSE C)
Next == x' = x

Spec == Init /\ [][Next]_x

====
