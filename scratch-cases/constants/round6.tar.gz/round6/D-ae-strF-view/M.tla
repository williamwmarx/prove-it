---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 2
Vw == <<x, AssertEq("a\"b\\c", "a\nb\tc")>>
Spec == Init /\ [][Next]_x

====
