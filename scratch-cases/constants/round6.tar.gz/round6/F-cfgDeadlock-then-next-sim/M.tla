---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
C == TRUE
D == PrintT("d")
Init == x = 0
Next == x' = 1 - x /\ (IF TLCGet("config").deadlock THEN C ELSE TRUE)

Spec == Init /\ [][Next]_x

====
