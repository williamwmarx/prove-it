---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == TRUE
D(a) == PrintT(<<"d", a>>)

Init == x = 0 /\ ([i \in 1..2 |-> IF i = 1 THEN TRUE ELSE C(1)][2])
Next == x' = x

Spec == Init /\ [][Next]_x

====
