---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
C == TRUE
D == PrintT("d")
Init == x = 0 /\ (IF (CHOOSE s \in {"b", "a", "c"} : TRUE) = "a" THEN C ELSE TRUE)
Next == x' = x

Spec == Init /\ [][Next]_x

====
