---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")

Init == x = 0
Next == x' = 1 - x
Inv == IF x = 0 THEN C ELSE TRUE
Spec == Init /\ [][Next]_x

====
