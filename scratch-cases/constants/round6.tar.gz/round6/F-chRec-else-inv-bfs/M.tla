---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
C == TRUE
D == PrintT("d")
Init == x = 0
Next == x' = 1 - x
Inv == IF (CHOOSE r \in [a : {2, 1}] : TRUE).a = 1 THEN TRUE ELSE C
Spec == Init /\ [][Next]_x

====
