---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == TRUE
D(a) == PrintT(<<"d", a>>)
F(a, b) == LET z == b IN a
Init == x = 0 /\ (F(TRUE, C(1)))
Next == x' = x

Spec == Init /\ [][Next]_x

====
