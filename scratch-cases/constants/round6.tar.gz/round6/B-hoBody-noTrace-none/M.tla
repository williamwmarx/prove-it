---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")
Ap2(Op(_)) == Op(1)
Al == [x |-> x, c |-> Ap2(LAMBDA q : C)]
Init == x = 0
Next == x' = (x + 1) % 2

Spec == Init /\ [][Next]_x

====
