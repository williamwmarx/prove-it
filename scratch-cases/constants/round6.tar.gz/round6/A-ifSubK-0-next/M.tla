---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")
K == TRUE
KF == FALSE
Init == x = 0
Next == x' = 1 - x /\ (IF K THEN TRUE ELSE C)

Spec == Init /\ [][Next]_x

====
