---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
C == TRUE
D == PrintT("d")
Lv == TLCGet("level")
Init == x = 0
Next == x' = 1 - x /\ (IF Lv = 1 THEN TRUE ELSE C)

Spec == Init /\ [][Next]_x

====
