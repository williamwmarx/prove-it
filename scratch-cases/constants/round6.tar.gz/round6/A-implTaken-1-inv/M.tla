---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == TRUE
D(a) == PrintT(<<"d", a>>)

Init == x = 0
Next == x' = 1 - x
Inv == TRUE => C(1)
Spec == Init /\ [][Next]_x

====
