---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
C == TRUE
D == PrintT("d")
Lv == TLCGet("level")
Init == x = 0
Next == x' = x
ASSUME IF Lv = 1 THEN C ELSE TRUE
Spec == Init /\ [][Next]_x

====
