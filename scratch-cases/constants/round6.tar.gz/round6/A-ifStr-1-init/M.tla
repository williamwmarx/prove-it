---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == TRUE
D(a) == PrintT(<<"d", a>>)

Init == x = 0 /\ (IF "a" = "a" THEN C(1) ELSE TRUE)
Next == x' = x

Spec == Init /\ [][Next]_x

====
