---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT S
VARIABLE x
Init == x = S
Next == x' = x
Inv == x # S
Spec == Init /\ [][Next]_x

====
