---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == TRUE
D(a) == PrintT(<<"d", a>>)
K == TRUE
KF == FALSE
Init == x = 0 /\ (K \/ C(1))
Next == x' = x

Spec == Init /\ [][Next]_x

====
