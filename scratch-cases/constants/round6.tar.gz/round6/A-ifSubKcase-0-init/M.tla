---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")
K == TRUE
KF == FALSE
Init == x = 0 /\ (CASE K -> TRUE [] OTHER -> C)
Next == x' = x

Spec == Init /\ [][Next]_x

====
