---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Foo == 1

Init == x = 0 /\ (IF x = 0 THEN PrintT(Foo) ELSE TRUE)
Next == x' = x
Spec == Init /\ [][Next]_x
====
