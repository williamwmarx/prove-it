---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
C == TRUE
D == PrintT("d")
Init == x = 0
Next == x' = x
ASSUME IF TLCGetOrDefault(1, TRUE) THEN C ELSE TRUE
Spec == Init /\ [][Next]_x

====
