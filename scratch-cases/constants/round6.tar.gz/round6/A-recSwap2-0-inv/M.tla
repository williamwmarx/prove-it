---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")
RECURSIVE R(_, _, _)
R(n, c, d) == IF n = 0 THEN c ELSE R(n - 1, d, c)
Init == x = 0
Next == x' = 1 - x
Inv == R(2, TRUE, C)
Spec == Init /\ [][Next]_x

====
