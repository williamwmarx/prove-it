---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")
I == INSTANCE N WITH K <- TRUE
Init == x = 0
Next == x' = 1 - x /\ (I!Op(C))

Spec == Init /\ [][Next]_x

====
