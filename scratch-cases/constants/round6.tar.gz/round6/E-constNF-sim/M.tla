---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB, N
VARIABLE x
Inv == N = 2

Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
