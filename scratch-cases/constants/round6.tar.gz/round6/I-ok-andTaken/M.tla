---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
Foo == 1

Init == x = 0 /\ (TRUE /\ PrintT(Foo))
Next == x' = x
Spec == Init /\ [][Next]_x
====
