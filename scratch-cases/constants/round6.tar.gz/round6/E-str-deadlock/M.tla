---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
Inv == "s"

Init == x = 0
Next == x < 1 /\ x' = x + 1
Spec == Init /\ [][Next]_x

====
