---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C(a) == TRUE
D(a) == PrintT(<<"d", a>>)
K == TRUE
K2 == FALSE
K3 == K2
Init == x = 0
Next == x' = 1 - x
Inv == IF K THEN TRUE ELSE C(1)
Spec == Init /\ [][Next]_x

====
