---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
Init == x = 0
Next == x' = (x + 1) % 3 /\ AssertEq([i \in {"p", "q"} |-> i], [i \in 1..2 |-> i])

Spec == Init /\ [][Next]_x

====
