---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
CONSTANT MA, MB
VARIABLE x
C == TRUE
D == PrintT("d")
Init == x = 0
Next == x' = 1 - x /\ (IF <<1>> = [i \in {1} |-> 1] THEN TRUE ELSE C)

Spec == Init /\ [][Next]_x

====
