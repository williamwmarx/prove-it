---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")
Id(q) == q
Ap(Op(_), v) == Op(v)
Init == x = 0 /\ (Ap(Id, C))
Next == x' = x

Spec == Init /\ [][Next]_x

====
