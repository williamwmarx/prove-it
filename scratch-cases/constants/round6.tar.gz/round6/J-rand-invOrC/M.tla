---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == RandomElement({TRUE})
Inv == TRUE \/ C
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
