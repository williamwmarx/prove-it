---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")
F(a, b) == LET Z(q) == b IN Z(1)
Init == x = 0
Next == x' = x
ASSUME F(0, C)
Spec == Init /\ [][Next]_x

====
