---- MODULE N ----
CONSTANT K
Op(c) == IF K THEN TRUE ELSE c
====
