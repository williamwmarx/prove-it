---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == AssertEq(<<1>>, <<2>>)
Al == [x |-> x, c |-> C]
Inv2 == x < 1
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
