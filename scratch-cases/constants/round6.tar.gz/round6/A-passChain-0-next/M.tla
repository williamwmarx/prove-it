---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")
H(r) == r
G(q) == H(q)
F(a, b) == G(b)
Init == x = 0
Next == x' = 1 - x /\ (F(0, C))

Spec == Init /\ [][Next]_x

====
