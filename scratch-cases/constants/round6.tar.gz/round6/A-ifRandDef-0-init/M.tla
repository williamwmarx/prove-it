---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")
RK == RandomElement({FALSE})
Init == x = 0 /\ (IF RK THEN TRUE ELSE C)
Next == x' = x

Spec == Init /\ [][Next]_x

====
