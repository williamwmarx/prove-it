---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x

Inv == CASE TRUE -> TRUE [] OTHER -> TLCSet(1, TRUE)
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x

====
