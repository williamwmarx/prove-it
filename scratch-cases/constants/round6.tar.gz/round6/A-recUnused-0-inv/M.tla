---- MODULE M ----
EXTENDS Naturals, TLC, TLCExt, Sequences, FiniteSets
VARIABLE x
C == TRUE
D == PrintT("d")
RECURSIVE R(_, _)
R(n, c) == IF n = 0 THEN TRUE ELSE R(n - 1, c)
Init == x = 0
Next == x' = 1 - x
Inv == R(2, C)
Spec == Init /\ [][Next]_x

====
