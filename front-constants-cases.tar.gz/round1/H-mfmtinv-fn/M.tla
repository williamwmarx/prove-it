---- MODULE M ----
EXTENDS Integers, TLC
VARIABLE x
C == [n \in 1..2 |-> n]
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x
====
