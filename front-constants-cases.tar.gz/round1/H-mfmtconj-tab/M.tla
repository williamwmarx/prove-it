---- MODULE M ----
EXTENDS Integers, TLC
VARIABLE x
C == "a\tb"
Init == x = 0
Next == x' = x
Spec == C /\ Init /\ [][Next]_x
====
