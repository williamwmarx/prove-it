---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
I == INSTANCE N WITH c <- (LAMBDA n : n + 1)(2)
ASSUME I!Val # 100
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x
====
