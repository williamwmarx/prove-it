---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x
Twice(a) == a + a
Never(a) == 7
Ap(F(_), a) == F(a)
K == Len(Trace)
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x
====
