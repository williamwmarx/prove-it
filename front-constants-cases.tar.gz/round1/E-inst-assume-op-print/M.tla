---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
I == INSTANCE N WITH c <- Print("c", 3)
ASSUME I!Val # 100
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x
====
