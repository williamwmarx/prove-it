---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT C
VARIABLE x
ASSUME PrintT(C)
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x
====
