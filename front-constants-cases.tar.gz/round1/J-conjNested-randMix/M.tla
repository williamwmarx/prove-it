---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x
C == RandomElement({TRUE, FALSE})
S0 == Init /\ C
Init == x = 0
Next == x' = x
Spec == S0 /\ [][Next]_x
====
