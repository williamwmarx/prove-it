---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Inv == (LAMBDA n : n > 0)(1)
Inv2 == x = 0
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x
====
