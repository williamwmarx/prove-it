---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Prop == \A n \in {} : [](x # n + 10)
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x
====
