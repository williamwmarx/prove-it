---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x
Twice(a) == a + a
Never(a) == 7
Ap(F(_), a) == F(a)
K == Cardinality(RandomSubset(3, 1..20)) + Twice(RandomElement(1..9))
Init == x = K
Next == x' = x
Spec == Init /\ [][Next]_x
====
