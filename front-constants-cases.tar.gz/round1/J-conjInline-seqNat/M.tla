---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x

Init == x = 0
Next == x' = x
Spec == (<<1>> \in Seq(Nat)) /\ Init /\ [][Next]_x
====
