---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x
Twice(a) == a + a
Never(a) == 7
Ap(F(_), a) == F(a)
K == IF Twice(JavaTime) > 0 THEN 1 ELSE 0
ASSUME PrintT(K)
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x
====
