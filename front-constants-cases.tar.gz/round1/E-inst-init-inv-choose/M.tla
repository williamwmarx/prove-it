---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
I == INSTANCE N WITH c <- CHOOSE n \in {} : TRUE
Init == x = I!Val
Next == x' = x
Spec == Init /\ [][Next]_x
====
