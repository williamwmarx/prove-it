---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x
P(n) == n = 1 /\ ("a" = "a")
Init == x = 0
Next == x' = x
Spec == P(1) /\ Init /\ [][Next]_x
====
