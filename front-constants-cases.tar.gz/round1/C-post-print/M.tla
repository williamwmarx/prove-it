---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Post == PrintT("inv")
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x
====
