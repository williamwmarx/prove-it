---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Cons == {2, 1}
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x
====
