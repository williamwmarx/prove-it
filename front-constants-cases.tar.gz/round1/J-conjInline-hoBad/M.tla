---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x

Init == x = 0
Next == x' = x
Spec == (LET Ap(G(_), a) == G(a) IN Ap(LAMBDA n : n \div 0 > 0, 1)) /\ Init /\ [][Next]_x
====
