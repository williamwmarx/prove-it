---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Prop == [](IF 1 \div 0 = 0 THEN TRUE ELSE FALSE)
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x
====
