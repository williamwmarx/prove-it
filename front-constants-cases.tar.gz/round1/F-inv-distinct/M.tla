---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x
Twice(a) == a + a
Never(a) == 7
Ap(F(_), a) == F(a)
K == Twice(TLCGet("distinct"))
Inv == x + K # -1
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x
====
