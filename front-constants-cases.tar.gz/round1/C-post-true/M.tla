---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Post == TRUE
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x
====
