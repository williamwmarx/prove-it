---- MODULE N ----
EXTENDS Naturals, TLC, Sequences
CONSTANT c
Val == IF c > 0 THEN 1 ELSE 0
====
