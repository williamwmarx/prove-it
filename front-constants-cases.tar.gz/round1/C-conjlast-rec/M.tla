---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
C == [a |-> 1]
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x /\ C
====
