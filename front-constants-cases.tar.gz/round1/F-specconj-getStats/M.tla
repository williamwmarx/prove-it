---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x
Twice(a) == a + a
Never(a) == 7
Ap(F(_), a) == F(a)
K == IF TLCGet("stats").distinct >= 0 THEN 1 ELSE 0
Init == x = 0
Next == x' = x
Spec == (K # -1) /\ Init /\ [][Next]_x
====
