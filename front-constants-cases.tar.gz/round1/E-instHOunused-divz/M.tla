---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
I == INSTANCE N WITH c <- 1 \div 0
Init == x = I!Ap(LAMBDA n : 0, I!c)
Next == x' = x
Spec == Init /\ [][Next]_x
====
