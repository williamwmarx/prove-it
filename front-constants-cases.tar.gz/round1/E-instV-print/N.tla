---- MODULE N ----
EXTENDS Naturals, TLC, Sequences
CONSTANT c
VARIABLE y
Init0 == y = c
S == Init0 /\ [][y' = y]_y
====
