---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
I == INSTANCE N WITH c <- Print("c", 3), y <- x
Init == x = 0
Next == x' = x
Spec == I!S
====
