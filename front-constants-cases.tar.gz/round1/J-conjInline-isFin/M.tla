---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x

Init == x = 0
Next == x' = x
Spec == (IsFiniteSet(Nat)) /\ Init /\ [][Next]_x
====
