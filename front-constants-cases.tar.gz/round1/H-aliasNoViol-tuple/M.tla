---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x
Al == <<x>>
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x
====
