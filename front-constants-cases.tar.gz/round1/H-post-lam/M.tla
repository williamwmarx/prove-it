---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x
K == Print("k", TRUE)
Post == (LAMBDA a : a)(TRUE)
Init == x = 0 /\ TLCSet(0, 1)
Next == x' = x
Spec == Init /\ [][Next]_x
====
