---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT C
VARIABLE x
D == 1..2
Inv == C
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x
====
