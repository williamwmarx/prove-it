---- MODULE N ----
EXTENDS Naturals, TLC, Sequences
CONSTANT c
P == c # 100
====
