---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
I == INSTANCE N WITH c <- 1 \div 0
Init == x = 0
Next == x' = x
Spec == I!P /\ Init /\ [][Next]_x
====
