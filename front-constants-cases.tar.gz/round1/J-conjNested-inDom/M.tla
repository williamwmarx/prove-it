---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x
C == 1 \in DOMAIN [n \in 1..2 |-> n]
S0 == Init /\ C
Init == x = 0
Next == x' = x
Spec == S0 /\ [][Next]_x
====
