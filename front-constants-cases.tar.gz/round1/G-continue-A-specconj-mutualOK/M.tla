---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Ap(F(_), a) == F(a)
Ap1(F(_), a) == F(1)
Ign(F(_), a) == a
Ap2(F(_), a) == F(F(a))
Sel(b, F(_), G(_), a) == IF b THEN F(a) ELSE G(a)
Dbl(n) == 2 * n
Bad(n) == n \div 0
Zero(n) == 0
Twice(a) == a + a
Never(a) == 7
Fst(a, b) == a
RECURSIVE R(_, _)
R(n, a) == IF n = 0 THEN a ELSE R(n - 1, a)
RECURSIVE R2(_, _)
R2(n, a) == IF n = 0 THEN 0 ELSE R2(n - 1, a + 1)
RECURSIVE R3(_, _)
R3(n, a) == IF n = 3 THEN a ELSE R3(n + 1, a)
RECURSIVE Ev(_, _), Od(_, _)
Ev(n, a) == IF n = 0 THEN a ELSE Od(n - 1, a)
Od(n, a) == IF n = 0 THEN 1 ELSE Ev(n - 1, a)
RECURSIVE Sum(_)
Sum(s) == IF s = {} THEN 0 ELSE LET e == CHOOSE y \in s : TRUE IN e + Sum(s \ {e})
K == Ev(4, 9)
Init == x = 0
Next == x' = x
Spec == (K # -1) /\ Init /\ [][Next]_x
====
