---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
INSTANCE N WITH c <- Print("c", 3)
Init == x = Val
Next == x' = x
Spec == Init /\ [][Next]_x
====
