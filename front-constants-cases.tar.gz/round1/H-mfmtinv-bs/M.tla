---- MODULE M ----
EXTENDS Integers, TLC
VARIABLE x
C == "a\\b"
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x
====
