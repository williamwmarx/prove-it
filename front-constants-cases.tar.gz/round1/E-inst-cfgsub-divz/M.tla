---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT C
VARIABLE x
I == INSTANCE N WITH c <- 1 \div 0
Init == x = C
Next == x' = x
Spec == Init /\ [][Next]_x
====
