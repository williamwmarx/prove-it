---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x
P(n) == n = 1 /\ (\A n \in 0..3 : 6 \div n > 0)
Init == x = 0
Next == x' = x
Spec == P(1) /\ Init /\ [][Next]_x
====
