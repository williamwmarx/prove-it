---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Prop == [](IF (LAMBDA n : n > 0)(1) THEN TRUE ELSE FALSE)
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x
====
