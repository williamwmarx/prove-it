---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT C
VARIABLE x
I == INSTANCE N WITH c <- Print("c", 3)
Init == x = C
Next == x' = x
Spec == Init /\ [][Next]_x
====
