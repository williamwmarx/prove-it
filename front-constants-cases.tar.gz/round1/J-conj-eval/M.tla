---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x
C == TLCEval(1 + 1 = 2)
Init == x = 0
Next == x' = x
Spec == C /\ Init /\ [][Next]_x
====
