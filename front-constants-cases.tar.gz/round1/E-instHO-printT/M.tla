---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
I == INSTANCE N WITH c <- IF PrintT("c") THEN 3 ELSE 4
Init == x = I!Ap(LAMBDA n : n + 1, I!c)
Next == x' = x
Spec == Init /\ [][Next]_x
====
