---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Cons == (LAMBDA n : n > 0)(1)
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x
====
