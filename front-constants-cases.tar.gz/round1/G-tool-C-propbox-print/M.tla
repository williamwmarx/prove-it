---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Prop == [](IF PrintT("inv") THEN TRUE ELSE FALSE)
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x
====
