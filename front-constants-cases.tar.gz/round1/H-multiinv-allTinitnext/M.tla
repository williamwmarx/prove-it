---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
I1 == TRUE
I2 == 2 > 1
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x
====
