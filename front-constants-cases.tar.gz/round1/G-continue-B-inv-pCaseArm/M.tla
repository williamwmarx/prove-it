---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Ap(F(_), a) == F(a)
Ign(F(_), a) == a
Twice(a) == a + a
Never(a) == 7
Once(a) == a + 1
Fst(a, b) == a
LetT(a) == LET y == a IN y + y
RECURSIVE R(_, _)
R(n, a) == IF n = 0 THEN a ELSE R(n - 1, a)
K == CASE PrintT("g1") -> 1 [] PrintT("g2") -> 2
Inv == x + K # -1
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x
====
