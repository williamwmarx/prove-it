---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Inv == 3
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x
====
