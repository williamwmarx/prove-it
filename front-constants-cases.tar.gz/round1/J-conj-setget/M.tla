---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x
C == TLCSet(1, 2) /\ TLCGet(1) = 2
Init == x = 0
Next == x' = x
Spec == C /\ Init /\ [][Next]_x
====
