---- MODULE N ----
EXTENDS Naturals, TLC, Sequences
CONSTANT c
ASSUME c # 100
Val == 1
====
