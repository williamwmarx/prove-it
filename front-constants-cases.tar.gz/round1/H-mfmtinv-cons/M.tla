---- MODULE M ----
EXTENDS Integers, TLC
VARIABLE x
C == {3, 1, 2}
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x
====
