---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x

Init == x = 0
Next == x' = x
Spec == (LET F(a, b) == b IN F(TRUE, 1 \div 0 = 1)) /\ Init /\ [][Next]_x
====
