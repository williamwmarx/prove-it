---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
I == INSTANCE N WITH c <- 3
Init == x = I!Ap(LAMBDA n : n + 1, I!c)
Next == x' = x
Spec == Init /\ [][Next]_x
====
