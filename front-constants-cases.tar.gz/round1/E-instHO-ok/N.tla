---- MODULE N ----
EXTENDS Naturals, TLC, Sequences
CONSTANT c
Ap(F(_), a) == F(a)
====
