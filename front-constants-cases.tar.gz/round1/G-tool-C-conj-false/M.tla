---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
C == FALSE
Init == x = 0
Next == x' = x
Spec == C /\ Init /\ [][Next]_x
====
