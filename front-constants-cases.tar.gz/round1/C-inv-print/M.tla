---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Inv == PrintT("inv")
Inv2 == x = 0
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x
====
