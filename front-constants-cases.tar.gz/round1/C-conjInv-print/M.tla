---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
C == PrintT("p")
Inv == x = 0
Init == x = 0
Next == x' = x
Spec == Init /\ C /\ [][Next]_x
====
