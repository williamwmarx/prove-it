---- MODULE M ----
EXTENDS Integers, TLC
VARIABLE x
C == 2^40
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x
====
