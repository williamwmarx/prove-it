---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x
C == LET F(a, b) == a IN F(TRUE, 1 \div 0)
S0 == Init /\ C
Init == x = 0
Next == x' = x
Spec == S0 /\ [][Next]_x
====
