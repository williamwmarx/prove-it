---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
I(k) == INSTANCE N WITH c <- k
K == I(CHOOSE n \in {} : TRUE)!Val
Init == x = K
Next == x' = x
Spec == Init /\ [][Next]_x
====
