---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x
P(n) == n = 1 /\ (TLCSet(1, 2) /\ TLCGet(1) = 2)
Init == x = 0
Next == x' = x
Spec == P(1) /\ Init /\ [][Next]_x
====
