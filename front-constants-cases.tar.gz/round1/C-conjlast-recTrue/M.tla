---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
RECURSIVE R(_)
R(n) == IF n = 0 THEN TRUE ELSE R(n - 1)
C == R(3)
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x /\ C
====
