---- MODULE N ----
EXTENDS Naturals, TLC, Sequences
CONSTANT c
Val == 7
====
