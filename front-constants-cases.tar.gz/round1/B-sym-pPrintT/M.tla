---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT S
VARIABLE x
Ap(F(_), a) == F(a)
Ign(F(_), a) == a
Twice(a) == a + a
Never(a) == 7
Once(a) == a + 1
Fst(a, b) == a
LetT(a) == LET y == a IN y + y
RECURSIVE R(_, _)
R(n, a) == IF n = 0 THEN a ELSE R(n - 1, a)
K == Twice(IF PrintT("t") THEN 1 ELSE 0)
Sym == IF K # -1 THEN Permutations(S) ELSE {}
Init == x \in S
Next == x' \in S
Spec == Init /\ [][Next]_x
====
