---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x
P(n) == n = 1 /\ (LET F(a, b) == a IN F(TRUE, 1 \div 0))
Init == x = 0
Next == x' = x
Spec == P(1) /\ Init /\ [][Next]_x
====
