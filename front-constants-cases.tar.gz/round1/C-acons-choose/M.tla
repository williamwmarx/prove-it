---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
Cons == CHOOSE n \in {} : TRUE
Init == x = 0
Next == x' = (x + 1) % 2
Spec == Init /\ [][Next]_x
====
