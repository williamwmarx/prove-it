---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x

Init == x = 0
Next == x' = x
Spec == (CHOOSE b \in BOOLEAN : b) /\ Init /\ [][Next]_x
====
