---- MODULE N ----
EXTENDS Naturals, TLC, Sequences
CONSTANT c
Val == LET F(n) == n + c IN F(1)
====
