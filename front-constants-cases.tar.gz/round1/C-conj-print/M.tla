---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
C == PrintT("p")
Init == x = 0
Next == x' = x
Spec == C /\ Init /\ [][Next]_x
====
