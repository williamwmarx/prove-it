---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
VARIABLE x
C == {"b", "a"}
Init == x = 0
Next == x' = x
Spec == Init /\ [][Next]_x /\ C
====
