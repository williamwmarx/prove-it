---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets, TLCExt
VARIABLE x

Init == x = 0
Next == x' = x
Spec == (1 \in DOMAIN [n \in 1..2 |-> n]) /\ Init /\ [][Next]_x
====
