---- MODULE M ----
EXTENDS Naturals, TLC, Sequences, FiniteSets
CONSTANT C
VARIABLE x
Ap(F(_), a) == F(a)
Ign(F(_), a) == a
Twice(a) == a + a
Never(a) == 7
Once(a) == a + 1
Fst(a, b) == a
LetT(a) == LET y == a IN y + y
RECURSIVE R(_, _)
R(n, a) == IF n = 0 THEN a ELSE R(n - 1, a)
K == Ap(LAMBDA n : n + n, Print("p", 2))
Init == x = C
Next == x' = x
Spec == Init /\ [][Next]_x
====
